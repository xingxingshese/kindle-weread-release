"""In-app cover, idle timer and shared Kindle power events."""
import base64
import hashlib
import io
import json
import os
import queue
import subprocess
import sys
import time
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from datetime import date, datetime
from pathlib import Path

from PIL import Image, ImageOps

from client import cover_bytes
from legacy_paths import desktop_legacy_books
from resources import ROOT
from resources.screensaver_data import collect, local_calendar

MODES = {"calendar": "日历天气", "system": "系统壁纸", "cover": "书籍封面", "custom": "本地图片"}
FORMATS = {".png", ".jpg", ".jpeg", ".webp"}
DEFAULT = ROOT / "default-cover.png"
MAX_PICTURE = 2 * 1024 * 1024


def local_picture(directory, name):
    if (not name or name in (".", "..") or any(c in name for c in "/\\:\x00")
            or Path(name).suffix.lower() not in FORMATS):
        raise ValueError("请选择本地图片")
    path = directory / name
    if (directory.is_symlink() or directory.resolve().parent != directory.parent.resolve()
            or path.is_symlink() or path.resolve().parent != directory.resolve() or not path.is_file()):
        raise ValueError("图片不在壁纸目录中")
    if path.stat().st_size > MAX_PICTURE:
        raise ValueError("图片超过 2 MB")
    return path


def import_picture(books, directory, name):
    source = local_picture(books / "wallpapers", name)
    with source.open("rb") as file:
        raw = file.read(MAX_PICTURE + 1)
    if len(raw) > MAX_PICTURE:
        raise ValueError("图片超过 2 MB")
    with Image.open(io.BytesIO(raw)) as picture:
        if picture.format not in ("PNG", "JPEG", "WEBP") or max(picture.size) > 2048:
            raise ValueError("不可用的壁纸")
        picture.load()
    if source.parent.resolve() == directory.resolve():
        return name
    if directory.is_symlink() or directory.resolve().parent != directory.parent.resolve():
        raise ValueError("无效的壁纸目录")
    # A different picture may already have the same name in the Windows preview.
    alternate = "pw3-" + hashlib.sha256(raw).hexdigest() + source.suffix.lower()
    for target in (directory / name, directory / alternate):
        try:
            file = target.open("xb")
        except FileExistsError:
            if (not target.is_symlink() and target.is_file() and target.stat().st_size == len(raw)
                    and target.read_bytes() == raw):
                return target.name
            continue
        try:
            with file:
                file.write(raw)
        except OSError:
            target.unlink(missing_ok=True)
            raise
        return target.name
    raise ValueError("同名壁纸已存在")


def migrate_wallpaper(store, books, directory, splitlist):
    if store.get("", "wallpaper") is not None:
        return None
    config = books / "pw3-wallpaper.conf"
    try:
        if config.is_symlink() or not config.is_file() or config.stat().st_size > 8192:
            return None
        fields = splitlist(config.read_text(encoding="utf-8").strip())
        if len(fields) not in (2, 3) or fields[0] not in MODES:
            return None
        mode, name = fields[:2]
        minutes = 5
        if len(fields) == 3 and fields[2].isascii() and fields[2].isdecimal():
            value = int(fields[2])
            if 1 <= value <= 1440:
                minutes = value
        if name:
            try:
                name = import_picture(books, directory, name)
            except (ValueError, OSError, Image.DecompressionBombError):
                name = ""
        pref = dict(mode="calendar" if mode == "custom" and not name else mode, name=name, minutes=minutes)
    except (ValueError, OSError, tk.TclError):
        return None
    with store.connect() as db:
        inserted = db.execute("insert or ignore into items values('', 'wallpaper', '', ?)",
                              (json.dumps(pref, ensure_ascii=False),)).rowcount
    return pref if inserted else None


class ScreenSaver:
    def __init__(self, app):
        self.app, self.root, self.tk = app, app.root, app.root.tk
        self.directory = (Path("/mnt/us/weread") if app.kindle else app.store.path.parent) / "wallpapers"
        self.directory.mkdir(parents=True, exist_ok=True)
        pref = app.store.get("", "wallpaper")
        if pref is None and app.kindle:
            pref = migrate_wallpaper(app.store, self.directory.parent, self.directory, self.tk.splitlist)
        default_data = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Kindle-WeRead" / "independent"
        check_desktop = pref is None and not app.kindle and app.store.path.parent == default_data
        pref = pref or {}
        self.mode = pref.get("mode") if pref.get("mode") in MODES else "calendar"
        self.name = pref.get("name", "")
        self.minutes = min(1440, max(1, pref.get("minutes", 5)))
        self.overlay = self.canvas = self.picture = None
        self.backdrop = None
        self.focus = self.idle = self.preload = self.tick = None
        self.held = self.sleeping = self.locked = self.closed = False
        self.serial = 0
        self.image_size = None
        self.messages = queue.SimpleQueue()
        self.weather = app.store.get("", "wallpaper-weather", default={})
        self.weather_pending = False
        self.last_fetch = 0
        self.cover_key = None
        self.device = self.light = self.power = None
        if app.kindle:
            from sleep_device import Frontlight, PowerPolicy, SystemSleepWifi
            self.power = ThreadPoolExecutor(1)
            self.light = Frontlight()
            self.device = SystemSleepWifi(on_event=self.device_event)
            self.policy = PowerPolicy(self.device)
            self.device.start()
            self.policy.start()
        for name in ("reader_style.tcl", "calendar.tcl"):
            self.tk.call("source", "-encoding", "utf-8", str(ROOT / name))
        self.tk.createcommand("saver::input", self.activity)
        self.tk.eval("""
            proc saver::track {w} {
                if {[string match .sleep* $w] || ![winfo exists $w]} return
                if {"WeReadActivity" ni [bindtags $w]} {
                    bindtags $w [linsert [bindtags $w] 0 WeReadActivity]
                }
            }
            bind all <Map> {+saver::track %W}
            foreach {event kind} {ButtonPress press ButtonRelease release Motion move KeyPress key MouseWheel wheel} {
                bind WeReadActivity <$event> [list saver::input $kind]
            }
            saver::track .
        """)
        self.arm()
        if check_desktop:
            def migrate():
                try:
                    books = desktop_legacy_books()
                    if books is None:
                        return None
                    return migrate_wallpaper(app.store, books, self.directory, tk.Tcl().tk.splitlist)
                except (OSError, ValueError, subprocess.SubprocessError):
                    return None
            def migrated(future):
                imported = future.result()
                if imported and app.store.get("", "wallpaper") == imported:
                    self.mode, self.name, self.minutes = imported["mode"], imported["name"], imported["minutes"]
                    self.arm()
            self.background(migrate, migrated)

    def activity(self, kind):
        if self.overlay or self.sleeping:
            return
        if kind in ("press", "release"):
            self.held = kind == "press"
        self.arm()

    def cancel(self, name):
        timer = getattr(self, name)
        if timer:
            self.root.after_cancel(timer)
            setattr(self, name, None)

    def settings(self):
        from pw3_page import Page
        self.app.clear()
        page = Page(self.app)
        page.title("锁屏设置")
        page.footer([("‹ 返回", self.app.settings)])
        page.label("闲置多久后锁屏", 48, 282, 490, 108, 36)
        value = page.label("", 674, 282, 200, 108, anchor="center")
        def save(mode, minutes):
            self.app.store.put("", "wallpaper", "", dict(mode=mode, name=self.name, minutes=minutes))
            self.mode, self.minutes = mode, minutes
            self.arm()
            refresh()
        minus = page.button("－", lambda: save(self.mode, self.minutes-1), 550, 290, 112, 88, outline=True)
        plus = page.button("＋", lambda: save(self.mode, self.minutes+1), 890, 290, 112, 88, outline=True)
        page.line(48, 412, 976)
        page.label("锁屏显示", 48, 454, 976, 96, 36, bold=True)
        choices = {}
        for i, mode in enumerate(("calendar", "cover", "system")):
            choices[mode] = page.button(MODES[mode], lambda m=mode: save(m, self.minutes),
                                        48, 560 + i*112, 976, 96, anchor="w")
        legacy_image = page.label("", 48, 908, 976, 76, 28) if self.mode == "custom" else None
        if self.app.kindle:
            page.label("锁屏后再过 5 分钟，Kindle 进入休眠。", 48, 1020, 976, 88, 28)
        def refresh():
            if legacy_image:
                legacy_image.configure(text="当前使用已保存的本地图片" if self.mode == "custom" else "")
            value.configure(text=f"{self.minutes} 分钟")
            minus.configure(state="disabled" if self.minutes <= 1 else "normal")
            plus.configure(state="disabled" if self.minutes >= 1440 else "normal")
            for mode, button in choices.items():
                button.configure(text=("●　" if mode == self.mode else "○　") + MODES[mode])
        refresh()

    def arm(self):
        self.cancel("idle")
        self.cancel("preload")
        if self.overlay or self.sleeping or self.closed:
            return
        delay = self.minutes * 60000
        self.idle = self.root.after(delay, self.on_idle)
        if self.mode == "calendar":
            self.preload = self.root.after(delay - min(90000, delay//2), self.forecast)

    def on_idle(self):
        if self.held or self.tk.call("grab", "current", "."):
            self.arm()
        elif not self.sleeping:
            self.show(self.mode, self.name, lock=True)

    def background(self, work, done):
        future = self.app.media.submit(work)
        future.add_done_callback(lambda f: self.messages.put((done, f)))

    def poll(self):
        while not self.messages.empty():
            callback, value = self.messages.get()
            callback(value)

    def device_event(self, name):
        if name in self.device.EVENTS:
            with self.device.guard:
                asleep = bool(self.device.reasons.intersection(("saver", "suspend")))
            self.policy.system_state(asleep)
            self.messages.put((self.system_sleep, asleep))

    def system_sleep(self, asleep):
        if self.sleeping == asleep:
            return
        if asleep:
            if self.overlay and not self.locked:
                self.hide()  # Replace a settings preview with the configured wallpaper.
            self.sleeping = True
            if not self.overlay:
                self.show(self.mode, self.name, system_sleep=True)
            self.arm()
            self.cancel("tick")
            self.held = False
            if self.light:
                self.power.submit(self.light.dim, True)
        else:
            self.sleeping = False
            restore = self.light and not self.locked
            if self.overlay:
                self.hide()
            if restore:
                self.power.submit(self.light.restore)
            self.arm()
        if self.app.articles:
            self.app.articles.reset_clock()
        self.app.activity.reset()

    def remember(self, book):
        account = self.app.client.account
        key = (account, str(book["bookId"]), book.get("cover"))
        if self.cover_key == key:
            return
        self.cover_key = key
        saved = self.app.store.get(account, "wallpaper-book", default={})
        if saved.get("id") == key[1] and saved.get("image") and saved.get("url") == key[2]:
            return
        saved = {"id": key[1], "title": book["title"], "url": key[2]}
        self.app.store.put(account, "wallpaper-book", "", saved)
        if not key[2]:
            return
        def fetch():
            with Image.open(io.BytesIO(cover_bytes(key[2]) or b"")) as image:
                image.thumbnail((1072, 1448))
                stream = io.BytesIO()
                image.convert("L").save(stream, "JPEG", quality=85)
                return base64.b64encode(stream.getvalue()).decode("ascii")
        def stored(future):
            if self.cover_key == key and not future.exception():
                self.app.store.put(account, "wallpaper-book", "", dict(saved, image=future.result()))
        self.background(fetch, stored)

    def forecast(self):
        if self.sleeping or (self.locked and self.app.kindle) or self.weather_pending:
            return
        day = date.today().isoformat()
        if self.weather.get("day") == day and self.last_fetch and time.monotonic() - self.last_fetch < 1800:
            return
        self.last_fetch, self.weather_pending = time.monotonic(), True
        def fetch():
            fields = {}
            collect(True, fields.update)
            return fields
        def store(future):
            self.weather_pending = False
            if not future.exception() and day == date.today().isoformat():
                data = future.result()
                previous = self.weather.get("data", {})
                if (self.weather.get("day") == day and "temp" in previous and "temp" not in data
                        and (not data.get("city") or data["city"] == previous.get("city"))):
                    return
                self.weather = {"day": day, "data": data}
                self.app.store.put("", "wallpaper-weather", "", self.weather)
                if self.overlay and self.shown == "calendar":
                    self.draw()
        self.background(fetch, store)

    def show(self, mode, name="", lock=False, system_sleep=False):
        if self.overlay or (self.sleeping and not system_sleep):
            return
        self.cancel("idle")
        self.cancel("preload")
        self.serial += 1
        self.locked, self.shown, self.file = lock, mode, name
        self.image_size = self.lunar_day = None
        self.focus = self.tk.call("focus")
        if mode == "custom":
            self.backdrop = self.capture_background(name)
        if self.app.kindle:
            self.title = self.root.title()
            top = tk.Toplevel(self.root, name="sleep", bg="white")
            self.overlay = top
            top.title(self.title.replace("_PC:T_", "_PC:N_"))
            self.root.title(top.title())
            top.geometry(f"{self.root.winfo_screenwidth()}x{self.root.winfo_screenheight()}+0+0")
            top.protocol("WM_DELETE_WINDOW", self.hide)
            self.canvas = tk.Canvas(top, highlightthickness=0, bg="white")
            self.canvas.pack(fill="both", expand=True)
            def fit(event):
                if event.widget != top or top.overrideredirect():
                    return
                w, h = self.root.winfo_screenwidth(), self.root.winfo_screenheight()
                if (top.winfo_rootx(), top.winfo_rooty(), event.width, event.height) != (0, 0, w, h):
                    top.withdraw()
                    top.overrideredirect(True)
                    top.geometry(f"{w}x{h}+0+0")
                    top.deiconify()
                    top.lift()
                    self.canvas.focus_force()
            top.bind("<Configure>", fit)
        else:
            self.overlay = self.canvas = tk.Canvas(self.root, name="sleep", highlightthickness=0, bg="white")
            self.canvas.place(x=0, y=0, relheight=1, relwidth=1)
            self.tk.call("raise", self.canvas._w)
        self.canvas.bind("<Configure>", lambda _: self.draw())
        self.canvas.bind("<ButtonRelease-1>", self.hide)
        self.canvas.bind("<KeyRelease-Escape>", self.hide)
        self.overlay.update_idletasks()
        self.canvas.focus_force()
        self.previous_grab = self.tk.call("grab", "current", self.canvas._w)
        self.previous_grab_status = (self.tk.call("grab", "status", self.previous_grab)
                                     if self.previous_grab else None)
        self.canvas.grab_set()
        if lock and self.device:
            self.power.submit(self.light.dim, True)
            self.power.submit(self.policy.lock)
        if self.app.articles:
            self.app.articles.reset_clock()
        self.app.activity.reset()
        self.refresh()

    def refresh(self):
        if not self.overlay:
            return
        self.draw()
        if self.shown == "calendar" and not self.sleeping:
            self.forecast()
            self.tick = self.root.after(60000 - int(time.time()*1000) % 60000, self.refresh)

    def draw(self):
        if not self.canvas:
            return
        w, h = self.canvas.winfo_width(), self.canvas.winfo_height()
        if min(w, h) < 10:
            return
        if self.shown == "calendar":
            today = date.today().isoformat()
            if self.lunar_day != today:
                self.almanac = {}
                local_calendar(datetime.now(), self.almanac.update)
                self.lunar_day = today
            fields = dict(self.weather.get("data", {}) if self.weather.get("day") == today else {},
                          **self.almanac)
            self.tk.setvar("saver::cv", self.canvas._w)
            self.tk.setvar("saver::locked", int((self.sleeping or self.locked) and self.app.kindle))
            self.tk.setvar("saver::data", tuple(v for entry in fields.items() for v in entry))
            self.tk.call("saver::drawCalendar", w, h)
        elif self.image_size != (w, h):
            self.image_size = (w, h)
            serial = self.serial
            mode, file, account = self.shown, self.file, self.app.client.account
            def loaded(future):
                if serial != self.serial or self.image_size != (w, h):
                    return
                self.canvas.delete("all")
                if future.exception():
                    self.canvas.create_text(w//2, h//2, text="图片无法读取，请重新选择壁纸。")
                    return
                image, note = future.result()
                self.picture = tk.PhotoImage(data=image, format="png")
                self.canvas.create_image(w//2, h//2, image=self.picture)
                if note:
                    self.canvas.create_text(w//2, h-26, text=note)
            backdrop = self.backdrop
            self.background(lambda: self.image(mode, file, account, w, h, backdrop), loaded)

    def capture_background(self, name):
        if not name or Path(name).name != name:
            return None
        path = self.directory / name
        try:
            if path.stat().st_size > 2*1024*1024:
                return None
            with Image.open(path) as img:
                if "A" not in img.getbands() and "transparency" not in img.info:
                    return None
            from PIL import ImageGrab
            self.root.update_idletasks()
            if sys.platform == "win32":
                return ImageGrab.grab(window=self.root.winfo_id()).convert("L"), (0, 0)
            frame = self.app.frame
            x, y = frame.winfo_rootx(), frame.winfo_rooty()
            w, h = frame.winfo_width(), frame.winfo_height()
            if not self.tk.call("winfo", "containing", x+w//2, y+h//2):
                return None
            image = ImageGrab.grab(bbox=(x, y, x+w, y+h), xdisplay=self.root.winfo_screen())
            return image.convert("L"), (x, y) if self.app.kindle else (0, 0)
        except (OSError, TypeError, ValueError, ImportError):
            return None

    def image(self, mode, name, account, width, height, backdrop=None):
        source, note = DEFAULT, ""
        if mode == "custom":
            source = local_picture(self.directory, name)
        elif mode == "system":
            folder = Path("/usr/share/blanket/screensaver")
            files = sorted(p for p in folder.rglob("*") if p.suffix.lower() in FORMATS) if self.app.kindle else []
            if files:
                source = files[0]
            else:
                note = "系统壁纸不可用，显示默认封面"
        else:
            saved = self.app.store.get(account, "wallpaper-book", default={})
            if saved.get("image"):
                source = io.BytesIO(base64.b64decode(saved["image"]))
            else:
                note = "暂无书籍封面，显示默认封面"
        with Image.open(source) as img:
            if mode == "custom" and max(img.size) > 2048:
                raise ValueError("图片最长边超过 2048 像素")
            img = ImageOps.exif_transpose(img).convert("RGBA")
            img = ImageOps.contain(img, (width, height))
            if backdrop is None:
                paper = Image.new("L", img.size, 255)
                at = (0, 0)
            else:
                paper = Image.new("L", (width, height), 255)
                paper.paste(*backdrop)
                at = ((width-img.width)//2, (height-img.height)//2)
            paper.paste(img.convert("L"), at, img.getchannel("A"))
            stream = io.BytesIO()
            paper.save(stream, "PNG")
            return stream.getvalue(), note

    def hide(self, _=None):
        if not self.overlay or (self.sleeping and not self.closed):
            return "break"
        self.cancel("tick")
        self.serial += 1
        self.canvas.grab_release()
        self.overlay.destroy()
        self.overlay = self.canvas = self.picture = self.image_size = self.backdrop = None
        if self.app.kindle:
            self.root.title(self.title)
        if self.device and self.locked:
            self.power.submit(self.policy.restore)
        if self.light and self.locked and not self.sleeping:
            self.power.submit(self.light.restore)
        self.locked = self.held = False
        if self.previous_grab and self.tk.call("winfo", "exists", self.previous_grab):
            if self.previous_grab_status == "global":
                self.tk.call("grab", "set", "-global", self.previous_grab)
            else:
                self.tk.call("grab", "set", self.previous_grab)
        if self.focus and self.tk.call("winfo", "exists", self.focus):
            self.tk.call("focus", self.focus)
        if self.app.articles:
            self.app.articles.reset_clock()
        self.app.activity.reset()
        self.arm()
        return "break"

    def close(self):
        self.closed = True
        self.hide()
        for timer in ("idle", "preload", "tick"):
            self.cancel(timer)
        if self.device:
            self.power.shutdown(wait=True)
            self.policy.close()
            self.device.close()
            self.light.restore()
