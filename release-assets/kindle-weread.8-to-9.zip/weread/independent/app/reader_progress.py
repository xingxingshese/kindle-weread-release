"""On-screen reading progress for the chapter currently laid out by Tk."""
import math
import tkinter as tk


class ReadingProgress:
    def __init__(self, text, label, rows, row_index, preview, show_pages, *, full_pages=False):
        self.text, self.label = text, label
        self.preview, self.show_pages = preview, show_pages
        self.full_pages = full_pages
        self.previous_starts = {}
        counts = [max(0, int(row.get("wordCount") or 0)) for row in rows]
        self.before, self.chapter, self.total = sum(counts[:row_index]), counts[row_index], sum(counts)
        self.caption = None
        self.bottom_mask = tk.Frame(text, bg=text.cget("background"), bd=0) if full_pages else None
        text.configure(yscrollcommand=self.refresh)
        if show_pages or full_pages:
            text.bind("<Configure>", lambda _: self.settle(), add=True)

    def settle(self):
        self.previous_starts.clear()
        if self.show_pages and self.text.winfo_ismapped():
            # Tk normally computes wrapped line heights in the background. A page
            # count needs the final heights before the first turn or after reflow.
            self.text.tk.call(str(self.text), "count", "-update", "-ypixels", "1.0", "end")
            self.refresh(*self.text.yview())

    def pages(self, top, bottom):
        text = self.text
        inset = sum(text.winfo_pixels(text.cget(key)) for key in ("highlightthickness", "borderwidth", "pady"))
        height = max(1, text.winfo_height() - 2 * inset)
        span = bottom - top
        if span <= 0 or span >= 1:
            return 0, 1, 0, height, 0
        extent = round(height / span)
        offset = round(top * extent)
        end = max(0, extent - height)
        # Tk leaves two lines of context per page except in very short windows.
        line = int(text.tk.call("font", "metrics", text.cget("font"), "-linespace"))
        step = max(1, height - 2 * line if 4 * line < height else min(height, max(line, 3 * height // 4)))
        if self.full_pages:
            step = height
        last = math.ceil(end / step)
        if last and 2 * offset >= (last-1) * step + end:
            page = last
        else:
            page = (offset + step//2) // step
        return page, last + 1, offset, step, end

    def refresh(self, first, last):
        top, bottom = float(first), float(last)
        if self.text.winfo_height() <= 1 or bottom <= top:
            return
        if self.bottom_mask is not None:
            _, clipped_y = self.last_display_line()
            if clipped_y is None:
                self.bottom_mask.place_forget()
            else:
                self.bottom_mask.place(x=0, y=clipped_y, relwidth=1,
                                       height=self.text.winfo_height()-clipped_y, bordermode="outside")
        if self.show_pages:
            page, total, *_ = self.pages(top, bottom)
            caption = f"{'试读' if self.preview else '本章'} {page + 1} / {total} 页"
        elif self.total and self.chapter:
            if self.preview:
                # A displayed excerpt can be much shorter than the published chapter.
                index = self.text.index(f"@0,{self.text.winfo_height()-1} display lineend")
                seen = sum(not c.isspace() for c in self.text.get("1.0", index))
                within = min(self.chapter, seen)
            else:
                within = self.chapter * bottom
            caption = f"全书约 {100 * (self.before + within) / self.total:.1f}%"
        else:
            caption = f"{'试读' if self.preview else '本章'} {bottom:.0%}"
        if self.caption != caption:
            self.label.configure(text=caption)
            self.caption = caption

    def turn(self, direction):
        if self.full_pages:
            self.turn_full_page(direction)
            return
        if not self.show_pages:
            self.text.yview_scroll(direction, "pages")
            return
        page, count, offset, step, end = self.pages(*self.text.yview())
        target = min(count-1, max(0, page + direction))
        self.text.yview_scroll(min(target * step, end) - offset, "pixels")

    def last_display_line(self):
        text = self.text
        inset = sum(text.winfo_pixels(text.cget(key)) for key in ("highlightthickness", "borderwidth", "pady"))
        bottom = text.winfo_height() - inset
        line = text.index(f"@0,{bottom-1} display linestart")
        bounds = text.dlineinfo(line)
        if bounds:
            following = text.index(line + " +1 display lines display linestart")
            # dlineinfo reports only the visible portion at the bottom. Count
            # pixels to the next display line to measure the unclipped height.
            height = int(text.tk.call(str(text), "count", "-ypixels", line, following))
            if bounds[1] > inset and bounds[1] + height > bottom:
                return line, bounds[1]
        return line, None

    def turn_full_page(self, direction):
        text = self.text
        start = text.index("@0,0 display linestart")
        if direction < 0 and start in self.previous_starts:
            text.yview(self.previous_starts[start])
            return
        inset = sum(text.winfo_pixels(text.cget(key)) for key in ("highlightthickness", "borderwidth", "pady"))
        bottom = text.winfo_height() - inset
        height = max(1, bottom - inset)
        if direction < 0:
            text.yview_scroll(-height, "pixels")
            text.yview(text.index("@0,0 display linestart"))
            return
        last, clipped_y = self.last_display_line()
        if clipped_y is None and text.compare(last, ">", start):
            last = text.index(last + " +1 display lines display linestart")
        if text.compare(last, ">", start):
            text.yview(last)
        else:
            text.yview_scroll(height, "pixels")
        following = text.index("@0,0 display linestart")
        if following != start:
            self.previous_starts[following] = start
