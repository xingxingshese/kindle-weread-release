"""Public-account list and ordered article content for the current login."""
import datetime
import json
import re
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args):
        return None


class Article(HTMLParser):
    void = set("area base br col embed hr img input link meta param source track wbr".split())
    blocks = set("p section div h1 h2 h3 h4 h5 li blockquote tr".split())

    heading_tags = {"h1", "h2", "h3", "h4", "h5", "h6"}

    def __init__(self, *, style_headings=False):
        super().__init__()
        self.style_headings = style_headings
        self.stack = []
        self.parts = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if (not self.stack and attrs.get("id") != "js_content"
                and "rich_media_content" not in (attrs.get("class") or "").split()):
            return
        if tag not in self.void:
            self.stack.append(tag)
        if self.style_headings and tag in self.heading_tags:
            self.parts.append(("heading", True))
        if tag in self.blocks or tag == "br":
            self.parts.append("\n")
        if tag == "img":
            url = attrs.get("data-src") or attrs.get("src") or ""
            self.parts.append(("picture", url, attrs.get("data-ratio") or "0", attrs.get("alt") or ""))

    def handle_endtag(self, tag):
        if tag in self.stack:
            del self.stack[len(self.stack) - self.stack[::-1].index(tag) - 1:]
            if self.style_headings and tag in self.heading_tags:
                self.parts.append(("heading", False))
            if tag in self.blocks:
                self.parts.append("\n")

    def handle_data(self, text):
        if self.stack and not any(t in ("script", "style", "template") for t in self.stack):
            self.parts.append(re.sub(r"\s+", " ", text))

    def blocks_in_order(self):
        text = []
        heading = False
        for part in [*self.parts, None]:
            if isinstance(part, str):
                text.append(part)
                continue
            paragraphs = [p.strip() for p in "".join(text).splitlines() if p.strip()]
            if paragraphs:
                block = ("paragraphs", "\n\n".join(paragraphs))
                yield (*block, "heading") if heading else block
            text.clear()
            if part is not None and part[0] == "heading":
                heading = part[1]
            elif part is not None:
                yield part


class ArticleServiceError(ValueError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = str(code)


# Public Tencent Cloud profile of Tencent_TEG, independently of its WeRead feed.
TENCENT_TEG = "MP_WXS_2398602260"
TENCENT_PROFILE = "https://cloud.tencent.com/developer/user/170434/articles"
TENCENT_COLUMN = "https://cloud.tencent.com/developer/column/1283"


class PublisherLinks(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows = {}
        self.link = None
        self.text = []
        self.heading = []
        self.in_heading = False
        self.in_title = False
        self.page_title = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == "title":
            self.in_title = True
        if tag == "a":
            dest = urlsplit(urljoin(TENCENT_PROFILE, attrs.get("href") or ""))
            self.link = None
            if (dest.scheme == "https" and dest.netloc == "cloud.tencent.com"
                    and re.fullmatch(r"/developer/article/[0-9]+", dest.path)):
                self.link = "https://cloud.tencent.com" + dest.path
            self.text, self.heading = [], []
            self.in_heading = False
        if self.link and tag in ("h2", "h3", "h4"):
            self.in_heading = True

    def handle_data(self, data):
        if self.in_title:
            self.page_title.append(data)
        if self.link:
            self.text.append(data)
            if self.in_heading:
                self.heading.append(data)

    def handle_endtag(self, tag):
        if tag == "title":
            self.in_title = False
        if tag in ("h2", "h3", "h4"):
            self.in_heading = False
        if tag == "a" and self.link:
            title = " ".join("".join(self.heading or self.text).split())
            if title:
                self.rows.setdefault(self.link, title)
            self.link = None


def publisher_articles():
    # This public site must never receive the reader's WeRead cookies.
    with build_opener(NoRedirect()).open(Request(TENCENT_PROFILE), timeout=10) as response:
        if response.headers.get_content_type() != "text/html":
            raise ArticleServiceError("format", "腾讯云未返回公开作者页。")
        raw = response.read(4 * 1024 * 1024 + 1)
    if len(raw) > 4 * 1024 * 1024:
        raise ArticleServiceError("format", "腾讯云作者页过大，请在浏览器查看。")
    parser = PublisherLinks()
    parser.feed(raw.decode("utf-8", errors="replace"))
    parser.close()
    if "腾讯技术工程官方号" not in "".join(parser.page_title) or not parser.rows:
        raise ArticleServiceError("format", "暂未取得腾讯技术工程公开文章。")
    return list(parser.rows.items())


def read_public_source(url):
    try:
        parts = urlsplit(url)
        if (parts.netloc != "mp.weixin.qq.com" or parts.scheme not in ("https", "http")
                or not (parts.path == "/s" or parts.path.startswith("/s/"))):
            return ""
    except ValueError:
        return ""
    # These links belong to WeChat. Never attach the reader's session.
    req = Request(parts._replace(scheme="https").geturl())
    with build_opener(NoRedirect()).open(req, timeout=10) as response:
        if response.headers.get_content_type() != "text/html":
            return ""
        raw = response.read(8 * 1024 * 1024 + 1)
        return raw.decode("utf-8", errors="replace") if len(raw) <= 8 * 1024 * 1024 else ""


def checked_json(raw):
    try:
        data = raw if isinstance(raw, dict) else json.loads(raw)
    except (ValueError, TypeError):
        raise ArticleServiceError("format", "微信读书返回的数据格式无法识别。") from None
    if not isinstance(data, dict):
        raise ArticleServiceError("format", "微信读书返回的数据格式无法识别。")
    code = data.get("errCode", data.get("errcode"))
    if code not in (None, 0, "0"):
        message = str(data.get("errMsg") or "")
        code = str(code)
        if message == code or not message:
            message = f"微信读书返回 {code}，请稍后重试。"
        raise ArticleServiceError(code, message)
    return data


def directory_rows(groups, offset, more=True, next_offset=None):
    for group in groups:
        if not isinstance(group, dict):
            continue
        children = group.get("subReviews")
        for sub in [group, *(children if isinstance(children, list) else [])]:
            if not isinstance(sub, dict):
                continue
            review = sub.get("review") or sub
            if not isinstance(review, dict):
                continue
            info = review.get("mpInfo") or {}
            if not isinstance(info, dict):
                continue
            rid = sub.get("reviewId") or review.get("reviewId")
            title = info.get("title") or review.get("title") or sub.get("title")
            if not rid or not title:
                continue
            timestamp = info.get("time") or review.get("createTime") or sub.get("createTime")
            try:
                date = datetime.date.fromtimestamp(int(timestamp)).isoformat() if timestamp else ""
            except (OverflowError, ValueError, OSError, TypeError):
                date = ""
            yield ("item", rid, title, info.get("mp_name", ""), date,
                   info.get("doc_url") or "", info.get("pic_url") or "", str(info.get("payType", "")))
    if more in (False, "0", None):
        following = ""
    elif next_offset is None:
        following = str(offset + len(groups)) if groups else ""
    elif str(next_offset).isascii() and str(next_offset).isdigit() and int(next_offset) > offset:
        following = str(next_offset)
    else:
        raise ArticleServiceError("cursor", "微信读书返回了重复或无效的文章列表分页位置。")
    yield "next", following


def page_directory(html, book):
    marker = re.search(r"window\.__INITIAL_STATE__\s*=\s*", html)
    if not marker:
        return []
    try:
        state = json.JSONDecoder().raw_decode(html[marker.end():])[0]
    except ValueError:
        return []
    if not isinstance(state, dict):
        return []
    for reader in state.values():
        if not isinstance(reader, dict):
            continue
        info = reader.get("bookInfo") or {}
        if not isinstance(info, dict) or str(reader.get("bookId") or info.get("bookId")) != book:
            continue
        if reader.get("isBookForbidden") in (1, True, "1"):
            raise ArticleServiceError("forbidden", "微信读书未开放这个公众号的文章列表。")
        groups = reader.get("articles") or reader.get("reviews")
        if isinstance(groups, list) and groups:
            rows = list(directory_rows(groups, 0, reader.get("hasMore", True), reader.get("nextOffset")))
            if any(row[0] == "item" for row in rows):
                return rows
    return []


def records(mode, key, offset, *, fetch, public_source=None, native_fetch=None):
    if mode == "list" and re.fullmatch(r"MP_WXS_[0-9]+", key):
        if native_fetch:
            # The Kindle/mobile client opens an MP feed with a sync key, then uses
            # offsets for later pages. These are separate request shapes.
            count = 5
            params = ({"bookId": key, "count": count, "synckey": 0} if not offset else
                      {"bookId": key, "count": count, "offset": offset})
            page = checked_json(native_fetch("/mp/chapters", params))
            groups = page.get("data")
            if not isinstance(groups, list):
                groups = page.get("reviews", page.get("articles"))
        else:
            count = None
            page = checked_json(fetch("articles", {"bookId": key, "offset": offset}))
            groups = page.get("reviews", page.get("articles"))
        if not isinstance(groups, list):
            raise ArticleServiceError("format", "微信读书未返回文章列表。")
        more = page.get("hasMore", True)
        next_offset = page.get("nextOffset")
        if native_fetch:
            # The mobile list advances by the number of groups (not subarticles).
            more = len(groups) >= count and more not in (False, 0, "0")
            next_offset = offset + len(groups) if more else None
        rows = list(directory_rows(groups, offset, more, next_offset))
        if groups and len(rows) == 1:
            raise ArticleServiceError("format", "微信读书未返回可识别的文章。")
        yield from rows
    elif mode == "read":
        raw = fetch("content", {"reviewId": key})
        if isinstance(raw, dict) or raw.lstrip().startswith("{"):
            checked_json(raw)
            raw = ""
        parser = Article()
        parser.feed(raw)
        parser.close()
        blocks = list(parser.blocks_in_order())
        if not blocks and public_source:
            url = public_source()
            if url:
                parser = Article()
                parser.feed(read_public_source(url))
                parser.close()
                blocks = list(parser.blocks_in_order())
        if not blocks:
            raise ArticleServiceError("empty", "微信读书未返回可显示的文章正文。")
        yield from blocks
        yield "ready",
    else:
        raise ValueError("未识别的公众号。")
