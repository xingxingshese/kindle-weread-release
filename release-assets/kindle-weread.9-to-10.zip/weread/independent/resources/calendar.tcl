namespace eval saver {
    variable factor 1
    variable ox 0
    variable oy 0
}
proc saver::val {key {fallback —}} {
    if {[dict exists $saver::data $key]} {return [dict get $saver::data $key]}
    return $fallback
}
proc saver::x {x} {expr {$saver::ox+$x*$saver::factor}}
proc saver::y {y} {expr {$saver::oy+$y*$saver::factor}}
proc saver::line {x1 y1 x2 y2 {color #aaaaaa}} {
    $saver::cv create line [x $x1] [y $y1] [x $x2] [y $y2] -fill $color
}
proc saver::label {x y value px {weight normal} {anchor w} {color #222222} {wrap 0}} {
    $saver::cv create text [x $x] [y $y] -text $value -anchor $anchor -fill $color \
        -font [list {Noto Sans CJK SC} [expr {-max(1,round($px*$saver::factor))}] $weight] \
        -width [expr {$wrap*$saver::factor}]
}
proc saver::pair {x y prefix value px {weight normal} {color #222222}} {
    label $x $y $prefix $px $weight w $color
    set font [list {Noto Sans CJK SC} [expr {-max(1,round($px*$saver::factor))}] $weight]
    set vx [expr {[x $x]+[font measure $font "$prefix　"]}]
    $saver::cv create text $vx [y $y] -text $value -anchor w -fill $color -font $font
}
proc saver::drawCalendar {w h} {
    set saver::factor [expr {min($w/1072.0,$h/1448.0)}]
    set saver::ox [expr {($w-1072*$saver::factor)/2}]
    # Calendar lock screens have no pull-down Kindle status strip. Move the
    # layout into that unused top band and keep the lower forecast above the
    # return hint, leaving room for two wrapped lines of advice.
    set saver::oy [expr {($h-1448*$saver::factor)/2 - 80*$saver::factor}]
    $saver::cv delete all
    set now [clock seconds]
    set day [clock format $now -format %e]
    set first [clock scan [clock format $now -format %Y-%m-01] -format %Y-%m-%d]
    set last [clock add [clock add $first 1 month] -1 day]
    set offset [expr {[clock format $first -format %u]-1}]
    label 48 124 [clock format $now -format {%Y 年 %m 月}] 36 bold
    line 48 167 1024 167
    label 48 314 [clock format $now -format %H:%M] 84 bold
    label 52 404 [clock format $now -format {%m 月 %d 日}] 38
    label 52 474 星期[string index 一二三四五六日 [expr {[clock format $now -format %u]-1}]] 34
    label 52 534 [val lunar] 28 normal w $ui::secondary
    for {set i 0} {$i < 7} {incr i} {label [expr {485+82*$i}] 225 [string index 一二三四五六日 $i] 27 normal center $ui::secondary}
    for {set n 1} {$n <= [clock format $last -format %e]} {incr n} {
        set cell [expr {$offset+$n-1}]
        set cx [expr {485+82*($cell%7)}]; set cy [expr {281+52*($cell/7)}]
        set ink $ui::ink
        if {$n == $day} {
            $saver::cv create rectangle [x [expr {$cx-28}]] [y [expr {$cy-23}]] [x [expr {$cx+28}]] [y [expr {$cy+23}]] -fill $ui::ink -outline {}
            set ink white
        }
        label $cx $cy $n 29 normal center $ink
    }
    line 48 601 1024 601
    set city [val city {}]
    label 48 670 [expr {$city eq {} ? "当地天气" : $city}] 36 bold
    label 48 779 "[val temp]° [val current 获取天气中]" 60 bold
    set cols {423 627 831}
    set i 0
    foreach {name key} {湿度 humidity 体感 feels 风力 wind 空气指数 aqi 紫外线 uv 降水概率 rain} {
        set cx [lindex $cols [expr {$i%3}]]
        set cy [expr {$i < 3 ? 666 : 753}]
        label $cx $cy $name 26 normal w $ui::secondary
        label $cx [expr {$cy+40}] [val $key] 32
        incr i
    }
    line 48 832 1024 832
    label 48 899 逐小时预报 36 bold
    set hcols {48 294 540 786}
    for {set i 0} {$i < 4} {incr i} {
        set cx [lindex $hcols $i]
        label $cx 950 [val hour$i] 26 normal w $ui::secondary
        label $cx 997 "[val temp$i] [val sky$i]" 32
    }
    line 48 1035 1024 1035
    label 48 1102 今日黄历 36 bold
    pair 48 1158 宜 [val good] 28
    pair 48 1207 忌 [val avoid] 28
    label 568 1102 日光时刻 36 bold
    pair 568 1158 日出 [val sunrise] 28
    pair 568 1207 日落 [val sunset] 28
    line 48 1245 1024 1245
    label 48 1320 明日穿衣建议 32 bold
    label 48 1382 [val clothes 等待天气预报] 28 normal w $ui::ink 480
    label 568 1320 明日天气 32 bold
    label 568 1382 "[val tomorrow]　[val range]" 28 normal w $ui::ink 456
    set stampFont [list {Noto Sans CJK SC} [expr {-max(1,round(26*$saver::factor))}]]
    set stamp [val stamp [expr {$saver::locked ? "离线 · 暂无天气数据" : "正在获取当地天气"}]]
    set width [expr {740*$saver::factor}]
    if {[font measure $stampFont $stamp] > $width} {
        while {[string length $stamp] && [font measure $stampFont "$stamp…"] > $width} {
            set stamp [string range $stamp 0 end-1]
        }
        append stamp …
    }
    label 48 1480 $stamp 26 normal w $ui::secondary
    label 1024 1480 轻点返回阅读 26 normal e $ui::secondary
}
