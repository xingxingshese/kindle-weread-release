"""Book selections, dictionary, highlights, thoughts and discussions."""
import base64
from functools import lru_cache
from pathlib import Path
from string import ascii_letters, digits
import tkinter as tk

from locations import SourceOffsets
from pw3_page import Page, INK, SECONDARY
from variants import hidden_range
import reviews

SECTIONS = (("mine", "我的划线"), ("bookmarks", "书签"), ("popular", "热门划线"), ("thoughts", "我的想法"), ("reviews", "书评"))


@lru_cache(maxsize=1)
def selection_words():
    with Path(__file__).with_name("pinyin.tsv").open(encoding="utf-8") as source:
        return frozenset(word for line in source if not line.startswith("#")
                         for word in line.partition("\t")[2].split() if 2 <= len(word) <= 4)


def chinese_word_bounds(text, held):
    before = text.get(held + "-3c", held)
    sample = before + text.get(held, held + "+4c")
    at = len(before)
    words = selection_words()
    for length in (4, 3, 2):
        for start in range(max(0, at-length+1), min(at, len(sample)-length)+1):
            if sample[start:start+length] in words:
                first = text.index(f"{held}-{at-start}c")
                return first, text.index(f"{first}+{length}c")
    return held, text.index(held + "+1c")


def show_underlines(text, uid, result, blocks, marks, chapter_marks=()):
    overlay = getattr(text, "dashed_underlines", None)
    if overlay:
        overlay.schedule()
    for tag in getattr(text, "book_marks", {}):
        text.tag_delete(tag)
    text.book_marks = {}
    text.tag_remove("myUnderline", "1.0", "end")
    text.tag_remove("chapterUnderline", "1.0", "end")
    rows = [(m, "myUnderline") for m in marks if str(m.get("uid")) == uid and m.get("quote")]
    rows.extend((m, "chapterUnderline") for m in chapter_marks)
    if not rows:
        return
    try:
        offsets = SourceOffsets(result, blocks)
    except ValueError:
        return
    text.tag_configure("myUnderline", underline=False)
    text.tag_configure("chapterUnderline", underline=False)
    for mark, style in rows:
        span = str(mark.get("range") or "")
        if hidden_range(result, span):
            continue
        bounds = span.split("-")
        if len(bounds) != 2 or not all(n.isascii() and n.isdigit() for n in bounds):
            continue
        low, high = map(int, bounds)
        if high <= low:
            continue
        indices = offsets.range_indices(low, high)
        if not indices:
            continue
        actual = text.get(*indices).strip()
        if not actual:
            continue
        quote = mark.get("quote") or actual
        if "".join(actual.split()) != "".join(quote.split()):
            # A web bookmark can echo the base64-encoded markText used when saving.
            # Accept it only if it resolves to the text at the supplied source coordinates.
            try:
                quote = base64.b64decode(quote, validate=True).decode("utf-8")
            except (ValueError, UnicodeError):
                continue
            if "".join(actual.split()) != "".join(quote.split()):
                continue
        text.tag_add(style, *indices)
        tag = "book-mark-" + span
        text.tag_add(tag, *indices)
        text.book_marks[tag] = dict(mark, quote=quote)


class DashedUnderlineOverlay:
    """Draw Kindle-friendly dashed marks over Text without changing its offsets."""
    def __init__(self, text):
        self.text = text
        self.widgets = []
        self.pending = None
        self.action = None
        self.scroll_command = text.cget("yscrollcommand")
        text.configure(yscrollcommand=self.scrolled)
        text.bind("<Configure>", lambda _: self.schedule(), add=True)
        text.bind("<Destroy>", self.destroy, add=True)
        text.dashed_underlines = self
        self.schedule()

    def scrolled(self, first, last):
        if self.scroll_command:
            self.text.tk.call(self.scroll_command, first, last)
        self.schedule()

    def schedule(self):
        if self.pending is None and self.text.winfo_exists():
            self.pending = self.text.after_idle(self.redraw)

    def destroy(self, _event=None):
        self.pending = None
        for widget in self.widgets:
            try:
                widget.destroy()
            except tk.TclError:
                pass
        self.widgets.clear()

    def redraw(self):
        self.pending = None
        text = self.text
        if not text.winfo_exists():
            return
        for widget in self.widgets:
            try:
                widget.destroy()
            except tk.TclError:
                pass
        self.widgets.clear()
        text.update_idletasks()
        height = text.winfo_height()
        width = text.winfo_width()
        background = text.cget("background")
        for tag, mark in getattr(text, "book_marks", {}).items():
            ranges = text.tag_ranges(tag)
            for first, last in zip(ranges[::2], ranges[1::2]):
                cursor = str(first)
                segment = None
                while text.compare(cursor, "<", last):
                    bounds = text.bbox(cursor)
                    next_index = text.index(cursor + " +1c")
                    if bounds:
                        x, y, char_width, line_height = map(int, bounds)
                        if char_width > 0 and y < height and y + line_height > 0:
                            if segment and segment[1] == y and x <= segment[2] + 2:
                                segment[2] = max(segment[2], x + char_width)
                                segment[3] = max(segment[3], line_height)
                            else:
                                if segment:
                                    self.add_segment(*segment, tag, mark, background, width, height)
                                segment = [x, y, x + char_width, line_height]
                        elif segment:
                            self.add_segment(*segment, tag, mark, background, width, height)
                            segment = None
                    elif segment:
                        self.add_segment(*segment, tag, mark, background, width, height)
                        segment = None
                    cursor = next_index
                if segment:
                    self.add_segment(*segment, tag, mark, background, width, height)

    def add_segment(self, x, y, right, line_height, tag, mark, background, width, height):
        left = max(0, x)
        right = min(width, right)
        top = y + line_height - 4
        if right <= left or top < 0 or top + 4 > height:
            return
        canvas = tk.Canvas(self.text, width=right-left, height=4, bg=background,
                           bd=0, highlightthickness=0, takefocus=False)
        canvas.create_line(0, 1, right-left, 1, fill="#888888", width=1, dash=(1, 3))
        canvas.place(x=left, y=top, width=right-left, height=4)
        canvas.bind("<ButtonRelease-1>", lambda _event, value=mark: self.action(value)
                    if self.action else None)
        self.widgets.append(canvas)


class BookNotes:
    def __init__(self, app, show_list=True):
        self.app = app
        self.book = str(app.book["bookId"])
        self.client = app.client
        self.account = self.client.account
        self.reading_row = next(r for r in app.rows if str(r["chapterUid"]) == app.uid)
        self.index = app.save_position()
        self.loaded = app.loaded
        self.blocks = app.reading_blocks
        self.version = self.loaded.get("version")
        if self.version is None:
            self.version = app.book.get("version")
        self.chapters = {str(row["chapterUid"]): row for row in app.rows}
        self.indices = {str(row["chapterIdx"]): row for row in app.rows if "chapterIdx" in row}
        if show_list:
            self.select("mine")

    def select(self, section):
        self.section, self.items, self.cursor = section, [], (0, 0)
        self.selected, self.scroll = None, 0.0
        self.list_page()
        self.fetch()

    def chapter(self, item):
        return self.chapters.get(str(item.get("uid"))) or self.indices.get(str(item.get("idx")))

    def caption(self, item):
        row = self.chapter(item) or {}
        label = item.get("author") or row.get("title") or item.get("chapter") or ""
        value = item.get("content") or item.get("quote") or ("书签" if self.section == "bookmarks" else "书评详情")
        return "　".join(filter(None, (label, " ".join(value.split()))))

    def list_page(self):
        app = self.app
        app.clear()
        from pw3_page import Page
        self.page=page=Page(app)
        page.title("笔记与书评")
        page.footer([("‹ 返回",lambda:app.read(self.reading_row,self.index,self.loaded))])
        for i,(section,name) in enumerate(SECTIONS):
            page.button(name,lambda s=section:self.select(s),48+195*i,256,195,88,
                        outline=True,primary=section==self.section)
        page.label(app.book.get("title") or "",48,396,976,82,36,True)
        app.status=tk.StringVar()
        page.label("",48,1256,976,70,26,color="#555555").configure(textvariable=app.status)
        actions=[("新建划线",self.select_text),("在此加书签",self.bookmark)]
        if self.section=="thoughts":
            actions.append(("草稿",self.draft_list))
        actions.append(("加载更多",self.fetch))
        for i,(title,fn) in enumerate(actions):
            width=992/len(actions)
            self.more=page.button(title,fn,48+i*width,1154,width-16,88,outline=True)
        self.cards=[]
        self.draw_cards()
        self.count()

    def draw_cards(self):
        page=self.page
        for widget in self.cards:
            widget.destroy()
        self.cards=[]
        start=int(self.scroll)
        for i,item in enumerate(self.items[start:start+2]):
            y=520+i*326
            chapter=self.chapter(item) or {}
            name=item.get("author") or chapter.get("title") or item.get("chapter") or ""
            quote=item.get("content") or item.get("quote") or self.caption(item)
            stripe=page.line(48,y,5,"#555555",164)
            heading=page.label(name,84,y,920,58,26,color="#555555")
            text=page.label(quote,84,y+54,920,162,32,anchor="nw")
            text.configure(wraplength=round(910*page.factor),justify="left")
            def open_item(_,idx=start+i):
                self.selected=idx
                self.detail(self.items[idx])
            for widget in (heading,text,stripe):
                widget.bind("<ButtonRelease-1>",open_item)
                self.cards.append(widget)
        def turn(delta):
            self.scroll=int(self.scroll)+delta
            self.draw_cards()
        if start:
            self.cards.append(page.button("上一页",lambda:turn(-2),48,1050,200,88))
        if start+2<len(self.items):
            self.cards.append(page.button("下一页",lambda:turn(2),824,1050,200,88))
    def change(self, section, work):
        app = self.app
        app.clear()
        app.header("书签" if section == "bookmarks" else "我的划线")
        app.status_line()
        app.status.set("正在同步…")
        def failed(error):
            app.error(error)
            app.status.set(app.status.get() + " 请刷新列表核对结果。")
            app.button(app.frame, "刷新列表", lambda: self.select(section)).pack()
        app.submit(work, lambda _: self.select(section), failed)

    def bookmark(self):
        try:
            span, quote = SourceOffsets(self.loaded, self.blocks).bookmark(self.index)
        except ValueError as error:
            self.app.status.set(str(error))
            return
        self.change("bookmarks", lambda: self.client.add_mark(
            self.book, self.reading_row, self.version, span, quote, bookmark=True))

    def return_to_text(self):
        self.app.read(self.reading_row, self.index, self.loaded)

    def select_text(self, held=None):
        app = self.app
        if held is None:
            self.return_to_text()
        text = app.text
        app.system_bar(True)
        text.selecting_words = True
        app.activity.reading(False)
        controls = tk.Frame(text if app.kindle else app.frame, bd=1, relief="solid")
        if not app.kindle:
            controls.pack(side="bottom", fill="x", before=text)
        app.status.set("拖动选择正文")
        anchor = None
        dismiss = False
        handles = []
        def place_tools():
            selected = text.tag_ranges("sel")
            if not selected:
                controls.place(relx=.5, rely=1, anchor="s")
                return
            first = text.bbox(selected[0])
            last = text.bbox(str(selected[1]) + "-1c")
            for handle, box, right in zip(handles, (first, last), (False, True)):
                if box:
                    x, y, width, height = box
                    handle.place(x=x + (width if right else 0), y=y + height, anchor="nw" if right else "ne")
                    handle.lift()
                else:
                    handle.place_forget()
            visible = first or last
            if visible:
                width, height = controls.winfo_reqwidth(), controls.winfo_reqheight()
                x = max(0, (text.winfo_width() - width) // 2)
                edge = last or visible
                y = edge[1] + edge[3] + handles[0].winfo_reqheight()
                if y + height > text.winfo_height():
                    y = max(0, visible[1] - height - 5)
                controls.place(x=x, y=max(0, y))
                controls.lift()
        def highlight(first, last):
            text.tag_remove("sel", "1.0", "end")
            text.tag_add("sel", first, last)
            if app.kindle:
                place_tools()
        def char_at(event):
            return text.index(f"@{event.x},{event.y}")
        def press(event):
            nonlocal anchor, dismiss
            if app.kindle and text.tag_ranges("sel"):
                dismiss = True
                return "break"
            start = char_at(event)
            anchor = start, text.index(start + "+1c")
            return drag(event)
        def drag(event):
            if anchor is None or dismiss:
                return "break"
            end = char_at(event)
            first, last = anchor
            if text.compare(end, "<", first):
                first = end
            elif text.compare(end, ">=", last):
                last = end + "+1c"
            highlight(first, last)
            return "break"
        pointer_offset = (0, 0)
        def grab_handle(event, side):
            nonlocal pointer_offset
            edge = str(text.tag_ranges("sel")[side])
            box = text.bbox(edge + "-1c" if side else edge)
            if box:
                x, y, width, height = box
                pointer_offset = (event.x_root - text.winfo_rootx() - x - width//2,
                                  event.y_root - text.winfo_rooty() - y - height//2)
            return "break"
        def move_handle(event, side):
            first, end = map(str, text.tag_ranges("sel"))
            x = event.x_root - text.winfo_rootx() - pointer_offset[0]
            y = event.y_root - text.winfo_rooty() - pointer_offset[1]
            index = text.index(f"@{x},{y}")
            if side == 0 and text.compare(index, "<", end):
                highlight(index, end)
            elif side == 1 and text.compare(index, ">=", first):
                highlight(first, text.index(index + "+1c"))
            return "break"
        def selected():
            selection = text.tag_ranges("sel")
            word = text.get(*selection).strip() if selection else ""
            if not word:
                app.status.set("请先拖动选中一段正文。")
            return word
        def save(action="mark"):
            if not selected():
                return
            try:
                offsets = SourceOffsets(self.loaded, self.blocks)
                span, quote = offsets.selection(*map(str, text.tag_ranges("sel")))
            except ValueError as error:
                app.status.set(str(error))
                return
            if action == "passage":
                self.passage(self.reading_row["chapterUid"], span, quote, self.return_to_text)
            elif action == "write":
                uid = self.reading_row["chapterUid"]
                self.write_thought(uid, span, quote, self.return_to_text,
                                   lambda: self.passage(uid, span, quote, self.return_to_text))
            else:
                self.change("mine", lambda: self.client.add_mark(self.book, self.reading_row, self.version, span, quote))
        def lookup():
            word = selected()
            if word:
                self.dictionary(word)
        def copy():
            word = selected()
            if word:
                app.root.clipboard_clear()
                app.root.clipboard_append(word)
                app.status.set("已复制到剪贴板")
        def search():
            word = selected()
            if word:
                app.search_book(initial=word, back=self.return_to_text)
        def cancel(_=None):
            self.return_to_text()
            return "break"
        actions = (("取消", cancel), ("词典", lookup), ("复制", copy), ("搜全书", search),
                   ("保存划线", save), ("写想法", lambda: save("write")), ("段落想法", lambda: save("passage")))
        if app.kindle:
            actions = (("复制", copy), ("查词", lookup), ("搜全书", search), ("划线", save),
                       ("写想法", lambda: save("write")), ("段落想法", lambda: save("passage")))
            for side in (0, 1):
                handle = tk.Label(text, text="●", padx=4, pady=0, cursor="hand2")
                handle.bind("<ButtonPress-1>", lambda e, s=side: grab_handle(e, s))
                handle.bind("<B1-Motion>", lambda e, s=side: move_handle(e, s))
                handles.append(handle)
            if held is None:
                actions += (("取消", cancel),)
        buttons = [app.button(controls, title, action) for title, action in actions]
        if app.kindle:
            for col in range(4):
                controls.columnconfigure(col, weight=1, uniform="action")
            for i, button in enumerate(buttons):
                width = 2 if i in (4, 5) else (4 if i == 6 else 1)
                row, col = (0, i) if i < 4 else ((1, (i-4)*2) if i < 6 else (2, 0))
                button.configure(font=("Noto Sans CJK SC", -28), padx=0, pady=0)
                controls.rowconfigure(row, minsize=88)
                button.grid(row=row, column=col, columnspan=width, sticky="nsew")
            controls.configure(width=max(1, min(976, text.winfo_width()-24)),
                               height=90*(2 if held is not None else 3))
            controls.grid_propagate(False)
        else:
            cols = len(buttons) if sum(b.winfo_reqwidth() for b in buttons) <= text.winfo_width() else 4
            for i, button in enumerate(buttons):
                controls.columnconfigure(i % cols, weight=1)
                button.grid(row=i // cols, column=i % cols, sticky="ew")
        text.configure(exportselection=False, selectbackground="#dddddd", selectforeground=INK,
                       inactiveselectbackground="#dddddd")
        text.bind("<ButtonPress-1>", press)
        text.bind("<B1-Motion>", drag)
        text.bind("<ButtonRelease-1>", lambda e: cancel() if dismiss else drag(e))
        text.bind("<Escape>", cancel)
        text.bind("<Return>", lambda _: save() or "break")
        text.update_idletasks()
        text.yview(self.index)
        if held is not None:
            letter = text.get(held, held + "+1c")
            if letter.isascii() and letter.isalnum():
                anchor = text.index(held + " wordstart"), text.index(held + " wordend")
                # Tk groups adjacent Latin and Chinese letters into one word.
                # Keep a long-pressed English word inside that ASCII run.
                before = text.get(anchor[0], held)
                after = text.get(held, anchor[1])
                letters = ascii_letters + digits + "_"
                left = len(before) - len(before.rstrip(letters))
                right = len(after) - len(after.lstrip(letters))
                anchor = text.index(f"{held}-{left}c"), text.index(f"{held}+{right}c")
            elif app.kindle and "\u3400" <= letter <= "\u9fff":
                anchor = chinese_word_bounds(text, held)
            else:
                anchor = held, text.index(held + "+1c")
            highlight(*anchor)
        elif app.kindle:
            place_tools()

    def dictionary(self, word):
        app = self.app
        app.clear()
        page = Page(app)
        page.title("词典")
        page.label(word, 48, 292, 976, 112, 44, True)
        page.line(48, 515, 976)
        page.label("释义", 48, 565, 976, 92, 36, True)
        body = tk.Text(page.frame, wrap="char", relief="flat", bd=0, highlightthickness=0,
                       state="disabled", bg="white", font=page.font(32))
        page.put(body, 48, 678, 976, 465)
        page.footer([("‹ 返回", self.return_to_text), ("上一页", lambda: body.yview_scroll(-1, "pages")),
                     ("下一页", lambda: body.yview_scroll(1, "pages"))])
        app.status = tk.StringVar()
        page.label("", 48, 1170, 732, 100, 28, color=SECONDARY).configure(textvariable=app.status)
        def fetch():
            retry.place_forget()
            app.status.set("正在查询 " + word)
            def display(lines):
                app.status.set("" if lines else "无查询结果")
                body.configure(state="normal")
                body.delete("1.0", "end")
                body.insert("1.0", "\n\n".join(lines))
                body.configure(state="disabled")
            def failed(error):
                app.error(error)
                page.put(retry, 806, 1170, 218, 88)
            app.submit(lambda: self.client.dictionary(word), display, failed)
        retry = page.button("重试", fetch, 806, 1170, 218, 88, outline=True)
        fetch()

    def count(self):
        self.more.configure(text="加载更多", state="normal" if self.cursor else "disabled")
        self.app.status.set(f"{len(self.items)} 条" if self.items else "暂无记录")

    def fetch(self):
        if self.cursor is None:
            return
        section, cursor = self.section, self.cursor
        self.more.configure(state="disabled")
        self.app.status.set("正在加载…")
        def loaded(response):
            items, following = response
            seen = {item["id"] for item in self.items}
            for item in items:
                if item["id"] not in seen:
                    self.items.append(item)
                    seen.add(item["id"])
            self.cursor = following
            self.draw_cards()
            self.count()
        def failed(error):
            self.app.error(error)
            self.more.configure(text="重试", state="normal")
        self.app.submit(lambda: self.client.notes_page(self.book, section, *cursor), loaded, failed)

    def text_box(self, parent=None):
        frame = tk.Frame(parent or self.app.frame)
        frame.pack(fill="both", expand=True)
        text = tk.Text(frame, wrap="char", height=4, borderwidth=0, padx=6, pady=6,
                       highlightthickness=1, highlightbackground="#777777", highlightcolor="#777777")
        scroll = tk.Scrollbar(frame, command=text.yview)
        scroll.pack(side="right", fill="y")
        text.configure(yscrollcommand=scroll.set)
        text.pack(fill="both", expand=True)
        return text

    def flat_button(self, parent, page, text, command, size=28, outline=True, state="normal"):
        return tk.Button(parent, text=text, command=command, font=page.font(size), bd=0, relief="flat",
                         overrelief="flat", bg="white", fg=INK, activebackground="#eeeeee",
                         activeforeground=INK, disabledforeground="#888888", state=state,
                         highlightthickness=round(2 * page.factor) if outline else 0,
                         highlightbackground=INK, highlightcolor=INK, padx=0, pady=round(22 * page.factor))

    def fill_actions(self, row, page, items):
        for child in row.winfo_children():
            child.destroy()
        for col in range(row.grid_size()[0]):
            row.columnconfigure(col, weight=0, uniform="")
        row.rowconfigure(0, weight=1)
        for i, (label, command) in enumerate(items):
            row.columnconfigure(i, weight=1, uniform="actions")
            btn = self.flat_button(row, page, label, command)
            btn.grid(row=0, column=i, sticky="nsew", padx=(round(18 * page.factor) if i else 0, 0))

    def quote_box(self, parent, page, caption, quote):
        box = tk.Frame(parent, bg="white")
        box.pack(fill="x")
        tk.Frame(box, bg=SECONDARY, width=round(5 * page.factor)).pack(side="left", fill="y")
        column = tk.Frame(box, bg="white")
        column.pack(side="left", fill="x", expand=True, padx=(round(36 * page.factor), 0))
        if caption:
            tk.Label(column, text=caption, font=page.font(26), fg=SECONDARY, bg="white", anchor="w",
                    justify="left").pack(fill="x", pady=(round(10 * page.factor), round(4 * page.factor)))
        tk.Label(column, text=" ".join(quote.split()), font=page.font(32), fg=INK, bg="white", anchor="w",
                 justify="left", wraplength=round(880 * page.factor)).pack(
            fill="x", pady=(0, round(10 * page.factor)))
        return box

    def fixed_quote(self, page, caption, quote, y, height):
        page.line(48, y, 5, SECONDARY, height)
        page.label(caption, 84, y, 940, 56, 26, color=SECONDARY)
        excerpt = tk.Text(page.frame, wrap="char", bd=0, highlightthickness=0,
                          font=page.font(32), bg="white", fg=INK)
        excerpt.insert("1.0", quote)
        excerpt.configure(state="disabled")
        page.put(excerpt, 84, y+62, 940, height-62)
        return excerpt

    def list_row(self, parent, page, heading, caption, right, command=None, embed=False):
        row = tk.Frame(parent, bg="white", cursor="hand2" if command else "arrow")
        if not embed:
            row.pack(fill="x")
        tk.Label(row, text=heading, font=page.font(36), fg=INK, bg="white", anchor="w", justify="left",
                 wraplength=round(900 * page.factor)).pack(fill="x", pady=(20, 4))
        bottom = tk.Frame(row, bg="white")
        bottom.pack(fill="x", pady=(0, 20))
        tk.Label(bottom, text=right, font=page.font(28), fg=SECONDARY, bg="white", anchor="e").pack(side="right")
        tk.Label(bottom, text=caption, font=page.font(26), fg=SECONDARY, bg="white", anchor="w", justify="left",
                 wraplength=round(760 * page.factor)).pack(side="left", fill="x", expand=True)
        tk.Frame(row, bg="#cccccc", height=round(2 * page.factor)).pack(fill="x")
        if command:
            def bind_tree(widget):
                widget.bind("<ButtonRelease-1>", lambda _e: command())
                for child in widget.winfo_children():
                    bind_tree(child)
            bind_tree(row)
        return row

    @staticmethod
    def draft_key(draft):
        if draft["kind"] == "new":
            return "new:{}:{}".format(draft["uid"], draft["range"])
        return "{}:{}:{}".format(draft["kind"], draft["review"], draft.get("comment") or "")

    def drafts(self):
        return self.app.store.get(self.account, "review-drafts", self.book, {})

    def save_draft(self, key, draft):
        values = self.drafts()
        if draft is None:
            values.pop(key, None)
        else:
            values[key] = draft
        self.app.store.put(self.account, "review-drafts", self.book, values)

    def draft_list(self):
        app = self.app
        app.clear()
        page = Page(app)
        page.title("草稿")
        page.footer([("‹ 返回", lambda: self.select("thoughts"))])
        page.label("本书草稿", 48, 305, 976, 108, 36, True)
        drafts = list(self.drafts().values())
        names = {"new": "想法", "edit": "编辑想法", "reply": "回复"}
        if not drafts:
            page.label("这本书没有草稿", 48, 470, 976, 90, 28, color=SECONDARY)
            return
        first = min(getattr(self, "draft_offset", 0), ((len(drafts)-1)//5)*5)
        for i, draft in enumerate(drafts[first:first+5]):
            y = 438 + i*156
            snippet = " ".join((draft.get("content") or draft.get("quote") or "").split()) or "（空草稿）"
            open_draft = lambda d=draft: self.compose(d, self.draft_list)
            page.button(snippet, open_draft, 48, y, 862, 92, 36, anchor="w")
            page.button(names[draft["kind"]], open_draft, 48, y+92, 862, 58, 28, anchor="w")
            page.button("›", open_draft, 910, y, 114, 152, 28, anchor="e")
            page.line(48, y+152, 976, "#cccccc")
        if len(drafts) > 5:
            def turn(delta):
                self.draft_offset = first + delta
                self.draft_list()
            nav = page.footer([("‹ 返回", lambda: self.select("thoughts")),
                               ("上一页", lambda: turn(-5)), ("下一页", lambda: turn(5))])
            nav["上一页"].configure(state="normal" if first else "disabled")
            nav["下一页"].configure(state="normal" if first+5 < len(drafts) else "disabled")

    def choose_visibility(self, draft, key, resume):
        app = self.app
        app.clear()
        page = Page(app)
        page.title("想法可见范围")
        page.footer([("‹ 返回", resume)])
        page.label("可见范围", 48, 292, 976, 110, 36, True)
        current = draft.get("scope", "isPrivate")
        for i, (value, label) in enumerate(reviews.VISIBILITY):
            y = 446 + 120*i
            choose = lambda v=value: self.set_visibility(draft, key, v, resume)
            page.button(label, choose, 48, y, 746, 116, 36, anchor="w")
            page.button("已选" if value == current else "", choose, 794, y, 230, 116, 28, anchor="e")
            page.line(48, y+116, 976, "#cccccc")

    def set_visibility(self, draft, key, value, resume):
        draft["scope"] = value
        self.save_draft(key, draft)
        resume()

    def compose(self, initial, back, on_saved=None):
        app = self.app
        key = self.draft_key(initial)
        draft = dict(self.drafts().get(key, initial))
        app.clear()
        kind = draft["kind"]
        page = Page(app)
        page.title({"new": "写想法", "edit": "编辑想法", "reply": "写回复"}[kind])
        busy, retired = False, False
        if kind == "reply":
            caption = "回复" + (draft.get("target_name") or "")
        else:
            row = self.chapters.get(str(draft.get("uid")))
            caption = " · ".join(filter(None, (app.book.get("title") or "", (row or {}).get("title") or "")))
        if draft.get("quote"):
            self.fixed_quote(page, caption, draft["quote"], 275, 176)
        page.label("回复内容" if kind == "reply" else "我的想法", 48, 491, 976, 100, 36, True)
        editor_box = tk.Frame(page.frame, bg="white")
        page.put(editor_box, 48, 624, 976, 376)
        editor = self.text_box(editor_box)
        editor.configure(font=page.font(32))
        editor.insert("1.0", draft["content"])
        editor.mark_set("insert", draft.get("cursor", "end-1c"))
        editor.see("insert")
        editor.edit_modified(False)
        app.touch_input(editor)
        def store():
            if retired:
                return
            draft["cursor"] = editor.index("insert")
            draft["content"] = editor.get("1.0", "end-1c")
            if draft["content"] or draft.get("pending"):
                self.save_draft(key, draft)
            else:
                self.save_draft(key, None)
        def changed(_=None):
            if not retired and editor.edit_modified():
                editor.edit_modified(False)
                store()
        editor.bind("<<Modified>>", changed)
        if kind != "reply":
            scope_row = page.button("可见范围", lambda: open_visibility(), 48, 1018, 470, 106, 36, anchor="w")
            scope_value = page.button("", lambda: open_visibility(), 518, 1018, 506, 106, 28, anchor="e")
            page.line(48, 1126, 976, "#cccccc")
            def refresh_scope():
                scope_value.configure(text=dict(reviews.VISIBILITY).get(draft.get("scope"), "") + "　›")
            def open_visibility(_e=None):
                if busy:
                    return
                store()
                self.choose_visibility(draft, key, lambda: self.compose(dict(draft), back, on_saved))
            refresh_scope()
        def leave():
            if not busy:
                store()
                back()
        def discard():
            nonlocal retired
            retired = True
            self.save_draft(key, None)
            back()
        discard_button = page.button("放弃草稿", lambda: app.confirm_action(
            "放弃这份草稿？", "放弃后，本次未发送的文字将被清除。", "放弃草稿", discard, None), 48, 1169, 976, 88, outline=True)
        def submit():
            nonlocal busy
            if busy:
                return
            store()
            if not draft["content"].strip():
                app.status.set("请先输入内容。")
                return
            busy = True
            draft["pending"] = True
            self.save_draft(key, draft)
            send_button.configure(state="disabled")
            discard_button.configure(state="disabled")
            editor.configure(state="disabled")
            snapshot = dict(draft)
            app.status.set("正在发送…")
            def saved(_):
                nonlocal retired
                retired = True
                self.save_draft(key, None)
                if on_saved:
                    on_saved()
                elif kind == "reply":
                    back()
                else:
                    self.select("thoughts")
            def failed(error):
                nonlocal busy
                busy = False
                editor.configure(state="normal")
                app.error(error)
                app.status.set(app.status.get() + " 草稿已保留，请先核对是否已发送。")
                send_button.configure(text="核对后重发", state="normal")
                discard_button.configure(state="normal")
            app.submit(lambda: reviews.send(self.client, self.book, snapshot), saved, failed)
        send_label = "核对后重发" if draft.get("pending") else "发送"
        footer = page.footer([("‹ 返回", leave), (send_label, submit)])
        send_button = footer[send_label]
        app.status = tk.StringVar()
        page.label("", 48, 1265, 976, 76, 26, color=SECONDARY).configure(textvariable=app.status)
        app.status.set("上次发送结果待核对" if draft.get("pending") else "")

    def write_thought(self, uid, span, quote, back, on_saved=None):
        draft = {"kind": "new", "uid": int(uid), "version": self.version or 0,
                 "quote": quote, "range": span, "scope": "isPrivate", "content": ""}
        self.compose(draft, back, on_saved)

    def passage(self, uid, span, quote, back):
        items = []
        following = 0
        scroll = 0.0
        def show():
            app = self.app
            app.clear()
            page = Page(app)
            page.title("这段文字的想法")
            page.footer([("‹ 返回", back)])
            chapter_row = self.chapters.get(str(uid)) or {}
            self.fixed_quote(page, chapter_row.get("title") or "", quote, 270, 196)
            page.label("这段文字的评论", 48, 530, 976, 100, 36, True)
            feed_box = tk.Frame(page.frame, bg="white")
            page.put(feed_box, 48, 648, 976, 464)
            text = self.text_box(feed_box)
            text.configure(highlightthickness=0, padx=0)
            def fit_rows(_event=None):
                for embedded in text.winfo_children():
                    embedded.configure(width=max(1, text.winfo_width()-4))
            text.bind("<Configure>", fit_rows)
            more = page.button("加载更多", lambda: fetch(), 48, 1150, 480, 88, outline=True)
            page.button("写想法", lambda: self.write_thought(
                uid, span, quote, show, lambda: self.passage(uid, span, quote, back)),
                544, 1150, 480, 88, primary=True)
            app.status = tk.StringVar()
            page.label("", 48, 1256, 976, 70, 26, color=SECONDARY).configure(textvariable=app.status)
            def open_detail(entry):
                nonlocal scroll
                scroll = text.yview()[0]
                self.detail(entry, "passage", show)
            def render():
                text.configure(state="normal")
                text.delete("1.0", "end")
                for entry in items:
                    widget = self.list_row(text, page, entry.get("author") or "读者",
                                          " ".join((entry.get("content") or "").split()), "›",
                                          lambda e=entry: open_detail(e), embed=True)
                    widget.configure(width=max(1, text.winfo_width()-4), height=round(144*page.factor))
                    widget.pack_propagate(False)
                    text.window_create("end", window=widget)
                    text.insert("end", "\n")
                text.configure(state="disabled")
                text.yview_moveto(scroll)
            def count():
                app.status.set("" if items else "这段文字暂无可见想法")
                more.configure(text="加载更多", state="normal" if following is not None else "disabled")
            def fetch():
                nonlocal following
                if following is None:
                    return
                start = following
                app.status.set("正在读取这段文字的想法…")
                more.configure(state="disabled")
                def loaded(result):
                    nonlocal following
                    rows, following = result
                    seen = {entry["id"] for entry in items}
                    for entry in rows:
                        if entry["id"] not in seen:
                            items.append(entry)
                            seen.add(entry["id"])
                    render()
                    count()
                def failed(error):
                    app.error(error)
                    more.configure(text="重试", state="normal")
                app.submit(lambda: reviews.passage_page(self.client, self.book, uid, span, start), loaded, failed)
            render()
            if not items and following is not None:
                fetch()
            else:
                count()
        show()

    def detail(self, item, section=None, back=None):
        app = self.app
        app.clear()
        section = section or self.section
        back = back or self.list_page
        def reopen():
            self.detail(item, section, back)
        page = Page(app)
        page.title({"reviews": "书评详情", "bookmarks": "书签详情"}.get(
            section, "划线详情" if section in ("mine", "popular") else "想法详情"))
        page.footer([("‹ 返回", back)])
        row = self.chapter(item)
        caption = " · ".join(filter(None, (app.book.get("title") or "", (row or {}).get("title") or "")))
        excerpt = self.fixed_quote(page, caption, item.get("quote") or "", 274, 196)
        heading = page.label("", 48, 544, 976, 100, 36, True)
        heading.configure(text={"mine": "我的划线", "bookmarks": "我的书签", "popular": "热门划线"}
                          .get(section, item.get("author") or "读者"))
        body_frame = tk.Frame(page.frame, bg="white")
        page.put(body_frame, 48, 660, 976, 265)
        body = tk.Text(body_frame, wrap="char", font=page.font(32), bg="white", fg=INK,
                       bd=0, highlightthickness=0)
        scroll = tk.Scrollbar(body_frame, command=body.yview)
        def scroll_state(first, last):
            scroll.set(first, last)
            if float(first) > 0 or float(last) < 1:
                scroll.pack(side="right", fill="y", before=body)
            else:
                scroll.pack_forget()
        body.configure(yscrollcommand=scroll_state)
        body.pack(side="left", fill="both", expand=True)
        actions_row = tk.Frame(page.frame, bg="white")
        page.put(actions_row, 48, 946, 976, 96)
        app.status = tk.StringVar()
        page.label("", 48, 1256, 976, 70, 26, color=SECONDARY).configure(textvariable=app.status)
        review = section in ("thoughts", "reviews", "passage")
        locate, extra = {}, {}
        def go_locate():
            call = locate.get("call")
            if call:
                call()
        def rebuild():
            entries = []
            if locate.get("call"):
                entries.append(("看原文", go_locate))
            if review:
                entries.append(("回复", lambda: self.replies(item, back=reopen)))
            elif section in ("mine", "popular") and item.get("uid") is not None and item.get("range"):
                entries.append(("这段文字的想法",
                               lambda: self.passage(item["uid"], item["range"], item["quote"], reopen)))
            for extra_key in ("like", "edit", "delete", "retry"):
                if extra_key in extra:
                    entries.append(extra[extra_key])
            self.fill_actions(actions_row, page, entries)
        def confirm_remove_mark():
            noun = "划线" if section == "mine" else "书签"
            app.confirm_action(f"删除这条{noun}？", "删除后，正文和笔记列表将不再显示这条划线。" if section == "mine" else "删除后，这条书签会从本书移除。", f"删除这条{noun}",
                               lambda: self.change(section, lambda: self.client.remove_mark(item["mark_id"])), None)
        def display(detail):
            author = (detail.get("author") or {}).get("name") or item.get("author")
            if section in ("thoughts", "reviews", "passage"):
                heading.configure(text=author or "读者")
            quote = detail.get("abstract") or item.get("quote")
            content_text = detail.get("content") or item.get("content")
            excerpt.configure(state="normal")
            excerpt.delete("1.0", "end")
            excerpt.insert("1.0", quote or "")
            excerpt.configure(state="disabled")
            parts = [content_text] if content_text and content_text != quote else []
            if item.get("votes"):
                parts.append(f'{item["votes"]} 人划线')
            body.configure(state="normal")
            body.delete("1.0", "end")
            body.insert("1.0", "\n\n".join(parts))
            body.configure(state="disabled")
            if row and section == "bookmarks" and str(item.get("range", "")).split("-")[0].isdigit():
                offset = int(str(item["range"]).split("-")[0])
                locate["call"] = lambda: app.read(row, source_offset=offset)
            elif row and quote:
                locate["call"] = lambda: app.read(row, hit={"abstract": quote, "keyword": [quote],
                                                           "range": detail.get("range") or item.get("range")})
            if section in ("mine", "bookmarks") and item.get("mark_id"):
                extra["delete"] = ("删除", confirm_remove_mark)
            rebuild()
        display({})
        if review:
            def loaded(detail):
                display(detail)
                if detail.get("isLike") in (0, 1, "0", "1"):
                    def show_like(state):
                        extra["like"] = ("取消点赞" if state else "点赞", lambda: set_like(not state))
                        rebuild()
                    def set_like(desired):
                        extra["like"] = ("正在更新…", lambda: None)
                        rebuild()
                        app.submit(lambda: reviews.set_like(self.client, item["id"], desired), show_like, unknown)
                    def unknown(error):
                        app.error(error)
                        extra["like"] = ("核对点赞状态", reload_like)
                        rebuild()
                    def reload_like():
                        extra["like"] = ("正在核对…", lambda: None)
                        rebuild()
                        app.submit(lambda: reviews.like_state(self.client.review_detail(item["id"])),
                                  show_like, unknown)
                    show_like(reviews.like_state(detail))
                if reviews.own_thought(self.client, self.book, item["id"], detail):
                    heading.configure(text="我的想法")
                    source = detail.get("content", "")
                    scope = reviews.visibility(detail)
                    draft = {"kind": "edit", "review": item["id"], "original": source, "original_scope": scope,
                             "content": source, "scope": scope, "quote": detail.get("abstract") or "",
                             "uid": item.get("uid") or detail.get("chapterUid")}
                    def confirm_delete():
                        app.confirm_action("删除这条想法？", "删除后，这条想法将从书中移除。", "删除想法",
                                           deleting, None)
                    def deleting():
                        extra["delete"] = ("正在删除…", lambda: None)
                        rebuild()
                        def refreshed(_):
                            self.save_draft(self.draft_key(draft), None)
                            self.select("thoughts")
                        def failed(error):
                            app.error(error)
                            extra["delete"] = ("刷新详情", reopen)
                            rebuild()
                        app.submit(lambda: reviews.remove(self.client, self.book, draft), refreshed, failed)
                    extra["edit"] = ("编辑", lambda: self.compose(draft, reopen))
                    extra["delete"] = ("删除", confirm_delete)
                    rebuild()
            def failed(error):
                app.error(error)
                extra["retry"] = ("重试", reopen)
                rebuild()
            app.submit(lambda: self.client.review_detail(item["id"]), loaded, failed)

    def replies(self, item, parent=None, back=None):
        app = self.app
        app.clear()
        page = Page(app)
        page.title("跟帖" if parent else "回复与跟帖")
        page.footer([("‹ 返回", back or (lambda: self.detail(item)))])
        content = tk.Frame(page.frame, bg="white")
        page.put(content, 48, 226, 976, 1128)
        self.quote_box(content, page, item.get("author") or "读者", item.get("content") or item.get("quote") or "")
        tk.Label(content, text="跟帖" if parent else "回复", font=page.font(36, True), fg=INK, bg="white",
                 anchor="w").pack(fill="x", pady=(32, 12))
        feed_box = tk.Frame(content, bg="white", height=round(480 * page.factor))
        feed_box.pack(fill="x")
        feed_box.pack_propagate(False)
        text = self.text_box(feed_box)
        def write(comment=None, recipient=None, name=None):
            draft = {"kind": "reply", "review": item["id"], "comment": comment, "recipient": recipient,
                     "parent": parent, "content": "", "quote": item.get("content") or item.get("quote") or "",
                     "target_name": name or item.get("author") or ""}
            self.compose(draft, lambda: self.replies(item, parent, back))
        buttons = tk.Frame(content, bg="white")
        buttons.pack(fill="x", pady=(24, 0))
        buttons.columnconfigure(0, weight=1)
        buttons.columnconfigure(1, weight=1)
        more = self.flat_button(buttons, page, "加载更多", lambda: fetch())
        more.grid(row=0, column=0, sticky="ew")
        write_btn = self.flat_button(buttons, page, "写回复", lambda: write(parent))
        write_btn.grid(row=0, column=1, sticky="ew", padx=(round(18 * page.factor), 0))
        app.status = tk.StringVar()
        page.label("", 48, 1256, 976, 70, 26, color=SECONDARY).configure(textvariable=app.status)
        shown, offset = set(), 0
        def render(rows_appended):
            text.configure(state="normal")
            for entry in rows_appended:
                author = (entry.get("author") or {}).get("name") or "读者"
                target = (entry.get("replyUser") or {}).get("name")
                recipient = entry.get("userVid") or (entry.get("author") or {}).get("userVid")
                key = entry.get("commentId")
                heading = author + (" 回复 " + target if target else "")
                if not parent and (entry.get("subComments") or entry.get("subCommentsCount")):
                    right = "查看跟帖　›"
                    command = lambda k=key: self.replies(item, k, lambda: self.replies(item, back=back))
                else:
                    right = "回复　›"
                    command = lambda k=key, who=recipient, nm=author: write(k, who, nm)
                widget = self.list_row(text, page, heading, entry.get("content", ""), right, command, embed=True)
                text.window_create("end", window=widget)
                text.insert("end", "\n")
            text.configure(state="disabled")
        def count():
            app.status.set(f"{len(shown)} 条回复" if shown else "暂无回复")
            more.configure(text="加载更多", state="normal" if offset is not None else "disabled")
        def fetch():
            nonlocal offset
            start = offset
            more.configure(state="disabled")
            app.status.set("正在加载回复…")
            def loaded(result):
                nonlocal offset
                rows, offset = result
                fresh = []
                for row in rows:
                    key = row.get("commentId")
                    if key and key not in shown:
                        shown.add(key)
                        fresh.append(row)
                render(fresh)
                count()
            def failed(error):
                app.error(error)
                more.configure(text="重试", state="normal")
            app.submit(lambda: self.client.review_replies(item["id"], parent or "", start), loaded, failed)
        fetch()
