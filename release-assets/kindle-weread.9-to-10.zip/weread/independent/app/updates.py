"""Version history and Kindle updates for the independent reader channel."""
import json
import os
import queue
import re
import sys
import tkinter as tk
from pathlib import Path
from urllib.request import Request, urlopen

HERE = Path(__file__).resolve().parent
if (HERE.parent / "kindle/update.py").is_file():
    sys.path.append(str(HERE.parent / "kindle"))
import update


PREFIX = "weread/independent/"
ASSET = "kindle-weread.zip"
TAG = re.compile(r"v0\.([0-9]{2,8})(?:-(beta|rc)\.([1-9][0-9]*))?")
REQUIRED = ("run.sh", "app/app.py", "app/updates.py", "app/update.py", "app/version_history.tsv",
            "bin/python3", "runtime/lib/ld-musl-armhf.so.1")


def layout():
    return update.InstallLayout(Path(os.environ.get("WR_APP_ROOT", HERE.parent)), Path("/mnt/us/weread/independent-updates"),
                                PREFIX, REQUIRED, Path("/tmp/weread-independent-update.lock"))


def local_history():
    rows = []
    for line in (HERE / "version_history.tsv").read_text(encoding="utf-8").splitlines():
        number, title, description = line.split("\t", 2)
        rows.append((int(number), title, description))
    return rows[:3]


def fetch_releases(current, include_beta=False):
    rows = {}
    page = 1
    while True:
        request = Request(f"https://api.github.com/repos/{update.REPO}/releases?per_page=100&page={page}",
                          headers={"User-Agent": "Kindle-WeRead", "Accept": "application/vnd.github+json"})
        with urlopen(request, timeout=15) as response:
            releases = json.load(response)
        if not isinstance(releases, list):
            raise ValueError("GitHub 未返回发行列表")
        for release in releases:
            tag = release["tag_name"]
            match = TAG.fullmatch(tag)
            if not match or release["draft"]:
                continue
            preview = release["prerelease"]
            if (preview and not include_beta) or (match[2] and not preview):
                continue
            revision = int(match[1])
            if revision < 1 or version(revision) != tag.split("-", 1)[0]:
                continue
            prefix = f"https://github.com/{update.REPO}/releases/download/{tag}/"
            assets = {a["name"]: a for a in release["assets"]
                      if a["state"] == "uploaded" and a["browser_download_url"] == prefix + a["name"]}
            full = assets.get(ASSET)
            if not full or not full["size"]:
                continue
            delta = assets.get(f"kindle-weread.{current}-to-{revision}.zip")
            if delta and not 0 < delta["size"] < full["size"]:
                delta = None
            rank = (not preview, match[2] == "rc", int(match[3] or 0))
            if revision not in rows or rank > rows[revision][0]:
                rows[revision] = (rank, (revision, release.get("name") or tag, release.get("body") or "", full, delta))
        if len(releases) < 100:
            break
        page += 1
    return [rows[rev][1] for rev in sorted(rows, reverse=True)[:3]]


def version(revision):
    return f"v0.{revision:02d}"


def release_label(revision, full):
    parts = full.get("browser_download_url", "").split("/")
    return parts[-2] if len(parts) > 1 and TAG.fullmatch(parts[-2]) else version(revision)


class VersionDetails:
    def __init__(self, app):
        self.app = app
        self.history = local_history()
        self.current = self.history[0][0]
        self.include_beta = tk.BooleanVar(master=app.root, value=bool(app.store.get("", "accept-beta-updates", default=False)))
        self.online = []
        self.future = self.target = self.ready = None
        self.events = queue.SimpleQueue()
        self.message = ""
        self.progress = None
        self.view = None
        self.page = None
        self.view_mode = None
        self.prompt = None
        self.back = app.profile
        if app.kindle:
            current_layout = layout()
            self.current = int((current_layout.app / "revision").read_text())
            if current_layout.store.exists():
                # A previous session may already have staged the next launch.
                for path in current_layout.store.iterdir():
                    if path.name.isascii() and path.name.isdecimal() and int(path.name) > self.current:
                        if update.installed(path, int(path.name), REQUIRED):
                            self.ready = max(self.ready or 0, int(path.name))

    def simple_mode(self):
        # Matches 43a: once a Kindle install is staged and ready to download,
        # the page drops the version/beta/history sections for a focused prompt.
        return bool(self.app.kindle and self.target and not self.ready)

    def show(self, back=None):
        app = self.app
        if back is not None:
            self.back = back
        app.clear()
        from pw3_page import Page
        page = self.page = Page(app)
        self.view = page.frame
        self.view_mode = "simple" if self.simple_mode() else "full"
        page.footer([("‹ 返回", self.back)])
        if self.view_mode == "simple":
            page.title("版本更新·可安装")
            page.label("有可用更新", 48, 300, 976, 70, 36, True)
            self.status_label = page.label("", 48, 390, 976, 300, 32)
            self.status_label.configure(wraplength=round(976*page.factor), justify="left")
            self.bar = tk.Canvas(page.frame, height=round(9*page.factor), bd=0, highlightthickness=0, bg="#ddd")
            self.bar.bind("<Configure>", lambda _: self.draw_bar())
            self.bar_box = (48, 700, 976, 10)
            self.channel = self.body = None
            self.action = page.button("下载并安装", self.install, 49, 937, 974, 86, primary=True)
        else:
            page.title("版本详情与更新")
            self.action = page.button("检查更新", self.check, 794, 118, 230, 88, anchor="e")
            tag = self.history[0][1].split()[0]
            installed_tag = tag if TAG.fullmatch(tag) and tag.split("-")[0] == version(self.current) else version(self.current)
            page.label("当前版本", 48, 320, 500, 70, 36, True)
            page.label(installed_tag, 48, 400, 976, 90, 52, True)
            self.channel = tk.Checkbutton(page.frame, text="接收 Beta 版本", variable=self.include_beta,
                                          anchor="w", command=self.change_channel, font=page.font(36),
                                          bd=0, highlightthickness=0, bg="white")
            page.put(self.channel, 48, 560, 880, 90)
            page.line(48, 670, 976, "#cccccc")
            page.label("更新历史", 48, 710, 400, 70, 36, True)
            self.body = tk.Text(page.frame, wrap="word", relief="flat", bd=0, font=page.font(28))
            scroll = tk.Scrollbar(page.frame, command=self.body.yview)
            self.body.configure(yscrollcommand=scroll.set, state="disabled")
            page.put(self.body, 48, 780, 928, 360)
            page.put(scroll, 984, 780, 40, 360)
            self.status_label = page.label("", 48, 1170, 976, 60, 26, color="#555555")
            self.bar = tk.Canvas(page.frame, height=round(9*page.factor), bd=0, highlightthickness=0, bg="#ddd")
            self.bar.bind("<Configure>", lambda _: self.draw_bar())
            self.bar_box = (48, 1150, 976, 10)
            self.render_history()
        self.refresh()

    def render_history(self):
        if self.body is None:
            return
        entries = {row[0]: row[1:3] for row in self.history}
        entries.update({row[0]: row[1:3] for row in self.online})
        self.body.tag_configure("heading", font=self.page.font(32, True))
        self.body.tag_configure("desc", font=self.page.font(24), foreground="#555555")
        self.body.configure(state="normal")
        self.body.delete("1.0", "end")
        for rev in sorted(entries, reverse=True)[:3]:
            title, text = entries[rev]
            tag = version(rev)
            heading = title if title == tag or title.startswith((tag + " ", tag + "-")) else f"{tag}　{title}"
            if self.body.index("end-1c") != "1.0":
                self.body.insert("end", "\n\n")
            self.body.insert("end", heading + "\n", "heading")
            self.body.insert("end", text.strip(), "desc")
        self.body.configure(state="disabled")

    def visible(self):
        return self.view is not None and self.view.winfo_exists()

    def draw_bar(self):
        if self.progress is not None and self.bar.winfo_exists():
            self.bar.delete("all")
            self.bar.create_rectangle(0, 0, self.bar.winfo_width() * self.progress / 100, self.bar.winfo_height(),
                                      width=0, fill="#202020")

    def refresh(self):
        if not self.visible():
            return
        if self.prompt and self.prompt.winfo_exists():
            return  # Don't rebuild the page under an open exit confirmation.
        if self.simple_mode() != (self.view_mode == "simple"):
            self.show()
            return
        self.status_label.configure(text=self.message)
        if self.progress is None:
            self.bar.place_forget()
        else:
            self.page.put(self.bar, *self.bar_box)
            self.draw_bar()
        if self.view_mode == "simple":
            self.action.configure(text="下载并安装", command=self.install,
                                  state="disabled" if self.future else "normal")
        else:
            title, action = "检查更新", self.check
            if self.ready:
                title, action = "新版已安装", self.ask_exit
            elif self.target and not self.app.kindle:
                pass  # Desktop preview: no install action, "检查更新" stays available.
            self.action.configure(text=title, command=action, state="disabled" if self.future else "normal")
            if self.channel:
                self.channel.configure(state="disabled" if self.future or self.ready else "normal")

    def change_channel(self):
        self.app.store.put("", "accept-beta-updates", "", self.include_beta.get())
        self.online = []
        self.render_history()
        self.check()

    def check(self):
        if self.future:
            return
        self.target = None
        self.message = "正在检查版本更新…"
        include_beta = self.include_beta.get()
        self.run(lambda: fetch_releases(self.current, include_beta), self.checked)

    def checked(self, rows):
        self.online = rows
        if self.visible():
            self.render_history()
        if not rows:
            self.message = "暂无可用发行记录。" if self.include_beta.get() else "暂无正式发行记录。"
        elif rows[0][0] <= self.current:
            self.message = "当前已是最新版本。"
        else:
            self.target = rows[0]
            revision, _, _, full, delta = self.target
            mode = "增量包" if delta else "完整包"
            self.message = f"发现 {release_label(revision, full)}，{mode} · {(delta or full)['size']/1048576:.2f} MiB。"
            if not self.app.kindle:
                self.message += "请在 Kindle 上安装。"

    def install(self):
        if self.future or not self.app.kindle or not self.target:
            return
        revision, _, _, full, delta = self.target
        self.mode = "增量包" if delta else "完整包"
        def work():
            update.install(revision, full, delta, layout=layout(), emit=lambda *event: self.events.put(event))
            return revision
        self.message = "正在准备更新…"
        self.run(work, self.installed)

    def installed(self, revision):
        self.ready = revision
        tag = release_label(revision, self.target[3]) if self.target else version(revision)
        self.message = f"{tag} 已安装，再次打开微信读书时生效。"
        self.ask_exit()

    def ask_exit(self):
        # Shares app.confirm_action's 33/38a/39a panel; the design's own 43b
        # pairing ("稍后退出" / "立即退出") only needs a different cancel label.
        app = self.app
        if app.saver.sleeping or app.saver.overlay:
            app.root.after(500, self.ask_exit)
            return
        if self.prompt and self.prompt.winfo_exists():
            return
        reading = app.activity.ready
        app.activity.reading(False)
        if app.articles:
            app.articles.clock = None
        def later():
            self.prompt = None
            panel = tk.Frame(app.root, background="white", padx=16, pady=16)
            panel.place(in_=app.frame, x=0, y=0, relwidth=1, relheight=1)
            panel.lift()
            panel.focus_set()
            self.prompt = panel
            tk.Label(panel, text="请手动退出微信读书，再次打开后新版生效。", wraplength=350).pack(fill="x")
            def dismiss():
                panel.destroy()
                self.prompt = None
                if app.text is not None:
                    app.text.focus_set()
                    app.activity.reading(reading)
                if app.articles:
                    app.articles.reset_clock()
                if self.visible():
                    self.show()
            app.button(panel, "继续使用", dismiss).pack(fill="x")
        self.prompt = app.confirm_action("现在退出微信读书？", "新版已安装，再次打开微信读书时生效。",
                                         "立即退出", app.close, later, cancel_label="稍后退出")

    def run(self, work, finished):
        self.future = self.app.media.submit(work)
        self.refresh()
        def poll():
            while not self.events.empty():
                event = self.events.get()
                if event[0] == "progress":
                    _, done, size, host = event
                    self.progress = int(done*100/size)
                    self.message = f"{self.mode}　{self.progress}%　{done/1048576:.2f}/{size/1048576:.2f} MiB　{host}"
                else:
                    self.progress = None
                    self.message = {"probe": "正在测速选择下载线路…", "verify": "正在校验安装包…",
                                    "install": "正在安装…", "fallback": "增量包不可用，改用完整包…"}[event[1]]
                    if event[1] == "fallback":
                        self.mode = "完整包"
            if self.future.done():
                future, self.future = self.future, None
                self.progress = None
                try:
                    result = future.result()
                except Exception as error:
                    self.message = f"更新失败，可重试。{error}"
                else:
                    finished(result)
                self.refresh()
                return
            self.refresh()
            self.app.root.after(150, poll)
        self.app.root.after(50, poll)


def show_versions(app, back=None):
    if not hasattr(app, "version_details"):
        app.version_details = VersionDetails(app)
    app.version_details.show(back)
