"""Connect the public-account reader controls to the signed-in account."""
import json
import time
from urllib.error import URLError
from urllib.parse import urlencode

from client import AuthorizationRequired, ReaderError, WEB, reader_id
from resources import ROOT
from resources.mp import ArticleServiceError, page_directory, records
from resources.mp_image import fitted_image


class Articles:
    def __init__(self, app):
        self.app = app
        self.tk = app.root.tk
        self.clock = None
        self.obscured = False
        self.picture_jobs = set()
        self.tk.eval("namespace eval independent {}; namespace eval reading {}")
        if app.keyboard:
            def input_catalog():
                app.keyboard.open(".mp.search", lambda: self.tk.call("focus", ".mp.catalog"))
            self.tk.createcommand("independent::inputCatalog", input_catalog)
        for name, callback in (
            ("independent::fetch", self.fetch), ("independent::picture", self.picture),
            ("independent::shelf", lambda: app.book_back()), ("independent::remember", self.remember),
            ("independent::clock", self.reset_clock), ("independent::visibility", self.visibility),
            ("independent::catalogLogin", self.catalog_login),
            ("independent::systemBar", lambda visible: app.system_bar(bool(int(visible)))),
            ("independent::readerSurface", app.fit_reader_surface),
            ("reading::turned", self.turned),
        ):
            self.tk.createcommand(name, callback)
        self.tk.setvar("scale", 1)
        self.tk.setvar("kindle", int(app.kindle))
        self.tk.setvar("barCut", 0)
        for name in ("reader_style.tcl", "mp.tcl"):
            self.tk.call("source", "-encoding", "utf-8", str(ROOT / name))
        self.tk.call("bind", ".", "<Visibility>",
                     '+if {"%W" eq "."} {independent::visibility %s}')
        for event, visible in (("Map", "VisibilityUnobscured"), ("Unmap", "VisibilityFullyObscured")):
            self.tk.call("bind", ".", "<" + event + ">",
                         '+if {"%W" eq "."} {independent::visibility ' + visible + '}')

    def open(self, book):
        self.clock = None
        self.tk.setvar("mp::leftNext", int(self.app.store.get(self.app.client.account, "left-tap-next", default=False)))
        frame = self.app.frame
        frame.update_idletasks()
        scale = max(1, 1072 / max(1, frame.winfo_width()), 1448 / max(1, frame.winfo_height()))
        self.tk.setvar("scale", scale)
        self.tk.setvar("mp::readerSize", self.app.store.get("", "article-size", default=38))
        self.tk.call("mp::sizeFonts")
        self.tk.call("array", "unset", "mp::positions")
        self.tk.call("mp::openAccount", book["bookId"], book.get("title") or "公众号")

    def visible(self, path):
        return bool(self.tk.call("winfo", "exists", path))

    def catalog_login(self):
        app, book, back = self.app, self.app.book, self.app.book_back
        query = self.tk.getvar("mp::query")
        position = self.tk.getint(self.tk.getvar("mp::pos"))
        self.tk.call("place", "forget", ".mp")
        def cancel():
            app.clear()
            self.tk.call("place", ".mp", "-in", ".page", "-relwidth", 1, "-relheight", 1)
            self.tk.call("mp::statusInset")
            self.tk.call("raise", ".mp")
            self.tk.call("focus", ".mp.catalog")
        def resume():
            app.open_book(book, back)
            self.tk.setvar("mp::query", query)
            self.tk.setvar("mp::target", position)
            if position < self.tk.getint(self.tk.call("llength", self.tk.getvar("mp::matches"))):
                self.tk.setvar("mp::pos", position)
                self.tk.call("mp::drawCatalog")
        app.login(resume=resume, back=cancel)

    def remember(self, review, index):
        self.app.store.put(self.app.client.account, "article-position", review, index)
        self.app.store.put("", "article-size", "", self.tk.getvar("mp::readerSize"))

    def fetch(self, token, mode, operation, key, offset):
        client = self.app.client
        account = client.account
        cache_key = key + "/" + str(offset)
        cover_key = key + "/cover"
        mp_page = WEB + "/web/mp/reader/" + reader_id(str(self.tk.getvar("mp::account")))
        if operation == "read":
            book_id = str(self.tk.getvar("mp::account"))
            row = self.tk.call("lindex", self.tk.getvar("mp::rows"), self.tk.getvar("mp::index"))
            link, pay_type = self.tk.call("lindex", row, 4), self.tk.call("lindex", row, 6)
        def public_source():
            if pay_type:
                return link if str(pay_type) == "0" else ""
            detail = client.review_detail(key)
            info = detail.get("mpInfo") or {}
            if str(detail.get("belongBookId")) == book_id and str(info.get("payType")) == "0":
                return info.get("doc_url") or ""
            return ""
        def request(endpoint, params):
            prefix = "/api/mp/" if endpoint == "cover" else "/web/mp/"
            url = WEB + prefix + endpoint + "?" + urlencode(params)
            def decode(raw):
                try:
                    return json.loads(raw) if raw.lstrip().startswith("{") else raw
                except ValueError:
                    raise ArticleServiceError("format", "微信读书返回的数据格式无法识别。") from None
            return client.request_with_renewal(url, decode, headers={"Referer": mp_page})
        def load():
            try:
                rows = list(records(operation, key, int(offset), fetch=request,
                                    public_source=public_source if operation == "read" else None,
                                    native_fetch=client.native_get if operation == "list" and client.has_native_login()
                                    else None))
            except AuthorizationRequired:
                raise
            except (URLError, TimeoutError, ConnectionError, ArticleServiceError, ReaderError) as err:
                if isinstance(err, (ReaderError, ArticleServiceError)) and operation != "list":
                    raise
                if isinstance(err, ArticleServiceError) and err.code in ("-2010", "-2012", "-2013", "forbidden"):
                    raise
                service_failure = isinstance(err, (ReaderError, ArticleServiceError))
                restricted = isinstance(err, ArticleServiceError) and err.code == "-2041"
                reason = "文章列表受限（-2041）" if restricted else "完整文章列表未返回"
                cached = client.store.get(account, "article-" + operation, cache_key)
                first_page = operation == "list" and int(offset) == 0
                seen = client.store.get(account, "article-list", cover_key, []) if first_page else []
                if cached is not None and operation == "list" and any(row[0] == "item" for row in cached):
                    return cached, "本机文章列表 · " + reason if restricted else "本机文章列表"
                if first_page and (service_failure or not (cached or seen)):
                    try:
                        html = client.request(mp_page)
                        rows = page_directory(html, key)
                    except AuthorizationRequired:
                        raise
                    except ArticleServiceError as page_error:
                        if page_error.code == "forbidden":
                            raise
                        rows = []
                    except (ReaderError, URLError, TimeoutError, ConnectionError):
                        rows = []
                    if rows:
                        client.store.put(account, "article-list", cache_key, rows)
                        return rows, ""
                if cached is not None:
                    if operation == "list":
                        return cached, "本机文章列表 · " + reason if restricted else "本机文章列表"
                    return cached, "正在阅读本机缓存"
                if not first_page:
                    raise
                if service_failure:
                    try:
                        cover = request("cover", {"bookId": key})
                        if (isinstance(cover, dict) and cover.get("reviewId") and cover.get("title")
                                and cover.get("errCode") in (None, 0, "0")):
                            rows = [("item", cover["reviewId"], cover["title"], cover.get("name") or "",
                                     "", "", cover.get("pic") or "", "")]
                            rows.extend(r for r in seen if r[0] == "item" and r[1] != cover["reviewId"])
                            rows.append(("next", ""))
                            client.store.put(account, "article-list", cover_key, rows)
                            return rows, "封面记录 · " + reason
                    except AuthorizationRequired:
                        raise
                    except (URLError, TimeoutError, ConnectionError, ReaderError, ArticleServiceError):
                        pass
                if seen:
                    return seen, "本机封面记录 · " + reason
                raise
            client.store.put(account, "article-" + operation, cache_key, rows)
            return rows, ""
        def deliver(result):
            if not self.visible(".mp") or int(self.tk.getvar("mp::version")) != int(token):
                return
            rows, notice = result
            if mode == "list" and not notice and rows and rows[-1][0] == "next":
                self.tk.setvar("mp::loginRequired", 0)
            if mode == "list":
                self.tk.setvar("mp::catalogNotice", notice)
            if operation == "read":
                index = client.store.get(client.account, "article-position", key, "1.0")
                self.tk.setvar(f"mp::positions({key})", index)
            for kind, *fields in rows:
                self.tk.call("mp::record", mode, offset, kind, tuple(fields))
                if operation == "read" and kind == "ready":
                    self.app.saver.remember(self.app.book)
                    if notice:
                        self.tk.call("mp::readMessage", notice)
        def failed(err):
            expired = isinstance(err, AuthorizationRequired) or (
                isinstance(err, ArticleServiceError) and err.code in ("-2010", "-2012", "-2013"))
            if expired and operation == "list":
                if not self.visible(".mp") or int(self.tk.getvar("mp::version")) != int(token):
                    return
                self.tk.setvar("mp::loginRequired", 1)
                cached = client.store.get(account, "article-list", cache_key)
                if cached:
                    deliver((cached, "本机文章列表 · 登录已过期"))
                else:
                    deliver(([("error", "登录已过期")], ""))
                return
            message = str(err) if isinstance(err, (ReaderError, ArticleServiceError)) else "未能加载，请检查网络后重试。"
            deliver(([("error", message)], ""))
        if mode == "list" and int(offset) == 0 and not self.tk.call("llength", self.tk.getvar("mp::rows")):
            cached = client.store.get(account, "article-list", cache_key, [])
            items = [tuple(row[1:]) for row in cached if row and row[0] == "item"]
            if items:
                self.tk.call("mp::showCachedCatalog", items)
        self.app.submit(load, deliver, failed)

    def picture(self, frame, width, url):
        directory = self.app.store.path.parent / "article-images"
        def done(path):
            self.tk.call("mp::showPicture", frame, width, str(path))
        self.picture_jobs = {job for job in self.picture_jobs if not job.done()}
        job = self.app.submit(lambda: fitted_image(directory, url, int(width)), done, lambda _: done(""), media=True)
        self.picture_jobs.add(job)

    def visibility(self, state):
        hidden = state == "VisibilityFullyObscured"
        if self.obscured != hidden:
            self.obscured = hidden
            self.reset_clock()

    def reset_clock(self):
        self.clock = None
        if (self.visible(".mp.body") and self.tk.call("winfo", "viewable", ".mp.body") and not self.obscured
                and self.app.activity.focused
                and not self.app.saver.overlay and not self.app.saver.sleeping
                and int(self.tk.getvar("mp::ready")) and not int(self.tk.getvar("mp::options"))):
            self.clock = time.monotonic()

    def turned(self):
        if self.clock is None or not self.visible(".mp.body") or not int(self.tk.getvar("mp::ready")):
            return
        elapsed = int(time.monotonic() - self.clock)
        if elapsed < 1:
            return
        self.reset_clock()
        if not self.clock or elapsed > 120:
            return
        book = self.tk.getvar("mp::account")
        review = self.tk.call("lindex", self.tk.getvar("mp::rows"), self.tk.getvar("mp::index"), 0)
        client = self.app.client
        ended = int(time.time())
        detail = {"book": book, "review": review}
        event = self.app.activity.record(client, ended, elapsed, detail)
        if not event:
            return
        def failed(_):
            if self.visible(".mp.body") and review == self.tk.call(
                    "lindex", self.tk.getvar("mp::rows"), self.tk.getvar("mp::index"), 0):
                self.tk.call("mp::readMessage", "本段阅读时长未获确认")
        self.app.submit(lambda: client.send_reading_event(event, detail, ended, elapsed),
                        lambda _: None, failed, executor=self.app.reporting)
