"""WeChat SDK sign-in for the independent reader."""
import hashlib
import json
import secrets
import time
from urllib.error import URLError
from urllib.parse import urlencode
from urllib.request import Request, build_opener

from client import NoRedirect, ReaderError

API = "https://i.weread.qq.com"
WX = "https://open.weixin.qq.com/connect"
HEADERS = {"User-Agent": "WeRead/2.1.2 WRBrand/Amazon Linux; U; Android 4.4.4",
           "appver": "2.1.2.0", "basever": "2.1.2.0", "channelId": "0", "osver": "4.4.4"}


def request(url, *, body=None, timeout=15, headers=None):
    headers = {**HEADERS, **(headers or {})}
    if body is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
        body = json.dumps(body).encode()
    with build_opener(NoRedirect()).open(Request(url, data=body, headers=headers), timeout=timeout) as reply:
        data = json.load(reply)
    if not isinstance(data, dict):
        raise ReaderError("微信登录返回的数据格式不正确。")
    return data


class NativeLogin:
    def __init__(self, store):
        self.store = store
        self.last = None

    def begin(self):
        ticket = request(API + "/wxticket?nonceStr=weread")
        if not ticket.get("signature") or not ticket.get("timeStamp"):
            raise ReaderError("微信读书没有返回扫码票据，请刷新。")
        params = {"appid": "wxab9b71ad2b90ff34", "noncestr": "weread", "timestamp": ticket["timeStamp"],
                  "scope": "snsapi_userinfo,snsapi_friend,snsapi_favorites", "signature": ticket["signature"]}
        qr = request(WX + "/sdk/qrconnect?" + urlencode(params))
        if qr.get("errcode") != 0 or not isinstance(qr.get("uuid"), str) or not qr["uuid"]:
            raise ReaderError("微信没有返回登录二维码，请刷新。")
        self.uuid = qr["uuid"]
        return WX + "/confirm?" + urlencode({"uuid": self.uuid})

    def poll(self):
        params = {"uuid": self.uuid, "f": "json"}
        if self.last is not None:
            params["last"] = self.last
        try:
            reply = request("https://long.open.weixin.qq.com/connect/l/qrconnect?" + urlencode(params), timeout=8)
        except TimeoutError:
            return None
        except URLError as exc:
            if isinstance(exc.reason, TimeoutError):
                return None
            raise
        self.last = int(reply.get("wx_errcode", -1))
        if self.last in (404, 408):
            return None
        if self.last != 405 or not reply.get("wx_code"):
            raise ReaderError("二维码已失效或已取消，请刷新二维码。")
        device = self.store.get("", "native-device-id")
        if not device:
            device = secrets.token_hex(16)
            self.store.put("", "native-device-id", "", device)
        timestamp = time.time_ns() // 1000000
        random_value = secrets.randbelow(1000)
        signature = hashlib.sha256(f"{timestamp}{device}{random_value}".encode()).hexdigest()
        result = request(API + "/login", body={"code": reply["wx_code"], "deviceId": device,
                         "trackId": "", "timestamp": timestamp, "random": random_value, "signature": signature,
                         "isFromQrcode": 1, "isAutoLogout": 0, "deviceName": "Kindle WeRead"})
        account, token = str(result.get("vid", "")), result.get("accessToken")
        if not account.isascii() or not account.isdigit() or not isinstance(token, str) or not token:
            raise ReaderError("微信读书未确认原生登录，请重新扫码。")
        return account, token
