"""Geometry for the approved PW3 screens, in the Kindle application's work area."""
import tkinter as tk
from tkinter import font as tkfont

FAMILY = "Noto Sans CJK SC"
INK = "#222222"
SECONDARY = "#555555"
RULE = "#aaaaaa"


class Page:
    # The reference artwork includes an 88px system strip. Only the part
    # below it belongs to the app. The Kindle WM supplies the actual viewport.
    def __init__(self, app):
        self.app = app
        self.frame = tk.Frame(app.frame, bg="white")
        self.frame.place(x=0, y=0, relwidth=1, relheight=1, bordermode="outside")
        self.factor = 1 if app.kindle else .5

    def put(self, widget, x, y, w, h):
        widget.place(relx=x/1072, rely=(y-88)/1360, relwidth=w/1072, relheight=h/1360)
        return widget

    def font(self, size, bold=False):
        return (FAMILY, -round(size*self.factor), "bold" if bold else "normal")

    def label(self, value, x, y, w, h, size=32, bold=False, anchor="w", color=INK):
        widget = tk.Label(self.frame, text=value, font=self.font(size, bold), fg=color,
                          bg="white", anchor=anchor, padx=0, pady=0, bd=0)
        return self.put(widget,x,y,w,h)

    def line(self,x,y,w,color=RULE,h=2):
        return self.put(tk.Frame(self.frame, bg=color),x,y,w,h)

    def button(self, value, action, x,y,w,h, size=28, outline=False, primary=False, anchor="center"):
        bg = INK if primary else "white"
        widget = tk.Button(self.frame,text=value,command=action,font=self.font(size),
                           bd=0, relief="flat", overrelief="flat", bg=bg, fg="white" if primary else INK,
                           activebackground="#eeeeee", activeforeground=INK, disabledforeground="#888888",
                           highlightthickness=round(2*self.factor) if outline else 0,
                           highlightbackground=INK,highlightcolor=INK,padx=0,pady=0,anchor=anchor)
        return self.put(widget,x,y,w,h)

    def title(self,value):
        title=self.label(value,48,110,710,96,44,True)
        self.line(48,226,976)
        return title

    def footer(self,items,active=None):
        self.line(0,1354,1072)
        width=1072/len(items)
        buttons={}
        for i,(name,action) in enumerate(items):
            if len(items)==1:
                buttons[name]=self.button(name,action,48,1357,230,90,32,anchor="w")
            elif name==active:
                buttons[name]=self.label(name,i*width,1357,width,90,32,True,"center")
                self.line((i+.5)*width-34,1355,68,INK,5)
            else:
                buttons[name]=self.button(name,action,i*width,1357,width,90,32)
        return buttons

    def tabs(self, items, selected, choose, y):
        width = 976 / len(items)
        self.line(48, y+88, 976, "#cccccc")
        marker = self.line(48, y+85, 66, INK, 5)
        def select(key, index):
            self.put(marker, 48 + (index+.5)*width-33, y+85, 66, 5)
            marker.lift()
            choose(key)
        for i, (key, name) in enumerate(items):
            self.button(name, lambda k=key, n=i: select(k, n), 48+i*width, y, width, 85)
            if key == selected:
                self.put(marker, 48 + (i+.5)*width-33, y+85, 66, 5)
        marker.lift()

    def value_row(self, label, value, y, height):
        self.label(label, 48, y, 436, height, 36)
        self.label(value, 496, y, 528, height, 28, color=SECONDARY, anchor="e")
        self.line(48, y + height, 976, "#cccccc")

    def row(self,name,action,y,height):
        self.button(name,action,48,y,850,height,36,anchor="w")
        self.button("›",action,898,y,126,height,28,anchor="e")
        self.line(48,y+height-2,976,"#dddddd")

    def search(self, var, prompt, submit=None, end=1024):
        canvas=tk.Canvas(self.frame,bg="white",bd=0,highlightthickness=0)
        self.put(canvas,48,256,end-48,88)
        def paint(event):
            w,h=event.width,event.height
            r=8*self.factor
            canvas.delete("all")
            canvas.create_polygon(2,r,2,2,r,2,w-r,2,w-2,2,w-2,r,w-2,h-r,w-2,h-2,
                                  w-r,h-2,r,h-2,2,h-2,2,h-r,smooth=True,fill="white",
                                  outline=SECONDARY,width=2*self.factor)
            cx,cy=40*self.factor,h/2-3*self.factor
            canvas.create_oval(cx-13*self.factor,cy-13*self.factor,cx+13*self.factor,cy+13*self.factor,
                               width=3*self.factor,outline=INK)
            canvas.create_line(cx+9*self.factor,cy+9*self.factor,cx+22*self.factor,cy+22*self.factor,
                               width=3*self.factor,fill=INK)
        canvas.bind("<Configure>",paint)
        field=tk.Entry(canvas,textvariable=var,font=self.font(32),bg="white",fg=INK,
                       highlightthickness=0,relief="flat",bd=0)
        field.place(relx=80/(end-48),rely=.12,relheight=.76,relwidth=1-104/(end-48))
        hint=tk.Label(field,text=prompt,font=self.font(32),fg=SECONDARY,bg="white",anchor="w",padx=0,bd=0)
        def update(*_):
            if var.get() or field.focus_get() is field:
                hint.place_forget()
            else:
                hint.place(relwidth=1,relheight=1)
        def activate(_):
            field.focus_set()
            if self.app.keyboard:
                self.app.keyboard.open(field,submit)
        hint.bind("<ButtonRelease-1>",activate)
        canvas.bind("<ButtonRelease-1>",activate)
        self.app.touch_input(field,submit)
        if submit:
            field.bind("<Return>",submit)
        field.bind("<FocusIn>",update)
        field.bind("<FocusOut>",update)
        trace=var.trace_add("write",update)
        field.bind("<Destroy>",lambda _:var.trace_remove("write",trace))
        update()
        return field

    def shorten(self,value,width,size):
        font=tkfont.Font(root=self.frame,font=self.font(size))
        if font.measure(value)<=width*self.factor:
            return value
        while value and font.measure(value+"…")>width*self.factor:
            value=value[:-1]
        return value+"…"
