"""Touch input for Kindle search fields, with an offline Simplified Chinese lexicon."""
import mmap
from pathlib import Path
import tkinter as tk


class TouchKeyboard:
    page_size = 4

    def __init__(self, app):
        self.app = app
        self.panel = self.lexicon = None

    def candidates(self, spelling):
        if not spelling:
            return []
        if self.lexicon is None:
            with Path(__file__).with_name("pinyin.tsv").open("rb") as source:
                self.lexicon = mmap.mmap(source.fileno(), 0, access=mmap.ACCESS_READ)
        key = b"\n" + spelling.encode("ascii") + b"\t"
        at = self.lexicon.find(key)
        if at < 0:
            return []
        start = at + len(key)
        return self.lexicon[start:self.lexicon.find(b"\n", start)].decode().split()

    def _family(self):
        return "Noto Sans CJK SC" if self.app.kindle else "Microsoft YaHei UI"

    def _unit(self):
        return 1 if self.app.kindle else 0.5

    def _font(self, size, bold=False):
        return (self._family(), -round(size*self._unit()), "bold" if bold else "normal")

    def _put(self, widget, x, y, w, h):
        # The panel covers the whole work area (design y 88-1448), matching pw3_page.Page.put.
        widget.place(in_=self.panel, relx=x/1072, rely=(y-88)/1360, relwidth=w/1072, relheight=h/1360)

    def _in_tray(self, widget, x, y, w, h):
        # Design 44/44a/44b: the keyboard tray spans y 596-1448.
        widget.place(in_=self.tray, relx=x/1072, rely=(y-596)/852, relwidth=w/1072, relheight=h/852)

    def _key_row_x(self, count):
        return 536 - (count*101 - 13)/2

    def _slots(self, count, y, h=86, start=49, end=1023, gap=17):
        width = (end - start - (count-1)*gap) / count
        return [(start + i*(width+gap), y, width, h) for i in range(count)]

    def _key_button(self, parent, text, command, primary=False):
        btn = self.app.button(parent, text, command)
        btn.configure(font=self._font(28), bd=0, relief="flat",
                      bg="#222222" if primary else "white", fg="white" if primary else "#222222",
                      activebackground="#eeeeee", activeforeground="#222222", disabledforeground="#888888",
                      highlightthickness=round(2*self._unit()), highlightbackground="#222222",
                      highlightcolor="#222222")
        return btn

    def _plain_button(self, parent, text, command):
        btn = self.app.button(parent, text, command)
        btn.configure(font=self._font(28), bg="white", fg="#222222", disabledforeground="#bbbbbb")
        return btn

    def open(self, field, submit=None):
        tkapp = self.app.root.tk
        path = str(field)
        if not tkapp.call("winfo", "exists", path) or str(tkapp.call(path, "cget", "-state")) != "normal":
            return
        self.dismiss()
        self.path, self.submit = path, submit
        self.mode, self.upper = "拼音", False
        self.spelling, self.page, self.words = "", 0, []
        self.panel = tk.Frame(self.app.root, background="white")
        self.panel.place(in_=self.app.frame, x=0, y=0, relwidth=1, relheight=1)
        self.panel.lift()
        self.multiline = tkapp.call("winfo", "class", path) == "Text"
        cursor = tkapp.call(path, "index", "insert")
        if self.multiline:
            self.line = tk.Text(self.panel, relief="solid", bd=1, wrap="char", font=self._font(32))
            self.line.insert("1.0", tkapp.call(path, "get", "1.0", "end-1c"))
            self.line.mark_set("insert", cursor)
            self.line.see("insert")
            self._put(self.line, 48, 232, 976, 330)
        else:
            self.line = tk.Entry(self.panel, relief="solid", bd=1, font=self._font(32))
            self.line.insert(0, tkapp.call(path, "get"))
            self.line.icursor(cursor)
            self._put(self.line, 48, 300, 976, 96)
        self.line.focus_set()
        self.line.bind("<Escape>", lambda _: self.dismiss() or "break")
        if not self.multiline:
            self.line.bind("<Return>", lambda _: self.done() or "break")
        # A bordered tray fills the bottom of the screen (design y 596-1448) while
        # the field being edited stays visible above it.
        self.tray = tk.Frame(self.panel, bg="white", highlightthickness=round(2*self._unit()),
                             highlightbackground="#555555")
        self._put(self.tray, 0, 596, 1072, 852)
        self.preedit = tk.StringVar()
        self._in_tray(tk.Label(self.tray, textvariable=self.preedit, bg="white", fg="#222222",
                               anchor="w", font=self._font(32)), 48, 610, 880, 70)
        self._in_tray(tk.Frame(self.tray, bg="#aaaaaa"), 0, 700, 1072, 2)
        self.choices = tk.Frame(self.tray, bg="white")
        self._in_tray(self.choices, 48, 700, 976, 99)
        slot = 976 / 6
        self.choice_buttons = []
        for i in range(self.page_size):
            btn = self._plain_button(self.choices, "", lambda n=i: self.choose(n))
            btn.place(relx=(i+1)*slot/976, rely=0, relwidth=slot/976, relheight=1)
            self.choice_buttons.append(btn)
        self.prev = self._plain_button(self.choices, "‹", lambda: self.turn(-1))
        self.prev.place(relx=0, rely=0, relwidth=slot/976, relheight=1)
        self.next = self._plain_button(self.choices, "›", lambda: self.turn(1))
        self.next.place(relx=5*slot/976, rely=0, relwidth=slot/976, relheight=1)
        self._in_tray(tk.Frame(self.tray, bg="#aaaaaa"), 48, 799, 976, 2)
        self.key_buttons = []
        self.draw_keys()
        for i, (name, action, primary) in enumerate((
                ("取消", self.dismiss, False), ("清空", self.clear, False), ("退格", self.erase, False),
                ("空格", self.space, False), ("完成", self.done, True))):
            x, y, w, h = self._slots(5, 1271)[i]
            self._in_tray(self._key_button(self.tray, name, action, primary), x, y, w, h)
        self.refresh()

    def draw_keys(self):
        for widget in self.key_buttons:
            widget.destroy()
        self.key_buttons.clear()
        rows = ("1234567890", "，。？！：；、（）", ".,?!-_'@/") if self.mode == "符号" else (
            "qwertyuiop", "asdfghjkl", "zxcvbnm")
        for row_index, row in enumerate(rows):
            y = 833 + 96*row_index
            start = self._key_row_x(len(row))
            for col, key in enumerate(row):
                key = key.upper() if self.mode == "英文" and self.upper else key
                btn = self._key_button(self.tray, key, lambda k=key: self.type_key(k))
                self.key_buttons.append(btn)
                self._in_tray(btn, start + col*101, y, 88, 86)
        names = ["拼音", "英文", "符号"]
        if self.mode == "英文":
            names.append("大小写")
        if self.multiline:
            names.append("换行")
        for name, (x, y, w, h) in zip(names, self._slots(len(names), 1148)):
            if name == "大小写":
                btn = self._key_button(self.tray, name, self.shift)
            elif name == "换行":
                btn = self._key_button(self.tray, name, self.newline)
            else:
                btn = self._key_button(self.tray, name, lambda m=name: self.switch(m), primary=name == self.mode)
                btn.configure(state="disabled" if name == self.mode else "normal")
            self.key_buttons.append(btn)
            self._in_tray(btn, x, y, w, h)

    def refresh(self):
        self.preedit.set(self.spelling)
        for i, button in enumerate(self.choice_buttons):
            n = self.page * self.page_size + i
            button.configure(text=self.words[n] if n < len(self.words) else "",
                             state="normal" if n < len(self.words) else "disabled")
        self.prev.configure(state="normal" if self.page else "disabled")
        self.next.configure(state="normal" if (self.page+1)*self.page_size < len(self.words) else "disabled")

    def compose(self, spelling):
        self.spelling = spelling
        self.words = self.candidates(spelling)
        self.page = 0
        self.refresh()

    def delete_selection(self):
        selected = self.line.tag_ranges("sel") if self.multiline else self.line.selection_present()
        if selected:
            self.line.delete("sel.first", "sel.last")
        return bool(selected)

    def insert(self, value):
        self.delete_selection()
        self.line.insert("insert", value)
        if self.multiline:
            self.line.see("insert")

    def type_key(self, key):
        if self.mode == "拼音":
            self.compose(self.spelling + key)
        else:
            self.insert(key)

    def choose(self, index):
        self.insert(self.words[self.page*self.page_size + index])
        self.compose("")

    def turn(self, delta):
        self.page += delta
        self.refresh()

    def switch(self, mode):
        if self.spelling:
            if mode == "英文":
                self.insert(self.spelling)
                self.compose("")
            elif self.words:
                self.choose(0)
            else:
                return
        self.mode = mode
        self.draw_keys()

    def shift(self):
        self.upper = not self.upper
        self.draw_keys()

    def erase(self):
        if self.spelling:
            self.compose(self.spelling[:-1])
        elif not self.delete_selection():
            if self.multiline:
                if self.line.compare("insert", ">", "1.0"):
                    self.line.delete("insert-1c", "insert")
            elif self.line.index("insert"):
                self.line.delete(self.line.index("insert") - 1)

    def clear(self):
        self.line.delete("1.0" if self.multiline else 0, "end")
        self.compose("")

    def newline(self):
        if self.spelling and not self.words:
            return
        if self.words:
            self.choose(0)
        self.insert("\n")

    def space(self):
        if self.words:
            self.choose(0)
        elif not self.spelling:
            self.insert(" ")

    def done(self):
        if self.spelling:
            if not self.words:
                self.preedit.set(self.spelling + "　无候选词，可退格或切换英文")
                return
            self.choose(0)
        value = self.line.get("1.0", "end-1c") if self.multiline else self.line.get()
        cursor = self.line.index("insert")
        tkapp, path, submit = self.app.root.tk, self.path, self.submit
        self.dismiss()
        if tkapp.call("winfo", "exists", path):
            if self.multiline:
                tkapp.call(path, "delete", "1.0", "end")
                tkapp.call(path, "insert", "1.0", value)
                tkapp.call(path, "mark", "set", "insert", cursor)
                tkapp.call(path, "see", "insert")
            else:
                variable = tkapp.call(path, "cget", "-textvariable")
                if variable:
                    tkapp.setvar(str(variable), value)
                else:
                    tkapp.call(path, "delete", 0, "end")
                    tkapp.call(path, "insert", 0, value)
                if tkapp.call("winfo", "exists", path):
                    tkapp.call(path, "icursor", cursor)
            if submit:
                submit()

    def dismiss(self):
        if self.panel is not None:
            self.panel.destroy()
            self.panel = None

    def close(self):
        self.dismiss()
        if self.lexicon is not None:
            self.lexicon.close()
