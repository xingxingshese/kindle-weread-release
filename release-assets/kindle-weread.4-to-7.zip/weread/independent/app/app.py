"""Shared Windows and Kindle entry point for the independent reader."""
import argparse
import io
import json
import os
import queue
import re
import time
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from tkinter import simpledialog
from urllib.error import URLError
from urllib.parse import urlencode

import qrcode
from PIL import Image, ImageOps

from client import Client, Library, OfficialChapterRequired, ReaderError, WEB
from resources.mp import Article

KINDLE = os.environ.get("WR_PW3_VIEWER") == "1"
FONT = "Noto Sans CJK SC" if KINDLE else "Microsoft YaHei UI"
BODY_FONT = "LXGW WenKai" if KINDLE else FONT
SCALE = 2 if KINDLE else 1


def photo(image):
    stream = io.BytesIO()
    image.save(stream, format="PNG")
    return tk.PhotoImage(data=stream.getvalue(), format="png")


def blocks(result):
    if result["format"] == "text":
        return [("paragraphs", result["content"].strip())]
    source = result.get("display_source", result["content"])
    body = re.search(r"<body\b[^>]*>(.*?)</body\s*>", source, re.I | re.S)
    parser = Article()
    parser.feed('<section id="js_content">' + (body[1] if body else source) + "</section>")
    parser.close()
    return list(parser.blocks_in_order())


def quote_anchor(text, result, excerpt, span):
    """Resolve identical quotations by the service's range in the chapter source."""
    anchor = text.search(excerpt, "1.0", stopindex="end") if excerpt else ""
    from variants import hidden_range
    if hidden_range(result, span):
        return ""
    if not anchor or not span or not text.search(excerpt, anchor + "+1c", stopindex="end"):
        return anchor
    match = re.fullmatch(r"([0-9]+)-([0-9]+)", str(span))
    if not match:
        return ""
    start, end = (int(n) * 2 for n in match.groups())
    raw = result["content"].encode("utf-16-le")
    if end > len(raw) or raw[start:end].decode("utf-16-le", errors="replace") != excerpt:
        return ""
    visible = result["display_source"].encode("utf-16-le") if "display_source" in result else raw
    prefix = visible[:start].decode("utf-16-le", errors="ignore")
    if result["format"] == "html" and re.search(r"<body\b", prefix, re.I):
        prefix += "</body>"
    before = blocks({"format": result["format"], "content": prefix})
    count = sum(block[1].count(excerpt) for block in before if block[0] == "paragraphs")
    for _ in range(count):
        anchor = text.search(excerpt, anchor + f"+{len(excerpt)}c", stopindex="end")
        if not anchor:
            break
    return anchor


class App:
    def __init__(self, root, store, scan_for_stats=False):
        self.root, self.store = root, store
        self.kindle = KINDLE
        from keyboard import TouchKeyboard
        self.keyboard = TouchKeyboard(self) if self.kindle else None
        self.articles = None
        self.sync_book_marks = False
        self.client = Client(store)
        self.jobs = ThreadPoolExecutor(1)
        self.reporting = ThreadPoolExecutor(1)
        self.media = ThreadPoolExecutor(4)
        self.results = queue.Queue()
        self.generation = 0
        self.shelf_page, self.query = 0, ""
        from shelf import ShelfGrid
        self.shelf_grid = ShelfGrid(self)
        self.books, self.rows = [], []
        self.book = self.uid = self.text = self.loaded = None
        self.book_back = self.show_shelf
        self.size = store.get("", "size", default=16)
        if KINDLE:
            root.title("L:A_N:application_ID:wereadpw3_PC:T_WS:true_O:U")
            root.geometry("1072x1448+0+0")
            root.tk.call("tk", "scaling", 2.6)
        else:
            root.title("Kindle 微信读书")
            root.geometry("550x730")
        root.minsize(400, 480)
        root.configure(bg="white")
        root.option_add("*Font", (FONT, 11))
        root.option_add("*Background", "white")
        self.frame = tk.Frame(root, name="page", padx=20, pady=15)
        if KINDLE:
            self.frame.place(x=0, y=0, relwidth=1, relheight=1)
            def fit_screen(event):
                if event.widget is root:
                    height = min(root.winfo_height(), root.winfo_screenheight() - root.winfo_rooty())
                    if height > 1:
                        self.frame.place_configure(relheight=0, height=height)
            root.bind("<Configure>", fit_screen, add=True)
        else:
            self.frame.pack(expand=True, fill="both")
        root.protocol("WM_DELETE_WINDOW", self.close)
        from saver import ScreenSaver
        self.saver = ScreenSaver(self)
        from activity import ReadingActivity
        self.activity = ReadingActivity(self)
        self.receive_timer = root.after(40, self.receive)
        if scan_for_stats and (KINDLE or os.name == "nt"):
            self.login(for_stats=True)
        elif self.client.account:
            self.show_shelf(sync=True)
        else:
            self.login()

    def system_bar(self, visible):
        if self.kindle:
            policy = "T" if visible else "N"
            self.root.title(f"L:A_N:application_ID:wereadpw3_PC:{policy}_WS:true_O:U")

    def clear(self):
        self.system_bar(True)
        if self.keyboard:
            self.keyboard.dismiss()
        self.activity.reading(False)
        self.activity.offsets = None
        self.save_position()
        self.text = None
        self.progress = None
        self.generation += 1
        for child in self.frame.winfo_children():
            child.destroy()
        self.photos = []

    def submit(self, work, done, failed=None, media=False, executor=None):
        version = self.generation
        owner = self.client
        def run():
            if owner.signed_out:
                return
            try:
                value = work()
            except Exception as error:
                self.results.put((version, failed or self.error, error))
            else:
                self.results.put((version, done, value))
        return (executor or (self.media if media else self.jobs)).submit(run)

    def receive(self):
        self.saver.poll()
        while not self.results.empty():
            version, callback, value = self.results.get()
            if version == self.generation:
                callback(value)
        self.receive_timer = self.root.after(40, self.receive)

    def header(self, title, back=None):
        # The book overlay owns its own return control; normal subpages use the footer.
        if not title:
            bar=tk.Frame(self.frame)
            bar.pack(fill="x")
            if back:
                self.button(bar,"‹ 返回",back).pack(side="left")
            return bar
        unit=1 if self.kindle else .5
        if back:
            footer=tk.Frame(self.frame,height=round(94*unit))
            footer.pack(side="bottom",fill="x")
            footer.pack_propagate(False)
            tk.Frame(footer,bg="#aaaaaa",height=2).pack(fill="x")
            self.button(footer,"‹ 返回",back).pack(side="left",padx=round(28*unit),fill="y")
        bar=tk.Frame(self.frame,height=round(120*unit),padx=round(28*unit))
        bar.pack(fill="x",pady=(0,round(18*unit)))
        bar.pack_propagate(False)
        tk.Frame(bar,bg="#aaaaaa",height=2).pack(side="bottom",fill="x")
        tk.Label(bar,text=title,anchor="w",font=(FONT,-round(44*unit),"bold"),fg="#222222").pack(side="left")
        return bar

    @staticmethod
    def button(parent, title, command):
        return tk.Button(parent, text=title, command=command, relief="flat",
                         cursor="hand2", padx=7, pady=4, highlightthickness=0)

    def touch_input(self, field, submit=None):
        if self.keyboard:
            field.bind("<ButtonRelease-1>", lambda _: self.keyboard.open(field, submit), add=True)

    def status_line(self, parent=None):
        self.status = tk.StringVar()
        label = tk.Label(parent or self.frame, textvariable=self.status, fg="#505050", anchor="w",
                         justify="left", wraplength=430*SCALE)
        label.pack(fill="x")
        return label

    def navigation(self, current):
        from discovery import Discover
        bar = tk.Frame(self.frame)
        bar.pack(side="bottom", fill="x")
        for name, action in (("发现", lambda: Discover(self)), ("书架", lambda: self.show_shelf(True)),
                             ("我的", self.profile)):
            button = self.button(bar, name, action)
            button.pack(side="left", expand=True, fill="x")
            if name == current:
                button.configure(state="disabled")

    def profile(self):
        self.clear()
        from pw3_page import Page
        from discovery import Discover
        from account_stats import show_stats, account_stats, minute_duration
        from updates import show_versions
        page=Page(self)
        page.title("我的")
        page.button("设置",self.settings,884,118,140,88,anchor="e")
        page.footer([("发现",lambda:Discover(self)),("书架",self.show_shelf),("我的",self.profile)],"我的")
        self.status=tk.StringVar()
        page.label("",48,1255,976,76,26,color="#555555").configure(textvariable=self.status)
        info=page.label("",48,294,656,88,44,True)
        extra=page.label("",48,390,976,68,26,color="#555555")
        page.line(48,460,976)
        def display(data):
            info.configure(text=page.shorten(data["name"],650,44))
            extra.configure(text="　".join(filter(None,(data.get("medal"),data.get("signature")))))
        cached = self.store.get(self.client.account, "profile")
        if cached:
            display(cached)
        def query():
            refresh.configure(state="disabled")
            self.status.set("正在读取账号资料…")
            def loaded(data):
                display(data)
                self.status.set("")
                refresh.configure(state="normal")
            def failed(error):
                self.error(error)
                refresh.configure(state="normal")
            self.submit(self.client.account_profile, loaded, failed)
        refresh=page.button("刷新资料",query,730,294,294,88,outline=True)
        totals={}
        for name,y in (("今日",512),("本周",737)):
            page.label(name+"阅读",48,y,976,70,32)
            totals[name]=page.label("…",48,y+72,976,96,56,True)
        for n,(name,command) in enumerate([("账户",self.account_details),("阅读时长",lambda:show_stats(self)),
                                           ("版本信息",lambda:show_versions(self))]):
            page.row(name,command,936+96*n,96)
        client,account,generation=self.client,self.client.account,self.generation
        def active():
            return self.generation==generation and self.client is client and client.account==account
        def summary(result):
            for k,widget in totals.items():
                times=result[1]
                widget.configure(text=minute_duration(times[k]) if k in times else "未获取")
        self.submit(lambda:account_stats(client,self.store,self.kindle,account,active),summary,
                    lambda _:summary(("",{})))
        query()

    def account_details(self):
        self.clear()
        from pw3_page import Page
        page=Page(self)
        page.title("账户")
        page.footer([("‹ 返回",self.profile)])
        self.status=tk.StringVar()
        page.label("",48,1250,976,82,26,color="#555555").configure(textvariable=self.status)
        profile=self.store.get(self.client.account,"profile") or {}
        page.label(profile.get("name") or "当前账户",48,295,976,88,44,True)
        client = self.client
        pending = set()
        sections = []
        def member(data):
            if data["permanent"]:
                return "终身会员卡"
            left = data["ends"] - int(time.time())
            if data["expired"] or left <= 0:
                return "无有效会员卡"
            days = (left + 86399) // 86400
            ends = time.strftime("%Y-%m-%d", time.localtime(data["ends"]))
            return f"还剩 {days} 天 · {ends} 到期"
        for title, key, fetch, describe, action, params in (
            ("书币余额", "account-balance", client.account_balance, lambda d: f"{d['balance']:.2f} 书币（Android）",
             "充值书币", {"schemeName": "account", "from": "ReaderRecharge"}),
            ("会员卡", "membership", client.membership, member,
             "购买会员卡", {"schemeName": "memCard", "from": "ReaderMemberCard", "memCardExpand": 1}),
        ):
            i=len(sections)
            y=456+132*i
            page.label("会员状态" if i else title,48,y,340,100,36)
            value=tk.StringVar()
            label=page.label("",400,y,624,100,28,anchor="e")
            label.configure(textvariable=value,wraplength=round(600*page.factor),justify="right")
            page.line(48,y+113,976,"#dddddd")
            page.button(action,lambda name=action,query=params:self.account_qr(name,query),
                        48+496*i,780,478,88,outline=True)
            sections.append((key, fetch, describe, value))
        def refresh():
            button.configure(state="disabled")
            errors = []
            self.status.set("正在读取账户信息…")
            def finish(key):
                pending.remove(key)
                if not pending:
                    self.status.set("；".join(errors))
                    button.configure(state="normal")
            for key, fetch, describe, value in sections:
                pending.add(key)
                cached = self.store.get(client.account, key)
                stamp = time.strftime("%m-%d %H:%M", time.localtime(cached["updated"])) if cached else ""
                value.set(describe(cached) + f"　上次更新 {stamp}" if cached else "正在读取…")
                def ready(data, k=key, label=value, fmt=describe):
                    label.set(fmt(data))
                    finish(k)
                def failed(error, k=key, label=value, old=cached):
                    self.error(error)
                    if self.status.get() not in errors:
                        errors.append(self.status.get())
                    if not old:
                        label.set("暂未获取")
                    finish(k)
                self.submit(fetch, ready, failed)
        button=page.button("刷新",refresh,884,118,140,88,anchor="e")
        page.button("退出登录",self.confirm_sign_out,48,1154,976,88,outline=True)
        refresh()

    def account_qr(self, title, query):
        self.clear()
        from pw3_page import Page
        page = Page(self)
        page.title(title)
        page.footer([("‹ 返回", self.account_details)])
        page.label("用微信扫码", 48, 300, 976, 90, 36, True, anchor="center")
        qr = qrcode.QRCode(box_size=4, border=4)
        qr.add_data(WEB + "/web/redirect?" + urlencode(query))
        side = round(420 * page.factor)
        picture = qr.make_image().convert("L").resize((side, side), Image.NEAREST)
        image = photo(picture)
        self.photos.append(image)
        page.put(tk.Label(page.frame, image=image, bg="white"), 326, 375, 420, 420)
        page.label("请在手机微信读书核对账号后办理。", 48, 850, 976, 70, 32, anchor="center").configure(
            wraplength=round(976*page.factor), justify="center")

    def confirm_action(self, title, message, confirm_label, accept, cancel, cancel_label="取消"):
        # The calling page already drew its own header; the overlay only covers the
        # body below the header rule (design y=226) so that header stays visible but
        # inert under the modal's grab.
        previous = self.root.focus_get()
        unit = 1 if self.kindle else 0.5
        header_bottom = 226
        overlay = tk.Frame(self.frame, bg="white")
        overlay.place(relx=0, rely=(header_bottom-88)/1360, relwidth=1, relheight=(1448-header_bottom)/1360,
                      bordermode="outside")
        box_x, box_y, box_w, box_h = 104, 470, 864, 484
        span = 1448 - header_bottom
        panel = tk.Frame(overlay, bg="white", highlightthickness=round(3*unit), highlightbackground="#222222")
        panel.place(relx=box_x/1072, rely=(box_y-header_bottom)/span, relwidth=box_w/1072, relheight=box_h/span)
        def locate(widget, x, y, w, h):
            widget.place(relx=(x-box_x)/box_w, rely=(y-box_y)/box_h, relwidth=w/box_w, relheight=h/box_h)
        locate(tk.Label(panel, text=title, bg="white", fg="#222222", anchor="w",
                        font=(FONT, -round(44*unit), "bold")), 152, 500, 768, 100)
        locate(tk.Label(panel, text=message, bg="white", fg="#222222", anchor="w", justify="left",
                        wraplength=round(768*unit), font=(FONT, -round(32*unit))), 152, 616, 768, 160)
        def finish(callback):
            if not overlay.winfo_exists():
                return
            overlay.grab_release()
            overlay.destroy()
            if previous and previous.winfo_exists():
                previous.focus_set()
            if callback:
                callback()
        buttons = []
        for i, (label, callback) in enumerate(((cancel_label, cancel), (confirm_label, accept))):
            button = self.button(panel, label, lambda f=callback: finish(f))
            button.configure(font=(FONT, -round(28*unit)), bg="#222222" if i else "white",
                             fg="white" if i else "#222222", highlightthickness=round(2*unit),
                             highlightbackground="#222222")
            locate(button, 153 + i*416, 815, 348, 86)
            button.bind("<Escape>", lambda _: finish(cancel) or "break")
            buttons.append(button)
        for i, button in enumerate(buttons):
            for key in ("<Tab>", "<Shift-Tab>", "<ISO_Left_Tab>"):
                button.bind(key, lambda _, other=buttons[1-i]: other.focus_set() or "break")
        overlay.grab_set()
        buttons[0].focus_set()
        return overlay

    def confirm_app_exit(self, cancel=None):
        self.confirm_action("退出微信读书？", "保存当前阅读位置并关闭应用。\n下次打开时可继续使用当前账号。",
                         "退出应用", self.close, cancel or self.settings)

    def confirm_sign_out(self):
        def sign_out():
            import sqlite3
            try:
                self.store.forget_session(self.client.account)
            except sqlite3.Error:
                self.status.set("未能保存退出状态，请重试。")
                return
            self.client.signed_out = True
            self.client = Client(self.store, restore=False)
            self.books, self.rows = [], []
            self.query, self.shelf_page = "", 0
            self.book = self.uid = self.loaded = None
            self.login()
        self.confirm_action("退出当前账号？", "这台 Kindle 下次使用微信读书时，需要重新扫码登录。",
                         "确认退出登录", sign_out, self.account_details)

    def settings(self):
        self.clear()
        from pw3_page import Page
        page=Page(self)
        page.title("设置")
        page.footer([("‹ 返回",self.profile)])
        account=self.client.account
        for i,(name,key,default) in enumerate((
                ("个性化推荐","personal-recommendations",True),("点击左侧翻到下一页","left-tap-next",False),
                ("安全模式","safe-mode",False),("阅读时显示章节内页码","chapter-pages",False))):
            y=282+134*i
            enabled = tk.BooleanVar(value=bool(self.store.get(account, key, default=default)))
            switch = tk.Canvas(page.frame, bg="white", bd=0, highlightthickness=0,
                               takefocus=True, cursor="hand2")
            page.put(switch, 898, y, 126, 108)
            def paint(_event=None, canvas=switch, flag=enabled):
                w, h = canvas.winfo_width(), canvas.winfo_height()
                ink = "#222222"
                canvas.delete("all")
                x, top, right, bottom = w*.14, h*.25, w*.9, h*.73
                radius = (bottom-top)/2
                center = (top+bottom)/2
                fill = ink if flag.get() else "white"
                canvas.create_line(x+radius, center, right-radius, center, width=max(1, 2*radius),
                                   capstyle="round", fill=ink)
                if not flag.get():
                    canvas.create_line(x+radius, center, right-radius, center, width=max(1, 2*radius-4),
                                       capstyle="round", fill=fill)
                cx = right-radius if flag.get() else x+radius
                r = radius*.72
                canvas.create_oval(cx-r, center-r, cx+r, center+r, fill="white" if flag.get() else ink, width=0)
            def change(_event=None, k=key, flag=enabled, redraw=paint):
                flag.set(not flag.get())
                self.store.put(account, k, "", flag.get())
                redraw()
                return "break"
            switch.bind("<Configure>", paint)
            for event in ("<ButtonRelease-1>", "<space>", "<Return>"):
                switch.bind(event, change)
            page.button(name,change,48,y,850,76 if key=="safe-mode" else 108,36,anchor="w")
            if key=="safe-mode":
                page.button("开启后禁用书籍下载",change,48,y+70,850,42,26,anchor="w").configure(fg="#555555")
            page.line(48,y+120,976,"#dddddd")
        page.row("清理缓存",self.cache_settings,816,122)
        if self.kindle:
            page.button("退出应用",self.confirm_app_exit,48,1160,976,88,outline=True)

    def cache_settings(self):
        from concurrent.futures import wait
        from pw3_page import Page
        self.clear()
        page = Page(self)
        page.title("清理缓存")
        page.footer([("‹ 返回", self.settings)])
        self.status = tk.StringVar(value="正在统计当前账号的缓存…")
        page.label("清理正文、插图、章节目录和公众号文章列表。保留书架、阅读位置、阅读记录和草稿。",
                   48, 282, 976, 100, 32).configure(wraplength=round(976*page.factor), justify="left")
        account = self.client.account
        def size(count):
            if count < 1024:
                return f"{count} B"
            if count < 1048576:
                return f"{count/1024:.1f} KiB"
            return f"{count/1048576:.1f} MiB"
        payload = page.label("", 48, 460, 460, 88, 36)
        payload_value = page.label("", 512, 460, 512, 88, 28, color="#555555", anchor="e")
        page.line(48, 548, 976, "#dddddd")
        files = page.label("", 48, 548, 460, 88, 36)
        files_value = page.label("", 512, 548, 512, 88, 28, color="#555555", anchor="e")
        page.line(48, 636, 976, "#dddddd")
        payload.configure(text="缓存内容")
        files.configure(text="当前账号独用的图片文件")
        def finished(result):
            self.status.set(f"已清理 {result['rows']} 条缓存，删除图片文件 {size(result['file_bytes'])}。"
                            f"数据库新增可复用整页 {size(result['reusable'])}。")
            trigger.place_forget()
        def failed(error):
            trigger.configure(state="normal")
            self.status.set("未完成清理，请检查存储后重试。" if isinstance(error, OSError) else str(error))
        def clear():
            trigger.configure(state="disabled")
            self.status.set("正在清理缓存…")
            pictures = tuple(self.articles.picture_jobs) if self.articles else ()
            def work():
                wait(pictures)
                return self.store.reading_cache(account, clear=True)
            self.submit(work, finished, failed)
        def confirm():
            self.confirm_action("清理当前账号的阅读缓存？", "清理后，正文、插图和列表需重新载入。",
                                "确认清理", clear, None)
        trigger = page.button("清理缓存", confirm, 48, 1146, 976, 88, outline=True)
        trigger.place_forget()
        def loaded(result):
            payload_value.configure(text=size(result["payload"]))
            files_value.configure(text=size(result["file_bytes"]))
            self.status.set(f"缓存内容 {size(result['payload'])}，当前账号独用的图片文件 {size(result['file_bytes'])}。")
            if result["rows"] or result["file_bytes"]:
                page.put(trigger, 48, 1146, 976, 88)
        self.submit(lambda: self.store.reading_cache(account), loaded,
                    lambda _: self.status.set("无法读取缓存，请返回后重试。"))
        page.label("", 48, 1256, 976, 70, 26, color="#555555").configure(textvariable=self.status)

    def error(self, error):
        if isinstance(error, ReaderError):
            self.status.set(str(error))
        elif isinstance(error, (OSError, URLError)):
            self.status.set("连接失败，请检查网络后重试。")
        else:
            self.status.set("返回的数据无法读取，请重试。")

    def login(self, for_stats=False, resume=None, back=None):
        from login_page import LoginPage
        self.clear()
        def refresh():
            self.login(for_stats=for_stats, resume=resume, back=back)
        cancel = back or (self.show_shelf if self.client.account else None)
        self.status = tk.StringVar(value="正在获取二维码…")
        page = LoginPage(self, FONT, "返回" if cancel else "退出应用",
                         cancel or (lambda: self.confirm_app_exit(refresh)), refresh, photo)
        self.qr = page.qr
        def failed(error):
            page.invalidate()
            self.error(error)
            if "刷新" not in self.status.get():
                self.status.set(self.status.get().rstrip("。") + "，请刷新二维码。")
        client = Client(self.store, restore=False)
        if self.kindle or os.name == "nt":
            from native_login import NativeLogin
            from urllib.parse import quote
            native = NativeLogin(self.store)
            generation = self.generation
            expected = self.client.account if for_stats or resume else None
            def show_qr(link):
                page.display(link)
                self.status.set("等待扫码")
                deadline = time.monotonic() + 300
                def poll():
                    if self.generation != generation:
                        return
                    if time.monotonic() >= deadline:
                        page.invalidate()
                        self.status.set("二维码已过期，请刷新。")
                        return
                    self.submit(native.poll, finished, failed)
                def finished(result):
                    if result is None:
                        if native.last == 404:
                            self.status.set("已扫码，请在手机上确认")
                        self.root.after(900, poll)
                        return
                    account, token = result
                    if expected and account != expected:
                        page.invalidate()
                        self.status.set("扫码账号与当前书架不同，请用原账号重新扫码。")
                        return
                    client.cookie("wr_vid", account)
                    client.cookie("wr_skey", quote(token, safe=""))
                    self.store.save_native_session(client.session())
                    self.client.signed_out = True
                    self.client = client
                    self.books, self.rows = [], []
                    if not expected:
                        self.query, self.shelf_page = "", 0
                    if resume:
                        resume()
                    elif for_stats:
                        from account_stats import show_stats
                        show_stats(self)
                    else:
                        self.show_shelf(sync=True)
                poll()
            self.submit(native.begin, show_qr, failed)
            return
        def display(uid):
            self.login_uid = uid
            link = WEB + "/web/confirm?" + urlencode({"uid": uid})
            page.display(link)
            self.status.set("等待扫码")
            self.poll(client, uid, time.monotonic() + 300)
        self.submit(client.begin, display, failed)

    def poll(self, client, uid, deadline, otp=""):
        if time.monotonic() >= deadline:
            self.status.set("二维码已过期，请刷新。")
            return
        version = self.generation
        def again():
            if version == self.generation:
                self.poll(client, uid, deadline, otp)
        def finished(state):
            if state == "ok":
                self.client.signed_out = True
                self.client = client
                self.store.put("", "session", "", client.session())
                self.query, self.shelf_page = "", 0
                self.show_shelf(sync=True)
            elif state in ("NEED_OTP", "OTP_NOT_MATCH"):
                hint = "请输入手机显示的验证码" if state == "NEED_OTP" else "验证码不正确，请重新输入"
                if KINDLE:
                    self.otp_input(hint, lambda code: self.poll(client, uid, deadline, code))
                    return
                code = simpledialog.askstring("微信读书验证", hint, parent=self.root)
                if code and version == self.generation:
                    self.poll(client, uid, deadline, code.strip())
                else:
                    self.status.set("已取消验证，可刷新二维码重新登录。")
            elif state in ("LOGIN_TIMEOUT", "OTP_EXPIRED"):
                self.status.set("登录已过期，请刷新二维码。")
            elif state == "waiting":
                self.root.after(1000, again)
            else:
                self.status.set("微信读书未确认登录，请刷新二维码。")
        self.submit(lambda: client.poll(uid, otp), finished)

    def otp_input(self, hint, submit):
        self.clear()
        self.header("微信读书验证", self.login)
        self.status_line()
        self.status.set(hint)
        code = tk.StringVar()
        tk.Label(self.frame, textvariable=code, font=(FONT, 19)).pack(pady=12)
        pad = tk.Frame(self.frame)
        pad.pack()
        def press(key):
            if key == "删除":
                code.set(code.get()[:-1])
            elif key == "确认":
                if code.get():
                    pad.destroy()
                    self.status.set("正在验证…")
                    submit(code.get())
            else:
                code.set(code.get() + key)
        for n, key in enumerate((*"123456789", "删除", "0", "确认")):
            button = self.button(pad, key, lambda k=key: press(k))
            button.configure(width=5)
            button.grid(row=n // 3, column=n % 3, padx=3, pady=3)

    def show_shelf(self, sync=False):
        self.clear()
        self.book = self.uid = self.loaded = None
        self.book_back = self.show_shelf
        self.shelf_grid.load_archives()
        cached = self.store.get(self.client.account, "shelf")
        self.books = [book for book in cached or [] if book.get("bookId") != "mpbook"]
        self.status = tk.StringVar()
        self.shelf_grid.load_columns()
        self.shelf_grid.controls()
        self.search = tk.StringVar(value=self.query)
        def search(*_):
            self.query = self.search.get()
            self.shelf_page = 0
            self.shelf_grid.redraw_tiles()
        self.search.trace_add("write", search)
        self.grid()
        if sync or cached is None:
            self.status.set("正在同步书架…" if cached is None else "已显示本地书架，正在同步…")
            client = self.client
            def sync_books():
                from legacy_paths import legacy_directories
                from legacy_settings import migrate_settings
                directories = legacy_directories(self.store, self.kindle)
                if directories:
                    migrate_settings(self.store, client.account, *directories)
                return client.shelf()
            def loaded(books):
                self.books = books
                self.activity.sync(check_unknown=True)
                self.shelf_grid.load_columns()
                self.shelf_grid.load_archives()
                if self.search.get() != self.query:
                    page = self.shelf_page
                    self.search.set(self.query)
                    self.shelf_page = page
                self.status.set("")
                self.grid()
            def failed(error):
                self.shelf_grid.load_columns()
                self.grid()
                self.error(error)
            self.submit(sync_books, loaded, failed)
        else:
            self.status.set("")

    def grid(self):
        self.shelf_grid.render()

    def open_book(self, book, back=None):
        self.clear()
        client = self.client
        self.book = book
        self.book_back = back or self.show_shelf
        key = str(book["bookId"])
        self.uid = self.loaded = None
        self.rows = []
        if key.startswith("MP_WXS_"):
            from articles import Articles
            if self.articles is None:
                self.articles = Articles(self)
            self.articles.open(book)
            return
        self.header("打开书籍", self.book_back)
        self.status_line()
        self.status.set(book["title"] + " · 正在读取目录…")
        self.button(self.frame, "重试", lambda: self.open_book(book, back)).pack()
        account = client.account
        pos = self.store.get(account, "position", key, {})
        legacy = None
        def load_catalog():
            nonlocal legacy
            if account and not pos:
                from legacy_paths import legacy_directories
                from legacy_positions import last_chapter
                directories = legacy_directories(self.store, self.kindle)
                if directories:
                    legacy = last_chapter(directories[1], account, key)
            return client.catalog(key)
        def ready(rows):
            self.rows = rows
            cloud = self.store.get(account, "cloud-position", key) or {}
            if legacy:
                from legacy_positions import first_position
                cloud = first_position(legacy, cloud, rows)
            # Positions written by older builds have no timestamp; keep their local anchor.
            newer = cloud and (not pos or (pos.get("changed") and cloud["changed"] > pos["changed"]))
            chosen = cloud if newer else pos
            uid = chosen.get("uid")
            target = next((r for r in rows if str(r["chapterUid"]) == uid), None)
            if uid and not target:
                self.catalog()
                self.status.set("上次阅读的章节已不在目录中，请选择章节。")
                return
            target = target or next((r for r in rows if r.get("wordCount", 1)), rows[0])
            self.read(target, chosen.get("index", "1.0"), cloud=cloud if newer else None)
        def failed(exc):
            cached = self.store.get(self.client.account, "catalog", key)
            if cached and isinstance(exc, (URLError, TimeoutError, ConnectionError)):
                ready(cached)
            else:
                self.error(exc)
        self.sync_book_marks = False
        def online(rows):
            self.sync_book_marks = bool(account)
            ready(rows)
        self.submit(load_catalog, online, failed)

    def catalog(self):
        from catalog import BookCatalog
        self.catalog_view = BookCatalog(self)

    def search_book(self, initial="", back=None):
        """Design 15: 搜全书 — search field + button, chapter·abstract rows, footer 更多结果."""
        self.clear()
        client = self.client
        back = back or self.catalog
        from pw3_page import Page, INK, SECONDARY
        page = Page(self)
        page.title("搜全书")
        term = tk.StringVar(value=initial)
        matches = []
        chapters = {str(row["chapterUid"]): row for row in self.rows}
        keyword, cursor = "", None
        region = tk.Frame(page.frame, bg="white")
        page.put(region, 48, 484, 976, 650)
        canvas = tk.Canvas(region, bg="white", bd=0, highlightthickness=0)
        scrollbar = tk.Scrollbar(region, command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        rows = tk.Frame(canvas, bg="white")
        window = canvas.create_window((0, 0), window=rows, anchor="nw")
        rows.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window, width=e.width))
        def wheel(event):
            canvas.yview_scroll(int(-event.delta / 40), "units")
        def bind_wheel(widget):
            widget.bind("<MouseWheel>", wheel)
            for child in widget.winfo_children():
                bind_wheel(child)
        canvas.bind("<MouseWheel>", wheel)
        def open_hit(chapter, hit):
            self.read(chapter, hit=hit)
        def add_row(chapter, hit):
            entry = tk.Frame(rows, bg="white")
            entry.pack(fill="x")
            top = tk.Frame(entry, bg="white")
            top.pack(fill="x", pady=(14, 0))
            tk.Label(top, text=chapter["title"], font=page.font(36, True), bg="white", fg=INK,
                     anchor="w").pack(side="left", fill="x", expand=True)
            tk.Label(top, text="›", font=page.font(28), bg="white", fg=SECONDARY,
                     anchor="e").pack(side="right")
            tk.Label(entry, text=page.shorten(str(hit.get("abstract", "")), 900, 28), font=page.font(28),
                     bg="white", fg=SECONDARY, anchor="w").pack(fill="x", pady=(4, 14))
            tk.Frame(entry, bg="#dddddd", height=2).pack(fill="x")
            for widget in (entry, top, *top.winfo_children()):
                widget.bind("<ButtonRelease-1>", lambda _e, c=chapter, h=hit: open_hit(c, h))
            bind_wheel(entry)
        def search(_=None, more=False):
            nonlocal keyword, cursor
            if not more:
                keyword, cursor = term.get().strip(), 0
                matches.clear()
                for child in rows.winfo_children():
                    child.destroy()
            if not keyword or cursor is None:
                return
            self.generation += 1
            more_button.configure(state="disabled")
            word, start, book = keyword, cursor, str(self.book["bookId"])
            self.status.set("正在搜索…")
            def done(response):
                nonlocal cursor
                hits, cursor = response
                for hit in hits:
                    chapter = chapters.get(str(hit.get("chapterUid")))
                    if chapter:
                        matches.append((chapter, hit))
                        add_row(chapter, hit)
                self.status.set(f"已找到 {len(matches)} 处" if matches else "未找到匹配内容")
                more_button.configure(state="normal" if cursor is not None else "disabled")
            def failed(err):
                self.error(err)
                more_button.configure(state="normal" if cursor is not None else "disabled")
            self.submit(lambda: client.search_book(book, word, int(start)), done, failed)
        field = page.search(term, "搜索本书正文", search, end=852)
        page.button("搜索", search, 870, 256, 154, 88, outline=True)
        page.label((self.book.get("title") or "") + "　·　搜索结果", 48, 394, 976, 70, 36, True)
        self.status = tk.StringVar()
        page.label("", 48, 1180, 976, 72, 26, color=SECONDARY).configure(textvariable=self.status)
        footer = page.footer([("‹ 返回", back), ("更多结果", lambda: search(more=True))])
        more_button = footer["更多结果"]
        more_button.configure(state="disabled")
        field.focus_set()
        if initial:
            search()

    def official_chapter(self, row, url):
        """Design 19: 官方阅读页 — centered QR with Kindle-browser and retry actions."""
        self.clear()
        from pw3_page import Page, SECONDARY
        page = Page(self)
        page.title("官方阅读页")
        page.label("用手机扫码阅读本章", 0, 300, 1072, 70, 36, True, "center")
        qr = qrcode.QRCode(box_size=4*SCALE, border=4)
        qr.add_data(url)
        image = photo(qr.make_image().convert("L"))
        self.photos.append(image)
        qr_area = tk.Frame(page.frame, bg="white")
        page.put(qr_area, 0, 380, 1072, 360)
        tk.Label(qr_area, image=image, bg="white").place(relx=.5, rely=.5, anchor="center")
        page.label(self.book["title"] + "　·　" + row["title"], 0, 752, 1072, 56, 28,
                   anchor="center", color=SECONDARY)
        self.status = tk.StringVar()
        page.label("", 48, 1236, 976, 60, 26, color=SECONDARY).configure(textvariable=self.status)
        def launch():
            if self.kindle:
                import subprocess
                try:
                    subprocess.run(["lipc-set-prop", "-s", "com.lab126.appmgrd", "start",
                                    "app://com.lab126.browser?view=" + url], check=True, timeout=3)
                except (OSError, subprocess.SubprocessError):
                    self.status.set("Kindle 浏览器未打开，请用手机扫码继续。")
            else:
                import webbrowser
                if not webbrowser.open(url):
                    self.status.set("未能打开默认浏览器，请用手机扫码继续。")
        page.button("在 Kindle 浏览器打开" if self.kindle else "在浏览器打开本章", launch,
                    48, 1066, 976, 96, 32, outline=True)
        page.button("重试本机阅读", lambda: self.read(row), 48, 1180, 976, 96, 32, outline=True)
        page.footer([("‹ 返回", self.catalog)])

    def read(self, row, index="1.0", loaded=None, hit=None, cloud=None, source_offset=None, turn=None):
        key, uid = str(self.book["bookId"]), str(row["chapterUid"])
        client = self.client
        was_reading = self.activity.ready
        self.activity.reading(False)
        self.status.set("正在打开 " + row["title"] + "…")
        self.generation += 1
        def failed(exc):
            if isinstance(exc, OfficialChapterRequired):
                self.official_chapter(row, exc.url)
                return
            cached = None
            if isinstance(exc, (URLError, TimeoutError, ConnectionError)):
                cached = self.store.get(self.client.account, "chapter", json.dumps([key, uid]))
            if cached:
                render(cached)
                self.status.set("离线阅读")
            else:
                self.error(exc)
                if self.text is not None:
                    self.activity.reading(was_reading)
                if self.text is None:
                    if not getattr(self, "toc_retry", None) or not self.toc_retry.winfo_exists():
                        self.toc_retry = self.button(self.frame, "查看目录", self.catalog)
                        self.toc_retry.pack()
        def render(result, online=False):
            nonlocal index
            import variants
            result = variants.for_reader(self, result)
            content = blocks(result)
            self.clear()
            self.uid = uid
            self.loaded = result
            self.reading_blocks = content
            self.saver.remember(self.book)
            left_next = self.store.get(self.client.account, "left-tap-next", default=False)
            unit = 1 if self.kindle else .5
            from notes import BookNotes, show_underlines
            import reader_options
            from reader_fonts import family
            # Persistent top strip: back control plus the book title (design 11/12).
            chapter_strip = tk.Frame(self.frame)
            chapter_strip.pack(fill="x")
            if self.kindle:
                self.button(chapter_strip, "‹ 返回", self.book_back).pack(side="left")
            tk.Label(chapter_strip, text=self.book.get("title") or "", fg="#505050", anchor="w").pack(side="left")
            # Chapter heading, kept outside the Text widget so source offsets/anchors are untouched.
            chapter_label = self.status_line(self.frame)
            chapter_label.configure(font=(FONT, -round(40*unit), "bold"), fg="#222222")
            chapter_status = row["title"] + ("　·　试读" if result["preview"] else "")
            self.status.set(chapter_status)
            if result.get("officialChapter"):
                self.button(self.frame, "官方阅读本章", lambda: self.official_chapter(
                    row, result["officialChapter"])).pack(anchor="w")
            footer = tk.Label(self.frame, anchor="e")
            footer.pack(side="bottom", fill="x")
            menu = tk.Frame(self.frame)
            menu.pack(side="bottom", fill="x")
            position = self.rows.index(row)
            # Toggle-only overlay header (design 12): back, book title, then the three direct actions.
            bar = tk.Frame(self.frame)
            self.button(bar, "‹ 返回", self.book_back).pack(side="left")
            tk.Label(bar, text=self.book.get("title") or "", fg="#222222", anchor="w").pack(side="left", padx=(4, 0))
            self.button(bar, "加书签", lambda: BookNotes(self, show_list=False).bookmark()).pack(side="right")
            self.button(bar, "正文版本", lambda: variants.show(self, row)).pack(side="right")
            self.button(bar, "搜全书", self.search_book).pack(side="right")

            def close_menu():
                self.system_bar(False)
                bar.place_forget()
                menu.place_forget()
                hide_panels()
                self.activity.reading(True)

            # px() converts design/12*.svg device-pixel coordinates (drawn for a 1072x1448 canvas)
            # straight into widget geometry, instead of letting pack() derive sizes from each
            # platform's default Button padding/font metrics, which is what left the panels far
            # shorter than the design on the ARM reader.
            px = lambda v: round(v*unit)
            tk.Frame(menu, bg="#aaaaaa", height=2).pack(side="top", fill="x")
            panel_area = tk.Frame(menu)
            panel_area.pack(side="top", fill="x")
            actions_row = tk.Frame(menu, height=px(94))
            actions_row.pack(side="top", fill="x")
            actions_row.pack_propagate(False)

            # 排版面板 (design 12a): inline font size plus the real typography-settings page.
            # Panel height/positions below match design 12a's SVG rects exactly (panel top = y1020,
            # so local y = svg_y - 1020); each candidate panel reserves the full 334px design height
            # so the fixed bottom toolbar lands at the same spot regardless of which panel is open.
            PANEL_H = 334
            layout_panel = tk.Frame(panel_area, height=px(PANEL_H))
            layout_panel.pack_propagate(False)
            tk.Label(layout_panel, text="字号", font=(FONT, -px(36), "bold"), fg="#222222"
                     ).place(x=px(48), y=px(57), anchor="w")
            smaller = self.button(layout_panel, "－", lambda: self.font_size(-1))
            smaller.configure(relief="solid", bd=1, font=(FONT, -px(28)))
            smaller.place(x=px(361), y=px(14), width=px(126), height=px(86))
            size_display = tk.Label(layout_panel, font=(FONT, -px(36)), fg="#222222")
            size_display.place(x=px(487), y=px(14), width=px(187), height=px(86))
            larger = self.button(layout_panel, "＋", lambda: self.font_size(1))
            larger.configure(relief="solid", bd=1, font=(FONT, -px(28)))
            larger.place(x=px(674), y=px(14), width=px(126), height=px(86))
            def update_size_display():
                pixels = self.root.winfo_fpixels(f"{self.size}p")
                size_display.configure(text=str(round(pixels)))
                smaller.configure(state="disabled" if self.size <= 10 else "normal")
                larger.configure(state="disabled" if self.size >= 30 else "normal")
            self.update_size_display = update_size_display
            update_size_display()
            layout_settings = self.button(layout_panel, "排版设置", lambda: reader_options.edit(self, row))
            layout_settings.configure(relief="solid", bd=1, font=(FONT, -px(28)))
            layout_settings.place(x=px(49), y=px(161), width=px(974), height=px(86))

            # 笔记面板 (design 12b): the three real note/review entry points, each its own next page.
            notes_panel = tk.Frame(panel_area, height=px(PANEL_H))
            notes_panel.pack_propagate(False)
            note_x = 49.0
            for title, command in (
                    ("笔记与书评", lambda: BookNotes(self)),
                    ("划线 / 写想法", lambda: BookNotes(self, show_list=False).select_text()),
                    ("查看书评", lambda: BookNotes(self, show_list=False).select("reviews"))):
                btn = self.button(notes_panel, title, command)
                btn.configure(relief="solid", bd=1, font=(FONT, -px(28)))
                btn.place(x=px(note_x), y=px(46), width=px(313.33), height=px(86))
                note_x += 330.33

            # 进度面板 (design 12c): current position plus the existing chapter navigation.
            progress_panel = tk.Frame(panel_area, height=px(PANEL_H))
            progress_panel.pack_propagate(False)
            tk.Label(progress_panel, text="阅读进度", font=(FONT, -px(36), "bold"), fg="#222222"
                     ).place(x=px(48), y=px(50), anchor="w")
            progress_value = tk.Label(progress_panel, font=(FONT, -px(28)), fg="#222222")
            progress_value.place(x=px(1024), y=px(50), anchor="e")
            progress_track = tk.Frame(progress_panel, bg="#cccccc")
            progress_track.place(x=px(48), y=px(105), width=px(976), height=px(8))
            progress_fill = tk.Frame(progress_track, bg="#333333")
            progress_fill.place(relx=0, rely=0, relheight=1, relwidth=0)
            for delta, title, x in ((-1, "‹ 上一章", 49.0), (1, "下一章 ›", 544.5)):
                target = position + delta
                btn = self.button(progress_panel, title, lambda k=target: self.read(self.rows[k]))
                btn.configure(font=(FONT, -px(28)), relief="solid", bd=1)
                btn.place(x=px(x), y=px(149), width=px(478.5), height=px(86))
                if not 0 <= target < len(self.rows):
                    btn.configure(state="disabled")
            def refresh_progress_panel():
                progress_value.configure(text=footer.cget("text"))
                progress_fill.place_configure(relwidth=max(0.0, min(1.0, self.text.yview()[1])))

            # Bottom toolbar (design 12): 目录/笔记/进度/排版/收起 stay visible in a fixed 94px strip
            # inset by 48px on each side (matching the panels' left margin above); only 笔记/进度/排版
            # expand a panel in place, 目录/收起 act immediately.
            panels = {"layout": layout_panel, "notes": notes_panel, "progress": progress_panel}
            tab_buttons = {}
            panel_open = {"name": None}
            def hide_panels():
                for panel in panels.values():
                    panel.pack_forget()
                for btn in tab_buttons.values():
                    btn.configure(font=(FONT, -px(28)))
                panel_open["name"] = None
            def show_panel(name):
                opening = panel_open["name"] != name
                hide_panels()
                if opening:
                    panels[name].pack(fill="x")
                    tab_buttons[name].configure(font=(FONT, -px(28), "bold"))
                    panel_open["name"] = name
                    if name == "progress":
                        refresh_progress_panel()
            TAB_W = 195.2
            for i, (title, name, command) in enumerate((
                    ("目录", None, self.catalog),
                    ("笔记", "notes", lambda: show_panel("notes")),
                    ("进度", "progress", lambda: show_panel("progress")),
                    ("排版", "layout", lambda: show_panel("layout")),
                    ("收起", None, close_menu))):
                btn = self.button(actions_row, title, command)
                btn.configure(font=(FONT, -px(28)))
                btn.place(x=px(48 + i*TAB_W), y=0, width=px(TAB_W), height=px(94))
                if name:
                    tab_buttons[name] = btn
            text = self.text = tk.Text(self.frame, wrap="char", relief="flat", padx=5, pady=8,
                                       font=(family(self, BODY_FONT), self.size), spacing1=4, spacing3=6,
                                       cursor="arrow", highlightthickness=0)
            reader_options.apply(text, reader_options.settings(self.store))
            text.pack(fill="both", expand=True)
            placeholders = []
            for block in content:
                if block[0] == "paragraphs":
                    reader_options.insert_paragraphs(text, block[1], plain_text=result["format"] == "text")
                else:
                    label = tk.Label(text, text=block[3] or "插图", fg="#666666")
                    text.window_create("end", window=label)
                    text.insert("end", "\n")
                    placeholders.append((block[1], label))
            text.configure(state="disabled")
            mark_version = result.get("version", self.book.get("version"))
            cache_key = json.dumps([key, uid])
            def draw_marks(_=None):
                mine = self.store.get(client.account, "book-highlights", key, [])
                shared = self.store.get(client.account, "chapter-underlines", cache_key, {})
                marks = shared.get("marks", []) if shared.get("version") == mark_version else []
                show_underlines(text, uid, result, content, mine, marks)
            draw_marks()
            if self.sync_book_marks:
                self.sync_book_marks = False
                def mine_failed(error):
                    self.sync_book_marks = True
                    self.status.set(chapter_status + "　·　个人划线未同步")
                self.submit(lambda: client.notes_page(key, "mine"), draw_marks, mine_failed)
            if online and client.account:
                def underline_error(error):
                    if self.status.get() == chapter_status:
                        self.status.set(chapter_status + "　·　章节划线未同步")
                self.submit(lambda: client.chapter_underlines(key, uid, mark_version), draw_marks, underline_error)
            from reader_progress import ReadingProgress
            self.progress = ReadingProgress(text, footer, self.rows, position, result["preview"],
                                           self.store.get(self.client.account, "chapter-pages", default=False),
                                           full_pages=self.kindle)
            bar.pack_forget()
            menu.pack_forget()
            self.system_bar(False)
            def toggle(_=None):
                if getattr(text, "selecting_words", False):
                    return "break"
                if menu.winfo_manager():
                    close_menu()
                else:
                    self.system_bar(True)
                    bar.place(x=0, y=0, relwidth=1)
                    menu.place(relx=0, rely=1, anchor="sw", relwidth=1)
                    bar.lift()
                    menu.lift()
                    self.activity.reading(False)
                text.focus_set()
                return "break"
            chapter_label.bind("<ButtonRelease-1>", toggle)
            footer.bind("<ButtonRelease-1>", toggle)
            hold = None
            def cancel_hold(_=None):
                nonlocal hold
                if hold is not None:
                    self.root.after_cancel(hold)
                    hold = None
            def select_word(index):
                nonlocal hold
                hold = None
                if self.text is text and not self.saver.overlay and not self.saver.sleeping:
                    BookNotes(self, show_list=False).select_text(index)
            def press(event):
                nonlocal hold
                if getattr(text, "selecting_words", False):
                    return "break"
                cancel_hold()
                self.press_xy = (event.x_root, event.y_root)
                if event.widget is text and not menu.winfo_manager():
                    index = text.index(f"@{event.x},{event.y}")
                    hold = self.root.after(500, lambda: select_word(index))
                return "break"
            def motion(event):
                if abs(event.x_root-self.press_xy[0]) + abs(event.y_root-self.press_xy[1]) >= 12:
                    cancel_hold()
                return "break"
            def release(event):
                cancel_hold()
                if getattr(text, "selecting_words", False):
                    return "break"
                dx, dy = event.x_root-self.press_xy[0], event.y_root-self.press_xy[1]
                if abs(dx) > max(20, text.winfo_width() * .12) and abs(dx) > abs(dy):
                    if menu.winfo_manager():
                        close_menu()
                    return self.page(1 if dx < 0 else -1)
                if abs(dx)+abs(dy) < 12 or (self.kindle and abs(dy) > abs(dx)):
                    if menu.winfo_manager():
                        return toggle()
                    x = event.x_root - text.winfo_rootx()
                    if event.widget is text and not menu.winfo_manager():
                        for tag in reversed(text.tag_names(f"@{event.x},{event.y}")):
                            mark = text.book_marks.get(tag)
                            if mark:
                                notes = BookNotes(self, show_list=False)
                                notes.passage(uid, mark["range"], mark["quote"], notes.return_to_text)
                                return "break"
                    if not self.kindle and event.y_root-text.winfo_rooty() < 32*SCALE:
                        return toggle()
                    if self.kindle:
                        x = event.x_root - self.root.winfo_rootx()
                        left, right = self.root.winfo_width() * .25, self.root.winfo_width() * .75
                    else:
                        left, right = text.winfo_width() * .30, text.winfo_width() * .65
                    if x < left or x >= right:
                        return self.page(-1 if x < left and not left_next else 1)
                    return toggle()
                return "break"
            for widget in (text, *(label for _, label in placeholders)):
                widget.bind("<ButtonPress-1>", press)
                widget.bind("<B1-Motion>", motion)
                widget.bind("<ButtonRelease-1>", release)
            text.bind("<Destroy>", cancel_hold, add=True)
            for hotkey in ("Right", "Next", "space", "Left", "Prior"):
                text.bind(f"<{hotkey}>", lambda _, k=hotkey: self.page(-1 if k in ("Left", "Prior") else 1))
            def scroll(units):
                before = text.index("@0,0")
                text.yview_scroll(units, "units")
                if text.index("@0,0") != before:
                    self.activity.turned(self.activity.elapsed(), int(time.time()))
                    self.save_position()
                return "break"
            if self.root.tk.call("tk", "windowingsystem") == "win32":
                text.bind("<MouseWheel>", lambda e: scroll(-int(e.delta/120)*3))
            else:
                text.bind("<Button-4>", lambda _: scroll(-3))
                text.bind("<Button-5>", lambda _: scroll(3))
            text.bind("<Up>", lambda _: scroll(-1))
            text.bind("<Down>", lambda _: scroll(1))
            text.bind("<Return>", toggle)
            text.bind("<Escape>", lambda _: toggle() if menu.winfo_manager() else self.book_back() or "break")
            text.bind("<Control-f>", lambda _: self.search_book() or "break")
            text.focus_set()
            self.root.update_idletasks()
            if cloud and cloud["offset"]:
                summary = cloud.get("summary", "").strip()
                location = text.search(summary, "1.0", stopindex="end") if summary else ""
                if (location and not text.search(summary, location+"+1c", stopindex="end")
                        and not variants.hidden_range(result, f"{cloud['offset']}-{cloud['offset']+1}")):
                    index = location
                else:
                    from locations import SourceOffsets
                    try:
                        anchor = SourceOffsets(result, content).index_at(cloud["offset"])
                    except ValueError:
                        anchor = None
                    if anchor:
                        index = anchor
                    else:
                        self.status.set(row["title"] + "　·　已打开云端章节，未定位到原段落")
            if hit:
                excerpt = str(hit.get("abstract") or "").strip("… \t\r\n")
                words = hit.get("keyword") or []
                word = words[0] if words and isinstance(words[0], str) else ""
                anchor = quote_anchor(text, result, excerpt, hit.get("range"))
                visible_hit = not variants.hidden_range(result, hit.get("range"))
                mark = text.search(word, anchor or "1.0", stopindex="end") if word and visible_hit else ""
                if mark and (anchor or not text.search(word, mark+"+1c", stopindex="end")):
                    text.tag_add("match", mark, mark + f"+{len(word)}c")
                    text.tag_configure("match", underline=True)
                    index = mark
                elif anchor:
                    index = anchor
                else:
                    self.status.set(row["title"] + "　·　当前可读正文中未定位到此处")
            if source_offset is not None:
                from locations import SourceOffsets
                try:
                    anchor = SourceOffsets(result, content).index_at(source_offset)
                except ValueError:
                    anchor = None
                if anchor:
                    index = anchor
                else:
                    self.status.set(row["title"] + "　·　当前正文中未定位到书签")
            text.yview(index)
            self.save_position(changed=cloud["changed"] if cloud else None)
            self.activity.reading(True)
            if turn:
                self.activity.turned(*turn)
            if placeholders:
                def images(found):
                    anchor = text.index("@0,0")
                    for src, label in placeholders:
                        if src in found:
                            try:
                                image = ImageOps.contain(Image.open(io.BytesIO(found[src])),
                                                         (max(100, text.winfo_width()-24), 420*SCALE))
                                illustration = photo(image)
                            except OSError:
                                continue
                            self.photos.append(illustration)
                            label.configure(image=illustration, text="")
                    self.root.update_idletasks()
                    text.yview(anchor)
                    self.progress.settle()
                self.submit(lambda: client.pictures(key, uid, [p[0] for p in placeholders],
                                                    online_only=result.get("onlineOnly", False)),
                            images, lambda _: self.status.set(row["title"] + "　·　插图暂不可用"))
        if loaded is not None:
            render(loaded)
        else:
            self.submit(lambda: client.chapter(key, uid), lambda chapter: render(chapter, online=True), failed)

    def page(self, amount):
        top, bottom = self.text.yview()
        if (amount > 0 and bottom == 1.0) or (amount < 0 and top == 0.0):
            current = next(i for i, row in enumerate(self.rows) if str(row["chapterUid"]) == self.uid)
            neighbor = current + amount
            if 0 <= neighbor < len(self.rows):
                turn = self.activity.elapsed(), int(time.time())
                self.read(self.rows[neighbor], "end" if amount < 0 else "1.0", turn=turn)
            return "break"
        before = self.text.index("@0,0")
        self.progress.turn(amount)
        if self.text.index("@0,0") != before:
            self.activity.turned(self.activity.elapsed(), int(time.time()))
        self.save_position()
        return "break"

    def font_size(self, delta):
        import reader_options
        from reader_fonts import family
        anchor = self.text.index("@0,0")
        self.size = min(30, max(10, self.size + delta))
        self.text.configure(font=(family(self, BODY_FONT), self.size))
        self.update_size_display()
        reader_options.apply(self.text, reader_options.settings(self.store))
        self.root.update_idletasks()
        self.text.yview(anchor)
        self.progress.settle()
        self.store.put("", "size", "", self.size)

    def save_position(self, changed=None):
        if self.text is None or self.uid is None:
            return "1.0"
        index = self.text.index("@0,0")
        book = str(self.book["bookId"])
        saved = self.store.get(self.client.account, "position", book) or {}
        if changed is not None or saved.get("uid") != self.uid or saved.get("index") != index:
            self.store.put(self.client.account, "position", book,
                           {"uid": self.uid, "index": index, "changed": int(time.time()) if changed is None else changed})
        return index

    def close(self):
        if self.saver.closed:
            return
        self.root.after_cancel(self.receive_timer)
        if self.keyboard:
            self.keyboard.close()
        self.activity.close()
        self.saver.close()
        if self.articles and self.articles.visible(".mp.body"):
            self.root.tk.call("mp::rememberArticle")
        self.save_position()
        self.generation += 1
        self.jobs.shutdown(wait=False, cancel_futures=True)
        self.reporting.shutdown(wait=False, cancel_futures=True)
        self.media.shutdown(wait=False, cancel_futures=True)
        self.root.destroy()


def main():
    options = argparse.ArgumentParser()
    base = Path(os.environ.get("LOCALAPPDATA", Path.home()))
    options.add_argument("--data-dir", type=Path, default=base / "Kindle-WeRead" / "independent")
    options.add_argument("--scan-for-stats", action="store_true")
    args = options.parse_args()
    root = tk.Tk()
    app = App(root, Library(args.data_dir), scan_for_stats=args.scan_for_stats)
    if KINDLE:
        import signal
        from legacy_entry import retire_stock_document
        retire_stock_document(Path("/mnt/us/documents"))
        signal.signal(signal.SIGTERM, lambda *_: root.after_idle(app.close))
    try:
        root.mainloop()
    finally:
        if not app.saver.closed:
            app.close()


if __name__ == "__main__":
    if KINDLE:
        import fcntl
        with open("/tmp/weread-pw3-view.lock", "a") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise SystemExit("微信读书已经打开。") from None
            main()
    elif os.name == "nt":
        launcher = Path(__file__).resolve().parents[3] / "outputs" / "Open-Revised.ps1"
        if not launcher.is_file():
            raise SystemExit("请用 Kindle-PW3-Revised.cmd 打开 ARM 预览。")
        import subprocess
        raise SystemExit(subprocess.call(["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass",
                                          "-File", str(launcher)]))
    else:
        main()
