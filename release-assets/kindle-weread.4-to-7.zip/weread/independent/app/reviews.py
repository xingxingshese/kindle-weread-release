"""Signed-in web review operations used by the independent book reader."""
from client import ReaderError, WEB


VISIBILITY = (("isPrivate", "仅自己可见"), ("", "公开"), ("friendship", "好友可见"),
              ("notVisibleToFriends", "不给好友看"))


def visibility(detail):
    return next((key for key, _ in VISIBILITY if key and detail.get(key) in (1, "1", True)), "")


def author_id(detail):
    user = detail.get("author") or {}
    return str(user.get("userVid") or user.get("vid") or detail.get("userVid") or "")


def own_thought(client, book, review_id, detail):
    return (bool(client.account) and author_id(detail) == client.account
            and str(detail.get("bookId")) == str(book) and str(detail.get("type")) == "1"
            and str(detail.get("reviewId") or review_id) == str(review_id))


def check_current(client, book, draft):
    detail = client.review_detail(draft["review"])
    if not own_thought(client, book, draft["review"], detail):
        raise ReaderError("无法确认这是当前账号的想法，请返回详情刷新。")
    if (detail.get("content", ""), visibility(detail)) != (draft["original"], draft["original_scope"]):
        raise ReaderError("这条想法已在其他设备修改。请返回详情核对新内容，草稿已保留。")


def send(client, book, draft):
    content = draft["content"].strip()
    if not content:
        raise ReaderError("请先输入内容。")
    kind = draft["kind"]
    body = {"content": content}
    if kind == "reply":
        body["reviewId"] = draft["review"]
        if draft.get("comment"):
            body["toCommentId"] = draft["comment"]
            if draft.get("recipient"):
                body["toUserVid"] = draft["recipient"]
        response = client.json(WEB + "/web/review/comment", body=body)
        if not response.get("commentId"):
            raise ReaderError("未收到回复编号。")
        return
    scope = draft["scope"]
    if scope not in dict(VISIBILITY):
        raise ReaderError("请选择想法的可见范围。")
    body.update(bookId=book, type=1)
    if kind == "new":
        body.update(chapterUid=draft["uid"], bookVersion=draft["version"],
                    abstract=draft["quote"], range=draft["range"])
        if scope:
            body[scope] = 1
        action = "add"
    elif kind == "edit":
        check_current(client, book, draft)
        body.update(reviewId=draft["review"], fromId=client.account)
        body.update({flag: int(flag == scope) for flag, _ in VISIBILITY if flag})
        action = "edit"
    else:
        raise ValueError("未知的想法操作")
    data = client.json(WEB + "/web/review/" + action, body=body)
    if kind == "edit" and data.get("succ") == 1:
        return
    if not data.get("reviewId") or (kind == "edit" and str(data["reviewId"]) != str(draft["review"])):
        raise ReaderError("未收到想法保存确认。")


def remove(client, book, draft):
    check_current(client, book, draft)
    result = client.json(WEB + "/web/review/delete", body={"reviewId": draft["review"]})
    if result.get("succ") != 1:
        raise ReaderError("未收到删除确认，请刷新我的想法核对。")


def passage_page(client, book, uid, span, offset=0):
    # synckey requests changes since a previous read; pagination uses only maxIdx.
    query = {"range": span, "count": 20, "maxIdx": offset, "synckey": 0}
    data = client.json(WEB + "/web/book/readReviews", read_only=True, body={
        "bookId": book, "chapterUid": int(uid), "reviews": [query]})
    pages = data.get("reviews") or []
    if (str(data.get("bookId", book)) != book or str(data.get("chapterUid", uid)) != str(uid)
            or not isinstance(pages, list) or len(pages) != 1 or not isinstance(pages[0], dict)
            or pages[0].get("range") != span):
        raise ReaderError("未收到所选段落的想法。")
    page, items = pages[0], []
    rows = page.get("pageReviews", [] if page.get("totalCount") == 0 else None)
    if not isinstance(rows, list):
        raise ReaderError("微信读书返回的段落想法格式无法识别。")
    for row in rows:
        if not isinstance(row, dict):
            continue
        wrapper = row.get("review", row)
        if not isinstance(wrapper, dict):
            continue
        detail = wrapper.get("review", wrapper)
        if not isinstance(detail, dict):
            continue
        review_id = row.get("reviewId") or wrapper.get("reviewId") or detail.get("reviewId")
        if not review_id or str(detail.get("chapterUid", uid)) != str(uid) or str(detail.get("bookId", book)) != book:
            continue
        items.append({"id": review_id, "uid": detail.get("chapterUid", uid),
                      "quote": detail.get("abstract", ""), "content": detail.get("content", ""),
                      "author": (detail.get("author") or {}).get("name", ""),
                      "range": detail.get("range") or span})
    following = None
    if page.get("hasMore") in (1, "1", True):
        end = page.get("maxIdx")
        if not isinstance(end, int) or end <= offset:
            raise ReaderError("微信读书未返回下一页的位置。")
        following = end
    return items, following


def like_state(detail):
    value = detail.get("isLike")
    if value not in (0, 1, "0", "1"):
        raise ReaderError("暂时无法核对点赞状态。")
    return bool(int(value))


def set_like(client, review_id, desired):
    if like_state(client.review_detail(review_id)) == desired:
        return desired
    data = client.json(WEB + "/web/review/like", body={"reviewId": review_id, "isUnlike": not desired})
    if data.get("succ") != 1:
        raise ReaderError("未收到点赞状态确认。")
    return desired
