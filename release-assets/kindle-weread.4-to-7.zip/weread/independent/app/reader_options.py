"""Typesetting options for ordinary book chapters."""
import tkinter as tk


LEVELS = (
    ("line", "行距", ("标准", "舒适", "宽松"), 0),
    ("gap", "段间距", ("紧凑", "标准", "宽松"), 1),
    ("margin", "左右边距", ("窄", "中", "宽"), 0),
    ("indent", "正文首行缩进", ("关闭", "开启"), 0),
)


def settings(store):
    saved = store.get("", "book-layout", default={})
    return {key: saved.get(key, initial) if saved.get(key, initial) in range(len(names)) else initial
            for key, _, names, initial in LEVELS}


def apply(text, options):
    font = text.cget("font")
    height = int(text.tk.call("font", "metrics", font, "-linespace"))
    em = int(text.tk.call("font", "measure", font, "汉"))
    gap = options["gap"]
    text.configure(padx=(5, em, 2*em)[options["margin"]],
                   spacing1=(0, 4, max(6, height//3))[gap],
                   spacing2=(0, max(2, height//6), max(4, height//3))[options["line"]],
                   spacing3=(2, 6, max(9, height//2))[gap])
    text.tag_configure("book-paragraph", lmargin1=2*em if options["indent"] else 0)
    # Retain logical blank lines used by saved positions and highlight ranges.
    # Paragraph separation on screen is already provided by spacing1/spacing3.
    text.tag_configure("paragraph-separator", elide=True)
    text.tag_configure("authored-blank-line", spacing1=0, spacing3=0)


def insert_paragraphs(text, content, *, plain_text=False):
    lines = content.splitlines(keepends=True)
    if lines and not lines[-1].endswith("\n"):
        lines[-1] += "\n"
        trailing = 1
    else:
        trailing = 2
    for line in lines:
        # Preserve indentation supplied by the book, and keep source indices
        # stable for search, selections, cloud positions, and illustrations.
        if not line.strip():
            tags = ("authored-blank-line",) if plain_text else ("paragraph-separator",)
        else:
            tags = ("book-paragraph",) if not line[0].isspace() else ()
        text.insert("end", line, tags)
    text.insert("end", "\n" * trailing, ("paragraph-separator",))


def edit(app, row):
    from app import BODY_FONT
    from reader_fonts import choose, display_family
    index = app.save_position()
    loaded = app.loaded
    options = settings(app.store)
    app.clear()
    def back():
        app.read(row, index, loaded)
    from pw3_page import Page
    page=Page(app)
    page.title("排版设置")
    panel=tk.Frame(page.frame,bd=1,relief="solid",bg="white")
    page.put(panel,48,250,976,360)
    tk.Label(panel,text="排版预览",fg="#555555",bg="white",font=page.font(26)).place(relx=.028,rely=.07)
    preview=tk.Text(panel,wrap="char",bd=0,highlightthickness=0,bg="white")
    preview.place(relx=.028,rely=.26,relwidth=.944,relheight=.70)
    from app import blocks
    sample=next((b[1] for b in blocks(loaded) if b[0]=="paragraphs" and b[1].strip()),"") if loaded else ""
    insert_paragraphs(preview,sample[:500] or "清早的渡口还没有船。\n石阶一层一层落到水里。")
    preview.configure(state="disabled")
    choice=tk.StringVar(value=app.store.get("","book-font",default=""))
    page.button("正文用字",lambda:choose(app,choice,BODY_FONT),48,630,440,92,36,anchor="w")
    font_button=page.button("",lambda:choose(app,choice,BODY_FONT),508,630,516,92,28,anchor="e")
    buttons={}
    def refresh(*_):
        family=display_family(app,choice.get(),BODY_FONT)
        font_button.configure(text=("霞鹜文楷" if family=="LXGW WenKai" else family)+"　›")
        preview.configure(font=(family,app.size))
        apply(preview,options)
        for (key,i),btn in buttons.items():
            active=options[key]==i
            btn.configure(bg="#222222" if active else "white",fg="white" if active else "#222222")
    for n,(key,label,choices,_) in enumerate(LEVELS):
        y=752+137*n
        page.label(label.replace("正文首行","首行"),48,y,330,88)
        width=624/len(choices)
        for i,title in enumerate(choices):
            def pick(k=key,v=i):
                options[k]=v
                refresh()
            buttons[key,i]=page.button(title,pick,396+i*width,y,width-14,88,outline=True)
    def save():
        app.store.put("","book-layout","",dict(options))
        app.store.put("","book-font","",choice.get())
        back()
    page.footer([("‹ 返回",back),("应用",save)])
    choice.trace_add("write",refresh)
    refresh()
