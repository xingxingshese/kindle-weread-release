"""Map Tk paragraph and image positions to WeRead UTF-16 chapter source ranges."""
import html
import re
from array import array
from bisect import bisect_left, bisect_right

from resources.mp import Article

IMAGE = "\ufffc"


class SourceOffsets:
    def __init__(self, result, blocks):
        self.source = result["content"]
        self.variants = result.get("_variants")
        self.prefs = result.get("_variant_prefs", {})
        self._surrogate_tails = None
        self.display = "".join(block[1] + "\n\n" if block[0] == "paragraphs" else IMAGE + "\n"
                               for block in blocks)
        self.lines = [0, *(m.end() for m in re.finditer("\n", self.display))]
        self.display_chars = array("I", (i for i, ch in enumerate(self.display) if not ch.isspace()))
        self.starts, self.ends = array("I"), array("I")

        def record(value, start, end):
            if value.isspace():
                return
            n = len(self.starts)
            if n >= len(self.display_chars) or self.display[self.display_chars[n]] != value:
                raise ValueError("无法把当前段落准确定位到原文。")
            self.starts.append(start)
            self.ends.append(end)

        if result["format"] == "text":
            for i, char in enumerate(self.source):
                record(char, i, i + 1)
        else:
            visible = result.get("display_source", self.source)
            body = re.search(r"<body\b[^>]*>(.*?)</body\s*>", visible, re.I | re.S)
            inner, start = (body[1], body.start(1)) if body else (visible, 0)
            prefix = '<section id="js_content">'
            wrapped = prefix + inner + "</section>"
            positions = [0, *(m.end() for m in re.finditer("\n", wrapped))]

            class Parser(Article):
                def position(self):
                    line, col = self.getpos()
                    return positions[line - 1] + col - len(prefix) + start

                def active(self):
                    return self.stack and not any(t in ("script", "style", "template") for t in self.stack)

                def handle_starttag(self, tag, attrs):
                    super().handle_starttag(tag, attrs)
                    if tag == "img" and self.stack:
                        i = self.position()
                        record(IMAGE, i, i + len(self.get_starttag_text()))
                    self.parts.clear()

                def handle_data(self, data):
                    if self.active():
                        i = self.position()
                        for offset, char in enumerate(data):
                            record(char, i + offset, i + offset + 1)

                def handle_entityref(self, name):
                    if self.active():
                        i = self.position()
                        ref = "&" + name
                        if original.startswith(ref + ";", i):
                            ref += ";"
                        for char in html.unescape(ref):
                            record(char, i, i + len(ref))

                def handle_charref(self, name):
                    self.handle_entityref("#" + name)

            original = self.source
            parser = Parser()
            parser.convert_charrefs = False
            parser.feed(wrapped)
            parser.close()
        if len(self.starts) != len(self.display_chars):
            raise ValueError("当前章节的显示内容与原文不一致。")

    def display_offset(self, index):
        line, column = (int(i) for i in index.split("."))
        if line > len(self.lines):
            return len(self.display)
        start = self.lines[line - 1]
        end = self.lines[line] if line < len(self.lines) else len(self.display)
        line_bytes = self.display[start:end].encode("utf-16-le")
        return start + len(line_bytes[:2*column].decode("utf-16-le", errors="ignore"))

    def selection(self, begin, end):
        a = bisect_left(self.display_chars, self.display_offset(begin))
        b = bisect_left(self.display_chars, self.display_offset(end))
        if a >= b:
            raise ValueError("请选中一段正文。")
        quote = self.display[self.display_chars[a]:self.display_chars[b-1]+1].replace(IMAGE, "")
        if not quote.strip():
            raise ValueError("请选中一段正文。")
        low = len(self.source[:self.starts[a]].encode("utf-16-le")) // 2
        high = low + len(self.source[self.starts[a]:self.ends[b-1]].encode("utf-16-le")) // 2
        return f"{low}-{high}", quote

    def bookmark(self, index):
        if not self.starts:
            raise ValueError("本章没有可定位的内容。")
        a = min(bisect_left(self.display_chars, self.display_offset(index)), len(self.starts) - 1)
        start = self.display_chars[a]
        return (str(len(self.source[:self.starts[a]].encode("utf-16-le")) // 2),
                self.display[start:start+60].replace(IMAGE, "").strip())

    def index_at(self, offset):
        raw = self.source.encode("utf-16-le")
        if not self.starts or not 0 <= offset*2 < len(raw):
            return None
        if self.variants:
            offset = self.variants.anchor(offset, self.prefs)
        pos = len(raw[:offset*2].decode("utf-16-le", errors="ignore"))
        n = bisect_right(self.ends, pos)
        if n >= len(self.display_chars):
            return None
        return self._index_of(self.display_chars[n])

    def _index_of(self, value):
        line = bisect_right(self.lines, value)
        column = len(self.display[self.lines[line-1]:value].encode("utf-16-le")) // 2
        return f"{line}.{column}"

    def range_indices(self, low, high):
        # API ranges count UTF-16 units in the source, including HTML tags.
        if self._surrogate_tails is None:
            self._surrogate_tails = []
            for i, char in enumerate(self.source):
                if ord(char) > 0xffff:
                    self._surrogate_tails.append(i + len(self._surrogate_tails) + 1)
        tails = self._surrogate_tails
        if not 0 <= low < high <= len(self.source) + len(tails):
            return None
        left = low - bisect_left(tails, low)
        right = high - bisect_left(tails, high)
        first = bisect_right(self.ends, left)
        last = bisect_left(self.starts, right) - 1
        if first > last:
            return None
        return self._index_of(self.display_chars[first]), self._index_of(self.display_chars[last] + 1)
