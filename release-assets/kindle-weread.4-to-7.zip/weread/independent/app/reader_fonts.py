"""Book fonts provided by the device, the reader's user, and the original catalog."""
from dataclasses import dataclass
import hashlib
import os
from pathlib import Path
import tempfile
import threading
import tkinter as tk
from urllib.request import urlopen
from zipfile import ZipFile

from PIL import ImageFont


@dataclass(frozen=True)
class Source:
    label: str
    filename: str
    url: str
    digest: str = ""
    license_url: str = ""
    license_digest: str = ""


RAW = "https://raw.githubusercontent.com/"
WENKAI = RAW + "lxgw/LxgwWenKai/061398910b550e1c68a302b4641aaf0e20bbf3ae/"
SANS = RAW + "adobe-fonts/source-han-sans/a4f7cf94edfb9d7ffbdfc4841de276358bd7e0f2/"
SERIF = RAW + "adobe-fonts/source-han-serif/7889f11bf31170b5d092a083b357c8c8130f89e0/"
SOURCES = [
    Source("霞鹜文楷", "LXGWWenKai-Regular.ttf", WENKAI + "fonts/TTF/LXGWWenKai-Regular.ttf",
           "39ad71264b588165b469e35e6afb162a378dacd1f95348160240ba9038ac3009", WENKAI + "OFL.txt",
           "1a25e35da1031c6c3436fde545bb9cb5aca954e9873afe510c834b8b79bd21a0"),
    Source("思源黑体", "SourceHanSansSC-Regular.otf", SANS + "OTF/SimplifiedChinese/SourceHanSansSC-Regular.otf",
           "f1d8611151880c6c336aabeac4640ef434fa13cbfbf1ffe82d0a71b2a5637256", SANS + "LICENSE.txt",
           "fcac737e761ec63dbfbdce11030a1780161920d80315edba9c8beff1c2bac5a2"),
    Source("思源宋体", "SourceHanSerifSC-Regular.otf", SERIF + "OTF/SimplifiedChinese/SourceHanSerifSC-Regular.otf",
           "78aa7a328fd974df2d688c8a9fd74a33d8334dfa84ab24d9d11efb2ffc464117", SERIF + "LICENSE.txt",
           "9ff5bb567e1b92c801fc1069e5fbf992ff8efccacb9db94e5959a5b3ba9bb903"),
]
CDN = "https://cdn.weread.qq.com/app/assets/app_fonts_new/"
for label, stem in (
        ("寒蝉活宋体", "ChillHuoSong_F_Regular"), ("寒蝉正楷体", "ChillKai"), ("汇文正楷", "HuiwenZhengkai-Regular"),
        ("京华老宋体", "KingHwa_OldSong"), ("仓耳华新", "TsangerHuaXinTi"), ("仓耳兰楷", "TsangerLanKai-Regular"),
        ("仓耳玉楷", "TsangerYuKai-Regular"), ("仓耳状元楷", "TsangerZhuangYuanKai"), ("AI 楷", "aik"),
        ("仓耳今楷04", "cejk"), ("仓耳今楷05", "TsangerJinKai03-W05"), ("仓耳玄三05", "cexs"),
        ("仓耳玄三04", "TsangerXuanSan01JF-W04"), ("仓耳云黑04", "ceyh"), ("仓耳云黑05", "TsangerYunHei-W05"),
        ("仓耳明楷04", "TsangerMingKai-W04"), ("仓耳明楷05", "TsangerMingKai-W05"), ("方正兰亭黑", "fzlth"),
        ("方正兰亭圆", "fzlty"), ("方正欧蝶正楷", "fzodzk"), ("方正宋三", "fzss"), ("方正盛世楷书", "fzssks"),
        ("方正悠宋", "fzys"), ("方正聚珍新仿", "fzjzxf"), ("汉仪空山楷", "hyksk")):
    suffix = ".otf" if stem == "ChillHuoSong_F_Regular" else ".ttf"
    SOURCES.append(Source(label, stem + suffix, CDN + stem + ".zip"))


class Cancelled(Exception):
    pass


def download(source, folder, cancel, progress):
    """Install a complete font directory. Never replace a user's existing files."""
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / Path(source.filename).stem
    if target.exists():
        raise ValueError("同名字体目录已存在。可返回本机字体查看。")
    def transfer(stream, dest, length, digest="", report=True):
        limit = 80 * 1024 * 1024
        if length > limit:
            raise ValueError("字体文件超出大小限制。")
        total = 0
        check = hashlib.sha256() if digest else None
        with dest.open("wb") as out:
            while not cancel.is_set():
                chunk = stream.read(128*1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > limit:
                    raise ValueError("字体文件超出大小限制。")
                out.write(chunk)
                if check:
                    check.update(chunk)
                if report:
                    progress(total, length)
        if cancel.is_set():
            raise Cancelled()
        if (length and length != total) or not total or (check and check.hexdigest() != digest):
            raise ValueError("字体文件校验失败。")
    def fetch(url, dest, digest="", report=True):
        with urlopen(url, timeout=12) as response:
            transfer(response, dest, int(response.headers.get("Content-Length") or 0), digest, report)
    with tempfile.TemporaryDirectory(dir=folder, prefix=".font-") as temporary:
        stage = Path(temporary)
        complete = stage / "complete"
        complete.mkdir()
        font = complete / source.filename
        if source.url.endswith(".zip"):
            archive = stage / "download.zip"
            fetch(source.url, archive)
            with ZipFile(archive) as z:
                entry = z.getinfo(source.filename)
                with z.open(entry) as stream:
                    transfer(stream, font, entry.file_size, report=False)
        else:
            fetch(source.url, font, source.digest)
            fetch(source.license_url, complete / "LICENSE.txt", source.license_digest, False)
        family = ImageFont.truetype(str(font), 16).getname()[0]
        if cancel.is_set():
            raise Cancelled()
        complete.rename(target)
        return family


def installed(app, refresh=False):
    cached = getattr(app, "_book_font_names", None)
    if cached is not None and not refresh:
        return cached
    if os.name == "nt":
        import ctypes
        registered = getattr(app, "_private_book_fonts", set())
        app._private_book_fonts = registered
        folder = app.store.path.parent / "fonts"
        for path in folder.rglob("*") if folder.is_dir() else ():
            if (path in registered or any(p.startswith(".") for p in path.relative_to(folder).parts)
                    or path.suffix.lower() not in (".ttf", ".otf", ".ttc") or not path.is_file()):
                continue
            if ctypes.windll.gdi32.AddFontResourceExW(str(path), 0x10, None):
                registered.add(path)
    families = app.root.tk.splitlist(app.root.tk.call("font", "families"))
    app._book_font_names = sorted(set(f for f in families if f and not f.startswith("@")), key=str.casefold)
    return app._book_font_names


def _selected_family(app, name, fallback):
    if not name:
        return fallback
    families = installed(app)
    if name in families:
        return name
    # Tk enumerates some Windows fonts under localized names. Saved choices
    # may use their English names after a move between Windows installations.
    aliases = {"microsoft yahei": "微软雅黑", "simsun": "宋体", "simhei": "黑体",
               "fangsong": "仿宋", "kaiti": "楷体"} if os.name == "nt" else {}
    canonical = aliases.get(name.casefold(), name.casefold())
    return next((f for f in families if aliases.get(f.casefold(), f.casefold()) == canonical), fallback)


def family(app, fallback):
    return _selected_family(app, app.store.get("", "book-font", default=""), fallback)


def display_family(app, name, fallback):
    requested = _selected_family(app, name, fallback)
    return str(app.root.tk.call("font", "actual", (requested, app.size), "-family", "--", "汉"))


def choose(app, selection, fallback):
    """Overlay the current page with the 正文用字/可下载字体 chooser (design 17/17a)."""
    from pw3_page import Page, INK, SECONDARY
    from app import blocks
    page = Page(app)
    status = tk.StringVar()
    state = {"cancel": None, "timer": None, "names": [], "choice": selection.get(),
             "source_index": 0, "source_ready": False}
    loaded = app.loaded
    first_paragraph = (next((b[1] for b in blocks(loaded) if b[0] == "paragraphs" and b[1].strip()), "")
                        if loaded else "")
    sample_text = " ".join(first_paragraph.split())[:80] or "山光悦鸟性，潭影空人心。清早的渡口还没有船。"

    def wipe():
        for child in page.frame.winfo_children():
            child.destroy()

    def scrollable(x, y, w, h):
        region = tk.Frame(page.frame, bg="white")
        page.put(region, x, y, w, h)
        canvas = tk.Canvas(region, bg="white", bd=0, highlightthickness=0)
        bar = tk.Scrollbar(region, command=canvas.yview)
        canvas.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        rows = tk.Frame(canvas, bg="white")
        window = canvas.create_window((0, 0), window=rows, anchor="nw")
        rows.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(window, width=e.width))
        def wheel(event):
            canvas.yview_scroll(int(-event.delta / 40), "units")
        def bind_wheel(widget):
            widget.bind("<MouseWheel>", wheel)
            for child in widget.winfo_children():
                bind_wheel(child)
        canvas.bind("<MouseWheel>", wheel)
        rows.bind_wheel = bind_wheel
        return rows

    def chrome(title, active):
        page.title(title)
        for i, (name, action) in enumerate((("本机字体", show_local), ("可下载字体", show_sources))):
            if name == active:
                page.label(name, i * 536, 256, 536, 90, 32, True, "center")
                page.line(i * 536 + 234, 344, 68, INK, 4)
            else:
                page.button(name, action, i * 536, 256, 536, 90, 32)
        page.line(0, 346, 1072)
        page.label("", 48, 362, 976, 46, 26, color=SECONDARY).configure(textvariable=status)

    def show_local(refresh=False):
        wipe()
        chrome("正文用字", "本机字体")
        page.button("刷新本机字体", lambda: show_local(True), 580, 118, 444, 88, 28, anchor="e")
        state["names"] = [""] + sorted(installed(app, refresh), key=lambda x: (x.isascii(), x.casefold()))
        choice = state["choice"]
        current = _selected_family(app, choice, "") if choice else ""
        status.set("原字体不可用，正文使用默认字体。" if choice and not current else "")
        rows = scrollable(48, 420, 976, 480)
        def pick(name):
            state["choice"] = name
            show_local()
        for name in state["names"]:
            label_text = "应用默认字体" if name == "" else name
            selected = name == current
            row = tk.Frame(rows, bg="white")
            row.pack(fill="x")
            top = tk.Frame(row, bg="white")
            top.pack(fill="x", pady=(16, 0))
            tk.Label(top, text=label_text, font=page.font(32), bg="white", fg=INK,
                     anchor="w").pack(side="left", fill="x", expand=True)
            if selected:
                tk.Label(top, text="已选", font=page.font(26), bg="white", fg=SECONDARY,
                         anchor="e").pack(side="right")
                actual = app.root.tk.call("font", "actual", (name or fallback, app.size), "-family", "--", "汉")
                tk.Label(row, text="中文显示为" + str(actual), font=page.font(24), bg="white",
                         fg=SECONDARY, anchor="w").pack(fill="x", pady=(2, 12))
            else:
                tk.Frame(row, bg="white", height=12).pack()
            tk.Frame(row, bg="#dddddd", height=2).pack(fill="x")
            for widget in (row, top, *top.winfo_children()):
                widget.bind("<ButtonRelease-1>", lambda _e, n=name: pick(n))
            rows.bind_wheel(row)
        page.label("字形预览", 48, 936, 400, 56, 32, True)
        preview = tk.Label(page.frame, text=sample_text, font=(_selected_family(app, choice, fallback), app.size),
                            bg="white", fg=INK, anchor="nw", justify="left")
        preview.configure(wraplength=round(976 * page.factor))
        page.put(preview, 48, 1006, 976, 190)
        def use():
            selection.set(state["choice"])
            page.frame.destroy()
        page.footer([("‹ 返回", page.frame.destroy), ("选用", use)])

    def show_sources():
        wipe()
        chrome("可下载字体", "可下载字体")
        if not state["source_ready"]:
            state["source_index"] = next((i for i, s in enumerate(SOURCES) if s.label == state["choice"]), 0)
            state["source_ready"] = True
        status.set("也可用 USB 将自己的字体放入 fonts 文件夹。" if app.kindle else "也可在 Windows 中安装自己的字体。")
        rows = scrollable(48, 420, 976, 640)
        def choose_source(i):
            state["source_index"] = i
            show_sources()
        for i, source in enumerate(SOURCES):
            already = source.label == state["choice"]
            row = tk.Frame(rows, bg="white")
            row.pack(fill="x")
            tk.Label(row, text=source.label, font=page.font(32), bg="white", fg=INK,
                     anchor="w").pack(side="left", fill="x", expand=True, padx=(8, 0), pady=16)
            if already:
                tk.Label(row, text="已选", font=page.font(26), bg="white", fg=SECONDARY,
                         anchor="e").pack(side="right", padx=(0, 8))
            tk.Frame(rows, bg="#dddddd", height=2).pack(fill="x")
            for widget in (row, *row.winfo_children()):
                widget.bind("<ButtonRelease-1>", lambda _e, n=i: choose_source(n))
            rows.bind_wheel(row)
        action = page.button("下载所选字体", lambda: None, 48, 1120, 976, 96, 32, primary=True)
        page.footer([("‹ 返回", page.frame.destroy)])
        def start():
            if state["cancel"] is not None or not (0 <= state["source_index"] < len(SOURCES)):
                return
            source = SOURCES[state["source_index"]]
            previous = set(state["names"])
            token = state["cancel"] = threading.Event()
            progress = [0, 0]
            def update(done, total):
                progress[:] = [done, total]
            def tick():
                if state["cancel"] is not token:
                    state["timer"] = None
                    return
                done, total = progress
                status.set(f"下载 {source.label}　{100*done//total}%" if total else "正在下载 " + source.label)
                state["timer"] = page.frame.after(250, tick)
            def stop():
                token.set()
                action.configure(text="正在取消", state="disabled")
            action.configure(text="取消下载", command=stop)
            def finish():
                state["cancel"] = None
                return page.frame.winfo_exists()
            def done(downloaded):
                if finish():
                    refreshed = installed(app, True)
                    added = set(refreshed) - previous
                    matched = downloaded if downloaded in refreshed else None
                    if not matched and len(added) == 1:
                        matched = added.pop()
                    if matched:
                        state["choice"] = matched
                    state["source_ready"] = False
                    show_local(True)
                    if not matched:
                        status.set("字体已下载。如列表尚未显示，请重新打开应用。")
            def failed(error):
                if finish():
                    status.set("已取消下载" if isinstance(error, Cancelled) else f"字体下载失败：{error}")
                    show_sources()
            tick()
            app.submit(lambda: download(source, app.store.path.parent / "fonts", token, update), done, failed, media=True)
        action.configure(command=start)

    def leaving(event):
        if event.widget is page.frame:
            if state["cancel"] is not None:
                state["cancel"].set()
            if state["timer"] is not None:
                page.frame.after_cancel(state["timer"])
    page.frame.bind("<Destroy>", leaving)
    show_local()
