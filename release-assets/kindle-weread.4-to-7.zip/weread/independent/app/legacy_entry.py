"""Retire the stock 0.3.9 document once the independent document is installed."""
import hashlib


def retire_stock_document(documents):
    replacement = documents / "微信读书 PW3 增强版.sh"
    stock = "微信读书.sh"
    # The original ZIP contains UTF-8 names without the ZIP UTF-8 flag.
    names = (stock, stock.encode("utf-8").decode("cp437"))
    try:
        launcher = documents.parent / "weread/start.sh"
        if not launcher.is_file() or b'exec sh /mnt/us/weread/independent/run.sh "$@"' not in launcher.read_bytes().splitlines():
            return
        if b"exec sh /mnt/us/weread/independent/run.sh" not in replacement.read_bytes().splitlines():
            return
        for name in names:
            entry = documents / name
            if entry.is_symlink() or not entry.is_file() or entry.stat().st_size > 256:
                continue
            script = entry.read_bytes().replace(b"\r\n", b"\n")
            if hashlib.sha256(script).hexdigest() == "9d7da9495e981d3b82cc5fcef3c230f2f5629466314b21e7cc6672e4cc70d99d":
                entry.unlink()
    except OSError as error:
        print("无法整理原版文档入口：", error, flush=True)
