"""Choose between text variants present in a chapter supplied by WeRead."""
from dataclasses import dataclass
from html.parser import HTMLParser
import re
import tkinter as tk

from locations import SourceOffsets


KINDS = {"wr-traditional": "traditional", "wr-simplified": "simplified", "wr-translation": "translation"}
SCRIPTS = {"traditional", "simplified"}
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}


@dataclass
class Element:
    tag: str
    start: int
    kind: str
    end: int = 0
    counterpart: int = -1


class ChapterVariants(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=False)
        self.source = source
        self.lines = [0, *(m.end() for m in re.finditer("\n", source))]
        self.stack = []
        self.last = {}
        self.items = []
        self.feed(source)
        self.close()
        scripts = [n for n in self.items if n.kind in SCRIPTS]
        translations = [n for n in self.items if n.kind == "translation"]
        self.scripts = bool(scripts) and all(n.counterpart >= 0 for n in scripts)
        self.bilingual = bool(translations) and all(n.counterpart >= 0 for n in translations)
        self.first_script = scripts[0].kind if self.scripts else None

    def position(self):
        line, column = self.getpos()
        return self.lines[line-1] + column

    def handle_starttag(self, tag, attrs):
        if tag in VOID:
            return
        classes = (dict(attrs).get("class") or "").split()
        kind = next((KINDS[c] for c in classes if c in KINDS), "")
        self.stack.append(Element(tag, self.position(), kind))

    def handle_startendtag(self, tag, attrs):
        pass

    def handle_endtag(self, tag):
        if not self.stack or self.stack[-1].tag != tag:
            return
        row = self.stack.pop()
        row.end = self.source.index(">", self.position()) + 1
        parent = self.stack[-1].start if self.stack else -1
        prev = self.last.get(parent)
        if prev and prev.tag == tag and not self.source[prev.end:row.start].strip():
            if {prev.kind, row.kind} == SCRIPTS and prev.counterpart < 0:
                row.counterpart, prev.counterpart = prev.start, row.start
            elif not prev.kind and row.kind == "translation":
                row.counterpart = prev.start
        self.last[parent] = row
        self.last.pop(row.start, None)
        if row.kind:
            self.items.append(row)

    def hidden(self, prefs):
        script = prefs.get("script")
        if script not in SCRIPTS:
            script = self.first_script
        return [row for row in self.items
                if (self.bilingual and row.kind == "translation" and not prefs.get("translation"))
                or (self.scripts and row.kind in SCRIPTS and row.kind != script)]

    def visible_source(self, prefs):
        parts, pos = [], 0
        for node in sorted(self.hidden(prefs), key=lambda n: n.start):
            if node.start < pos:
                continue
            parts.append(self.source[pos:node.start])
            # Comments disappear from the renderer while retaining the original line,
            # code point and UTF-16 offsets, including any supplementary characters.
            body = self.source[node.start+4:node.end-3]
            parts.extend(("<!--", re.sub(r"[^\n\r\U00010000-\U0010ffff]", " ", body), "-->"))
            pos = node.end
        return "".join(parts) + self.source[pos:]

    def anchor(self, offset, prefs):
        encoded = self.source.encode("utf-16-le")
        index = len(encoded[:offset*2].decode("utf-16-le", errors="ignore"))
        for row in self.hidden(prefs):
            if row.start <= index < row.end:
                # Prefer the paired paragraph start to the next visible paragraph.
                return len(self.source[:row.counterpart].encode("utf-16-le"))//2
        return offset


def prepared(result, prefs):
    if result.get("format") != "html" or not any(k in result["content"] for k in KINDS):
        return result
    variants = result.get("_variants") or ChapterVariants(result["content"])
    return dict(result, _variants=variants, _variant_prefs=prefs, display_source=variants.visible_source(prefs))


def for_reader(app, result):
    if result.get("format") != "html" or not any(k in result["content"] for k in KINDS):
        return result
    prefs = app.store.get(app.client.account, "reader-variants", str(app.book["bookId"]), {})
    return prepared(result, prefs)


def hidden_range(result, span):
    """Whether a known source range includes content hidden in the current view."""
    visible = result.get("display_source")
    match = re.fullmatch(r"([0-9]+)-([0-9]+)", str(span)) if visible and span else None
    if not match:
        return False
    start, end = (int(value)*2 for value in match.groups())
    return visible.encode("utf-16-le")[start:end] != result["content"].encode("utf-16-le")[start:end]


def show(app, row):
    """Design 18: 译文显示 and 简繁正文 as paired filled/outline choices."""
    from app import blocks
    from pw3_page import Page, SECONDARY
    loaded, original_blocks, index = app.loaded, app.reading_blocks, app.save_position()
    book = str(app.book["bookId"])
    account = app.client.account
    prefs = app.store.get(account, "reader-variants", book, {})
    variants = loaded.get("_variants")
    def back():
        app.read(row, index, loaded)
    app.clear()
    page = Page(app)
    page.title("正文版本")
    app.status = tk.StringVar()
    page.label("", 48, 1256, 976, 70, 26, color=SECONDARY).configure(textvariable=app.status)
    page.footer([("‹ 返回", back)])
    def note(text, y):
        label = page.label(text, 48, y, 976, 90, 28, color=SECONDARY)
        label.configure(wraplength=round(960*page.factor), justify="left", anchor="nw")
    def change(key, value):
        selected = dict(prefs, **{key: value})
        try:
            offset, _ = SourceOffsets(loaded, original_blocks).bookmark(index)
            offset = variants.anchor(int(offset), selected)
            target = prepared(loaded, selected)
            new_index = SourceOffsets(target, blocks(target)).index_at(offset)
            if not new_index:
                raise ValueError
        except ValueError:
            app.status.set("当前段落无法对应到所选版本，请回到正文换一段后重试。")
            return
        app.store.put(account, "reader-variants", book, selected)
        app.read(row, new_index, target)
    def choice(name, key, value, selected, x, y):
        primary = value == selected
        page.button(name, lambda: change(key, value), x, y, 472, 96, 32,
                    outline=not primary, primary=primary)
    page.label("译文显示", 48, 300, 976, 60, 36, True)
    if variants and variants.bilingual:
        selected = bool(prefs.get("translation"))
        choice("只看原文", "translation", False, selected, 48, 370)
        choice("原文与译文", "translation", True, selected, 552, 370)
    elif row.get("hasTranslated"):
        note("目录标记本章已有译文。当前可读正文中没有可逐段对应的译文，可在官方微信读书中查看。", 370)
    elif row.get("hasTranslated") is False:
        note("官方目录显示本章尚无译文。", 370)
    else:
        note("当前可读正文未提供可逐段对应的译文。", 370)
    page.label("简繁正文", 48, 620, 976, 60, 36, True)
    if variants and variants.scripts:
        selected = prefs.get("script") or variants.first_script
        choice("简体", "script", "simplified", selected, 48, 690)
        choice("繁体", "script", "traditional", selected, 552, 690)
    else:
        note("当前可读正文未提供可切换的简繁对照。", 690)
