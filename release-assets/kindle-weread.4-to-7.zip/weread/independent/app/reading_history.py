"""Browse account-scoped intervals already recorded on this device."""
from dataclasses import dataclass
from datetime import datetime
import json
import time
import tkinter as tk


LABELS = {"pending": "未上报", "unconfirmed": "结果待核对", "confirmed": "已确认上报", "matched": "已核对"}


@dataclass
class Interval:
    rowid: int
    id: str
    ended: int
    seconds: int
    status: str
    detail: dict


def intervals(store, account, status="", before=None, event=None, limit=20):
    sql = "select rowid,id,ended,seconds,status,detail from reading_events where account=?"
    params = [account]
    if status:
        sql += " and status=?"
        params.append(status)
    if before:
        sql += " and (ended,rowid)<(?,?)"
        params.extend(before)
    if event:
        sql += " and id=?"
        params.append(event)
    with store.connect() as db:
        rows = db.execute(sql+" order by ended desc,rowid desc limit ?", [*params, limit+1]).fetchall()
    return [Interval(*r[:-1], json.loads(r[-1])) for r in rows[:limit]], len(rows)>limit


def checkable(detail):
    return ("review" not in detail and type(detail.get("priorSeconds")) is int
            and all(k in detail for k in ("book", "uid", "summary", "offset", "submitted")))


def known_reports(client, book=None):
    return [record for record in client.store.unconfirmed_reports(client.account)
            if checkable(record[1]) and (book is None or record[1]["book"] == book)]


def available_action(record, now):
    if record.status == "unconfirmed" and checkable(record.detail):
        return "check"
    if (record.status == "pending" and 0 <= now-record.ended < 120
            and ("offset" in record.detail or "review" in record.detail)):
        return "retry"
    return None


def explanation(record, now):
    if record.status == "pending":
        if not ("offset" in record.detail or "review" in record.detail):
            return "本段已计入本机时长，缺少可上报的原文位置。"
        if available_action(record, now) == "retry":
            return "联网后会自动重试，也可以点下方按钮立即重试。"
        return "已超过本应用两分钟的在线重试时间。原阅读时间和时长已保存在本机，当前网页接口不支持按原日期补报。"
    if record.status == "unconfirmed":
        if checkable(record.detail):
            return "已尝试发送。可读取这本书的云端时长及位置，核对本次记录。"
        return "已尝试发送，服务端结果未知。当前没有可唯一核对的云端记录，本机保留这段时长。"
    if record.status == "matched":
        return "云端记录的时长增量、设备、章节及位置与本段相符。"
    if record.status == "confirmed":
        return "微信读书已确认收到这段阅读时长。"
    return ""


class ReadingHistory:
    def __init__(self, app):
        self.app, self.client = app, app.client
        self.account = self.client.account
        self.status = ""
        self.pages = [None]
        self.selected = ""
        self.books = {str(b["bookId"]): b.get("title") for b in app.books if b.get("bookId")}
        self.show()

    def book_name(self, record):
        book = str(record.detail.get("book") or "")
        prefix = "公众号 " if "review" in record.detail else "图书 "
        return record.detail.get("bookTitle") or self.books.get(book) or (prefix + book if book else "未记录书名")

    def show(self):
        from activity import local_duration
        from pw3_page import Page
        app = self.app
        app.clear()
        page = Page(app)
        page.title("本机阅读记录")
        def choose(value):
            self.status, self.pages, self.selected = value, [None], ""
            self.show()
        options = (("", "全部"), ("pending", "未上报"), ("unconfirmed", "待核对"))
        page.tabs(options, self.status, choose, 254)
        rows, more = intervals(app.store, self.account, self.status, self.pages[-1], limit=5)
        app.status = tk.StringVar()
        page.label("", 48, 372, 976, 56, 26, color="#555555").configure(textvariable=app.status)
        app.status.set("" if rows else "暂无此类记录")
        def open_record(record):
            self.selected = record.id
            self.detail()
        for i, record in enumerate(rows):
            y = 397 + i*162
            clock = datetime.fromtimestamp(record.ended).strftime("%m-%d %H:%M")
            action = lambda r=record: open_record(r)
            heading = page.button(self.book_name(record), action, 48, y, 976, 92, 36, anchor="w")
            if record.id == self.selected:
                heading.configure(font=page.font(36, True))
                page.frame.after_idle(heading.focus_set)
            page.button(clock + "　·　" + local_duration(record.seconds), action,
                        48, y+92, 640, 55, 26, anchor="w")
            page.button(LABELS.get(record.status, record.status) + "　›", action,
                        700, y+92, 324, 55, 28, anchor="e")
            page.line(48, y+152, 976, "#cccccc")
        def turn(step):
            if step > 0:
                last = rows[-1]
                self.pages.append((last.ended, last.rowid))
            else:
                self.pages.pop()
            self.selected = ""
            self.show()
        nav = page.footer([("‹ 返回", app.activity.show), ("上一页", lambda: turn(-1)), ("下一页", lambda: turn(1))])
        nav["上一页"].configure(state="normal" if len(self.pages) > 1 else "disabled")
        nav["下一页"].configure(state="normal" if more else "disabled")

    def detail(self, message=""):
        from activity import local_duration
        from pw3_page import Page
        app = self.app
        rows, _ = intervals(app.store, self.account, event=self.selected, limit=1)
        if not rows:
            self.show()
            return
        r = rows[0]
        app.clear()
        page = Page(app)
        page.title("阅读记录详情")
        page.footer([("‹ 返回", self.show)])
        now = int(time.time())
        data = r.detail
        name = data.get("chapterTitle")
        if not name and "uid" in data and data.get("book"):
            catalog = app.store.get(self.account, "catalog", str(data["book"]), [])
            name = next((c.get("title") for c in catalog if str(c.get("chapterUid")) == str(data["uid"])), None)
            name = name or "章节 " + str(data["uid"])
        elif not name and data.get("review"):
            name = "文章 " + str(data["review"])
        stamp = lambda t: datetime.fromtimestamp(t).strftime("%Y-%m-%d %H:%M:%S")
        page.label(self.book_name(r), 48, 292, 976, 98, 36, True)
        page.label(local_duration(r.seconds), 48, 370, 976, 100, 56, True)
        y = 555
        for label, value in (("阅读时间", stamp(r.ended - r.seconds) + " – " + stamp(r.ended).split()[-1]),
                             ("章节" if name else "", name),
                             ("上报结果", LABELS.get(r.status, r.status))):
            if not label:
                continue
            page.value_row(label, value, y, 112)
            y += 115
        note = explanation(r, now)
        y = 950
        app.status = tk.StringVar(value=message)
        if note:
            page.label(note, 48, y, 976, 100, 28, color="#555555").configure(wraplength=round(976*page.factor))
            y += 112
        page.label("", 48, y, 976, 70, 26, color="#555555").configure(textvariable=app.status)
        y = 1154
        action = available_action(r, now)
        if not action:
            return
        def work():
            if self.client.account != self.account:
                return
            if action == "check":
                # Match against every eligible interval in this book. Checking a single
                # row alone could mistake an ambiguous acknowledgement for a match.
                self.client.check_book_reports(known_reports(self.client, data["book"]))
            else:
                for record in app.store.recent_unsent(self.account):
                    if record[0] == r.id:
                        self.client.send_reading_event(*record)
                        break
        def run():
            btn.configure(state="disabled")
            app.status.set("正在核对云端记录…" if action == "check" else "正在检查上报条件…")
            def failed(error):
                self.detail()
                app.error(error)
            def finished(_):
                current, _more = intervals(app.store, self.account, event=r.id, limit=1)
                outcome = ""
                if current and current[0].status == r.status:
                    outcome = ("云端数据尚不能唯一确认本段，记录已保留。" if action == "check"
                               else "本次未获上报确认，记录已保留。")
                self.detail(outcome)
            app.submit(work, finished, failed, executor=app.reporting)
        btn = page.button("核对此书上报结果" if action == "check" else "重试本段上报", run, 48, y, 976, 88, primary=True)
