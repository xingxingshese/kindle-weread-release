"""Search the WeRead catalog from the shelf and open a result in the reader."""
import tkinter as tk

from book_details import description, ordinary, published_details


class Discover:
    def __init__(self, app):
        self.app = app
        self.recent = self.recommendations = None
        self.offset = 0
        self.shelf_ids = {str(book["bookId"]) for book in app.books}
        self.show()

    def show(self):
        app = self.app
        app.clear()
        from pw3_page import Page
        self.page = page = Page(app)
        page.title("发现")
        search=tk.Canvas(page.frame,bg="white",bd=0,highlightthickness=0,takefocus=True)
        page.put(search,936,118,88,88)
        search.create_oval(*(int(v*page.factor) for v in (29,29,52,52)),width=3*page.factor)
        search.create_line(*(int(v*page.factor) for v in (49,49,60,60)),width=3*page.factor)
        for event in ("<ButtonRelease-1>","<Return>","<space>"):
            search.bind(event,lambda _:BookSearch(app,self.show,self.shelf_ids))
        page.footer([("发现",self.show),("书架",app.show_shelf),("我的",app.profile)],"发现")
        app.status=tk.StringVar()
        self.section("最近阅读",True)
        if app.store.get(app.client.account,"personal-recommendations",default=True):
            page.line(48,786,976)
            self.section("猜你喜欢",False)

    def section(self,title,recent):
        from app import photo
        from shelf import cover_thumbnail
        app,page=self.app,self.page
        y=264 if recent else 809
        page.label(title,48,y,340,62,36,True)
        status=tk.StringVar()
        page.label("",402,y,420,62,26,color="#555555").configure(textvariable=status)
        action=page.button("刷新" if recent else "换一批",lambda:advance(),884,y-12,140,88,anchor="e")
        widgets=[]
        def display():
            books=self.recent if recent else self.recommendations
            start=0 if recent else self.offset
            rows=(books or [])[start:start+6]
            for widget in widgets:
                widget.destroy()
            widgets.clear()
            for i,book in enumerate(rows):
                x=48+(i%2)*500
                top=y+74+(i//2)*147
                cover=page.label(book["title"][:4],x,top,88,124,22,True,"center")
                cover.configure(bg="#eeeeee",wraplength=78*page.factor,relief="solid",bd=1)
                heading=page.label(page.shorten(book["title"],362,36),x+111,top+5,365,62,36)
                author=page.label(page.shorten(book.get("author") or "",362,26),x+111,top+67,362,44,26,color="#555555")
                def choose(_,item=book):
                    if recent:
                        app.open_book(item,self.show)
                    else:
                        book_detail(app,item,self.show,self.shelf_ids)
                for widget in (cover,heading,author):
                    widget.bind("<ButtonRelease-1>",choose)
                    widgets.append(widget)
                if book.get("cover"):
                    def loaded(image,target=cover):
                        if image is not None and target.winfo_exists():
                            target.image=photo(image)
                            target.configure(image=target.image,text="")
                    app.submit(lambda url=book["cover"]:cover_thumbnail(url,round(88*page.factor),round(124*page.factor)),
                               loaded,lambda _:None,media=True)
            status.set("" if rows else ("暂无最近阅读" if recent else "暂无推荐书籍"))
            action.configure(state="normal",text="刷新" if recent else "换一批")
        def advance():
            if not recent and self.recommendations and self.offset + 6 < len(self.recommendations):
                self.offset += 6
                display()
                return
            status.set("加载中…")
            action.configure(state="disabled")
            def loaded(books):
                if recent:
                    self.recent = books
                else:
                    self.recommendations, self.offset = books, 0
                display()
            def failed(error):
                status.set("加载失败")
                action.configure(state="normal", text="重试")
                app.error(error)
                status.set(app.status.get())
            app.submit(app.client.recent_books if recent else app.client.recommended_books, loaded, failed)
        if (self.recent if recent else self.recommendations) is None:
            advance()
        else:
            display()


class BookSearch:
    def __init__(self, app, back=None, shelf_ids=None):
        self.app = app
        self.back = back or (lambda: app.show_shelf(True))
        self.keyword = ""
        self.items = []
        self.cursor = self.selected = None
        self.scroll = 0
        self.shelf_ids = shelf_ids if shelf_ids is not None else {str(b["bookId"]) for b in app.books}
        self.show()

    def show(self):
        app = self.app
        app.clear()
        from pw3_page import Page
        self.page=page=Page(app)
        page.title("全站搜书")
        page.footer([("‹ 返回",self.back)])
        term=tk.StringVar(value=self.keyword)
        def search(_=None):
            value=term.get().strip()
            if value:
                self.keyword,self.items,self.cursor=value,[],0
                self.scroll,self.selected=0,None
                self.show()
                self.fetch()
            return "break"
        page.search(term,"搜索书名或作者",search,end=852)
        page.button("搜索",search,870,256,154,88,outline=True)
        page.label("搜索结果",48,394,480,70,36,True)
        app.status=tk.StringVar()
        page.label("",48,1180,976,72,26,color="#555555").configure(textvariable=app.status)
        self.visible=[]
        self.more=page.button("加载更多",self.fetch,48,740,976,88,outline=True)
        self.draw_results()
        self.count()

    def draw_results(self):
        page=self.page
        for w in self.visible:
            w.destroy()
        self.visible=[]
        start=int(self.scroll)
        rows=self.items[start:start+4]
        for i,item in enumerate(rows):
            y=484+i*148
            def open_item(_,idx=start+i):
                self.selected=idx
                self.detail(self.items[idx])
            for widget in (page.label(page.shorten(item["title"],870,36),48,y,870,68,36),
                           page.label(item.get("author") or "",48,y+66,870,50,26,color="#555555"),
                           page.label("›",932,y,92,120,32,anchor="e",color="#777777")):
                widget.bind("<ButtonRelease-1>",open_item)
                self.visible.append(widget)
            self.visible.append(page.line(48,y+130,976,"#dddddd"))
        bottom=min(1080,592+148*len(rows))
        def turn(delta):
            self.scroll=max(0,int(self.scroll)+delta)
            self.draw_results()
        if start:
            self.visible.append(page.button("上一页",lambda:turn(-4),48,bottom,200,88))
        if start+4<len(self.items):
            self.more.place_forget()
            self.visible.append(page.button("下一页",lambda:turn(4),824,bottom,200,88))
        else:
            page.put(self.more,266 if start else 48,bottom,758 if start else 976,88)

    def count(self):
        self.more.configure(state="normal" if self.cursor is not None else "disabled")
        self.app.status.set("" if self.items else ("没有找到相关图书" if self.keyword else "输入书名或作者"))

    def fetch(self):
        if self.cursor is None:
            return
        keyword, cursor = self.keyword, self.cursor
        self.more.configure(state="disabled")
        self.app.status.set("正在搜索…")
        def loaded(result):
            books, self.cursor = result
            seen = {str(b["bookId"]) for b in self.items}
            for book in books:
                key = str(book["bookId"])
                if key not in seen:
                    self.items.append(book)
                    seen.add(key)
            self.draw_results()
            self.more.configure(text="加载更多")
            self.count()
        def failed(error):
            self.app.error(error)
            self.more.configure(text="重试", state="normal")
        client = self.app.client
        self.app.submit(lambda: client.search_library(keyword, cursor), loaded, failed)

    def detail(self, book):
        book_detail(self.app, book, self.show, self.shelf_ids)


def book_detail(app, book, back, shelf_ids, complete=False):
    app.clear()
    from pw3_page import Page
    page=Page(app)
    page.title("书籍详情")
    page.footer([("‹ 返回",back)])
    app.status=tk.StringVar()
    page.label("",48,1250,976,75,26,color="#555555").configure(textvariable=app.status)
    def details():
        book_detail(app,book,back,shelf_ids,complete)
    def read():
        app.open_book(book,details)
    page.button("开始阅读",read,542,1144,482,88,primary=True)
    key = str(book["bookId"])
    def join():
        button.configure(state="disabled")
        app.status.set("正在加入书架…")
        def confirmed(_):
            shelf_ids.add(key)
            button.configure(text="已在书架")
            app.status.set("已加入书架")
        def failed(error):
            app.error(error)
            button.configure(text="核对书架", command=refresh, state="normal")
        client = app.client
        app.submit(lambda: client.add_to_shelf(key), confirmed, failed)
    def refresh():
        button.configure(state="disabled")
        def loaded(books):
            app.books = books
            shelf_ids.clear()
            shelf_ids.update(str(b["bookId"]) for b in books)
            details()
        def failed(error):
            app.error(error)
            button.configure(state="normal")
        app.submit(app.client.shelf, loaded, failed)
    button=page.button("加入书架",join,48,1144,480,88,outline=True)
    if key in shelf_ids:
        button.configure(text="已在书架",state="disabled")
    title=page.label("",48,299,976,84,36,True)
    author=page.label("",48,384,976,66)
    rating=page.label("",48,475,976,66,28,color="#555555")
    page.line(48,592,976,"#dddddd")
    page.label("简介",48,638,976,84,36,True)
    text=tk.Text(page.frame,wrap="char",bd=0,highlightthickness=0,font=page.font(32),spacing2=8)
    page.put(text,48,735,976,320)
    def display():
        title.configure(text=page.shorten(book["title"],976,36))
        author.configure(text=book.get("author") or "")
        parts=description(book).split("\n\n")[1:]
        extras=[v for v in parts if not v.startswith("作者　") and v!=book.get("intro")]
        score=next((v for v in extras if v.startswith("微信读书推荐值")),"")
        rating.configure(text=score.replace("微信读书推荐值","推荐值"))
        body=[v for v in [book.get("intro"),*(v for v in extras if v!=score)] if v]
        pos=text.yview()[0]
        text.configure(state="normal")
        text.delete("1.0","end")
        text.insert("end","\n\n".join(body))
        text.configure(state="disabled")
        text.yview_moveto(pos)
    display()
    start = None
    def press(event):
        nonlocal start
        start = event.x, event.y
    def release(event):
        if start:
            left, vertical = start[0]-event.x, abs(event.y-start[1])
            if left > max(30, text.winfo_width()//6) and left > 2*vertical:
                read()
                return "break"
    text.bind("<ButtonPress-1>", press)
    text.bind("<ButtonRelease-1>", release)
    if not complete and ordinary(key) and not key.startswith("CB_"):
        def enrich():
            retry.configure(state="disabled", text="正在补全资料…")
            def loaded(info):
                nonlocal book, complete
                book = {**book, **info}
                complete = True
                retry.place_forget()
                display()
            def failed(_):
                retry.configure(text="重试完整资料", state="normal")
            client = app.client
            app.submit(lambda: published_details(client, key), loaded, failed, media=True)
        retry=page.button("",enrich,48,1050,440,88)
        enrich()
