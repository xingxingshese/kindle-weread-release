"""Windows QR login and read-only statistics through weread-omni's CLI."""
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

from client import AuthorizationRequired, ReaderError


def tool_paths(store):
    root = store.path.parent / "stats-omni"
    return root, root / "node_modules/weread-omni/dist/cli.js"


def invoke(store, account, args, *, interactive=False, active=None):
    if not account.isascii() or not account.isdigit():
        raise ReaderError("当前书架缺少有效的账号。")
    node = shutil.which("node.exe")
    if not node:
        raise ReaderError("扫码读取时长需要 Node.js 22.13 或更新版本。")
    root, cli = tool_paths(store)
    if interactive and not cli.is_file():
        npm = Path(node).parent / "node_modules/npm/bin/npm-cli.js"
        if not npm.is_file():
            raise ReaderError("没有找到随 Node.js 安装的 npm。")
        root.mkdir(parents=True, exist_ok=True)
        try:
            subprocess.run([node, str(npm), "install", "--prefix", str(root), "--no-save",
                            "--ignore-scripts", "--no-audit", "--no-fund", "weread-omni@0.1.2"],
                           check=True, timeout=90, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                           creationflags=subprocess.CREATE_NO_WINDOW)
        except (OSError, subprocess.SubprocessError):
            raise ReaderError("未能下载阅读时长组件，请检查 npm 网络连接后重试。") from None
    cmd = [node, str(cli), "--account", "reader-" + account, *args]
    env = {k: v for k, v in os.environ.items() if not k.startswith("WEREAD_")}
    env["WEREAD_CONFIG_DIR"] = str(root / "config")
    if interactive:
        if not active():
            raise ReaderError("账号或页面已变更。")
        with subprocess.Popen(cmd, env=env, creationflags=subprocess.CREATE_NEW_CONSOLE) as process:
            deadline = time.monotonic() + 180
            while process.poll() is None:
                if not active() or time.monotonic() >= deadline:
                    process.terminate()
                    raise ReaderError("扫码已取消或超时，请重新扫码。")
                time.sleep(0.25)
            if process.returncode:
                raise ReaderError("微信读书扫码未完成，请重试。")
        return
    try:
        completed = subprocess.run([*cmd, "--json"], check=True, timeout=20, env=env,
                                   stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                   stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
        value = json.loads(completed.stdout)
    except (OSError, subprocess.SubprocessError, ValueError):
        raise ReaderError("阅读时长请求失败，请检查网络或重新扫码。") from None
    if not isinstance(value, dict):
        raise ReaderError("阅读时长接口返回了无法识别的数据。")
    data = value.get("data")
    return data if isinstance(data, dict) else value


def verify_account(store, account):
    identity = invoke(store, account, ["whoami"])
    if str(identity.get("vid", "")) != account:
        raise AuthorizationRequired("扫码账号与当前书架不一致，请使用书架账号重新扫码。")


def login(store, account, active):
    invoke(store, account, ["login"], interactive=True, active=active)
    if active():
        verify_account(store, account)


def read(store, account, active):
    from account_stats import period_totals
    root, cli = tool_paths(store)
    if not cli.is_file() or not (root / "config/accounts" / ("reader-" + account)).is_dir():
        return account, {}
    verify_account(store, account)
    def detail(path, params):
        return invoke(store, account, ["read-data", "detail", "--mode", params["mode"],
                                       "--base-time", str(params["baseTime"])])
    return period_totals(detail, {}, account, active)
