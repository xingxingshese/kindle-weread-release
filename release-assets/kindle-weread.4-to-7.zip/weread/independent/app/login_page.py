"""The QR sign-in screen, laid out inside the native Kindle work area."""
import tkinter as tk

import qrcode


class LoginPage:
    def __init__(self, app, family, leave_label, leave, refresh, photo):
        self.app = app
        self.family = family
        self.photo = photo
        self.code = None
        self.module_size = 0
        self.image = None
        self.canvas = tk.Canvas(app.frame, bg="white", borderwidth=0, highlightthickness=0)
        self.canvas.place(relwidth=1, relheight=1, bordermode="outside")
        self.qr = tk.Label(app.frame, bg="white", bd=0, highlightthickness=0)
        self.status = tk.Label(self.canvas, textvariable=app.status, bg="white",
                               fg="#222222", bd=0, justify="center")
        self.buttons = []
        for label, command, anchor in ((leave_label, leave, "w"), ("刷新二维码", refresh, "e")):
            button = app.button(self.canvas, label, command)
            button.configure(anchor=anchor, bg="white", fg="#222222", activebackground="#eeeeee",
                             activeforeground="#222222", borderwidth=0)
            self.buttons.append(button)
        self.canvas.bind("<Configure>", self.layout)

    def display(self, link):
        self.code = qrcode.QRCode(border=4)
        self.code.add_data(link)
        self.code.make(fit=True)
        self.module_size = 0
        self.layout()

    def invalidate(self):
        self.code = None
        self.image = None
        self.qr.configure(image="")
        self.qr.place_forget()

    def layout(self, event=None):
        c = self.canvas
        w, h = c.winfo_width(), c.winfo_height()
        if min(w, h) <= 1:
            return
        # The reference includes 76 px of system chrome. Tk already receives the
        # usable window, so map only the application's 1372 px to this canvas.
        scale = min(w / 1072, h / 1372)
        def px(value):
            return max(1, round(value * scale))
        def y(value):
            return round((value - 76) * h / 1372)
        def font(size, weight="normal"):
            return self.family, -px(size), weight
        c.delete("all")
        margin = px(48)
        c.create_text(margin, y(164), text="扫码登录", anchor="w", font=font(44, "bold"), fill="#222222")
        c.create_line(margin, y(228), w-margin, y(228), fill="#aaaaaa", width=px(2))
        c.create_text(w/2, y(362), text="用微信扫一扫", font=font(42, "bold"), fill="#222222")
        c.create_text(w/2, y(440), text="扫描下方二维码，在手机上确认登录。",
                      font=font(32), fill="#555555")
        side = px(538)
        cx, cy = w/2, y(793)
        radius = px(12)
        x0, y0, x1, y1 = cx-side/2, cy-side/2, cx+side/2, cy+side/2
        points = (x0+radius,y0, x1-radius,y0, x1,y0, x1,y0+radius, x1,y1-radius,
                  x1,y1, x1-radius,y1, x0+radius,y1, x0,y1, x0,y1-radius, x0,y0+radius, x0,y0)
        c.create_polygon(points, smooth=True, fill="white", outline="#aaaaaa", width=px(2))
        if self.code is not None:
            modules = self.code.modules_count + 2*self.code.border
            module_size = max(1, px(518)//modules)
            if module_size != self.module_size:
                self.code.box_size = module_size
                self.image = self.photo(self.code.make_image().convert("L"))
                self.qr.configure(image=self.image)
                self.module_size = module_size
            self.qr.place(in_=c, x=round(cx), y=cy, anchor="center")
            self.qr.lift()
        self.status.configure(font=font(32), wraplength=w-2*margin)
        self.status.place(relx=.5, y=y(1157), anchor="center")
        top = y(1338)
        c.create_line(0, top, w, top, fill="#aaaaaa", width=px(2))
        for i, button in enumerate(self.buttons):
            button.configure(font=font(28), padx=margin)
            button.place(relx=i*.5, relwidth=.5, y=top+px(2), height=h-top-px(2))
