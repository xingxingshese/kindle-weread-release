"""Touch navigation through the current book's chapters and bookmarks."""
import tkinter as tk

from pw3_page import Page, SECONDARY

ROW_HEIGHT = 104
MARK_ROW_HEIGHT = 144
LIST_TOP = 440
LIST_BOTTOM = 1135


class BookCatalog:
    def __init__(self, app):
        self.app = app
        self.book = str(app.book["bookId"])
        self.chapters = {str(row["chapterUid"]): row for row in app.rows}
        self.active, self.loaded = self.chapters.get(app.uid), app.loaded
        self.index = (app.save_position() if app.text is not None else
                      app.store.get(app.client.account, "position", self.book, {}).get("index", "1.0"))
        self.levels = [max(0, int(row["level"])) if row.get("level") not in (None, "") else 1
                       for row in app.rows]
        self.top_level = min(self.levels, default=1)
        self.collapsed = False
        self.marks = None
        self.chapter_page = self.mark_page = 0
        self.positioned = False
        self.show()

    @property
    def page(self):
        return self.mark_page if self.bookmarks else self.chapter_page

    @page.setter
    def page(self, value):
        if self.bookmarks:
            self.mark_page = value
        else:
            self.chapter_page = value

    def leave(self):
        if self.active:
            self.app.read(self.active, self.index, self.loaded)
        else:
            self.app.book_back()

    def visible_entries(self):
        if self.bookmarks:
            return self.entries
        return [(row, level) for row, level in zip(self.app.rows, self.levels)
                if not self.collapsed or level == self.top_level]

    def rows_per_page(self):
        height = MARK_ROW_HEIGHT if self.bookmarks else ROW_HEIGHT
        return max(1, (LIST_BOTTOM - LIST_TOP) // height)

    def total_pages(self):
        return max(1, -(-len(self.visible_entries()) // self.rows_per_page()))

    def show(self, bookmarks=False):
        app = self.app
        app.clear()
        self.bookmarks = bookmarks
        if bookmarks:
            self.mark_page = 0
        page = self.page_widget = Page(app)
        page.title("书签" if bookmarks else "章节目录")
        if not bookmarks:
            page.button("搜全书", self.search, 884, 118, 140, 88, anchor="e")
        app.status = tk.StringVar()
        page.label("", 48, 372, 976, 56, 26, color=SECONDARY).configure(textvariable=app.status)
        self.rows_frame = []
        if bookmarks:
            self.entries = []
            self.retry = page.button("重试", self.load_marks, 48, 1151, 976, 88, outline=True)
            self.retry.place_forget()
            self.load_marks()
        else:
            self.entries = None
            book_title = app.book.get("title") or ""
            page.label(book_title, 48, 278, 976, 82, 36, True)
            tools = []
            if any(level > self.top_level for level in self.levels):
                tools.append(("fold", self.fold_chapters))
            tools.append(("edge", self.jump))
            tools.append(("marks_btn", self.open_marks))
            self.fold = self.edge = self.marks_btn = None
            width = 976 / len(tools)
            for i, (key, action) in enumerate(tools):
                btn = page.button("", action, 48 + i * width, 1151, width - 14, 88, outline=True)
                setattr(self, key, btn)
            if not self.positioned:
                self.goto_active_page()
                self.positioned = True
            self.draw_toolbar()
            self.draw_page()
        nav = page.footer([("‹ 返回", self.show if bookmarks else self.leave),
                           ("上一页", lambda: self.turn(-1)), ("下一页", lambda: self.turn(1))])
        self.back_up, self.back_down = nav["上一页"], nav["下一页"]
        self.update_nav()

    def draw_toolbar(self):
        if self.fold is not None:
            self.fold.configure(text="展开目录" if self.collapsed else "折叠目录")
        if self.marks_btn is not None:
            self.marks_btn.configure(text="书签")
        self.edge.configure(text="去底部" if self.page < self.total_pages() - 1 else "去顶部")

    def goto_active_page(self):
        entries = self.visible_entries()
        index = next((i for i, (row, _) in enumerate(entries) if row is self.active), None)
        if index is not None:
            self.page = index // self.rows_per_page()

    def draw_page(self):
        app, page = self.app, self.page_widget
        for widget in self.rows_frame:
            widget.destroy()
        self.rows_frame = []
        per_page = self.rows_per_page()
        entries = self.visible_entries()
        start = self.page * per_page
        height = MARK_ROW_HEIGHT if self.bookmarks else ROW_HEIGHT
        for i, entry in enumerate(entries[start:start + per_page]):
            y = LIST_TOP + i * height
            if self.bookmarks:
                mark = entry
                row = self.chapters.get(str(mark.get("uid")))
                title = row["title"] if row else "章节已变更"
                quote = " ".join((mark.get("quote") or "").split())
                heading = page.label(title, 48, y, 850, 88, 36, anchor="w")
                caption = page.label(quote, 48, y + 92, 850, 44, 26, color=SECONDARY, anchor="w")
                arrow = page.label("›", 898, y, 126, height, 28, color=SECONDARY, anchor="e")
                widgets = (heading, caption, arrow)
                target = mark
            else:
                row, level = entry
                indent = "　" * min(3, level - self.top_level)
                title = indent + (row.get("title") or "未命名章节")
                heading = page.button(title, lambda r=row: self.choose(r), 48, y, 850, height, 36, anchor="w")
                if row is self.active:
                    side = page.label("正在读", 898, y, 126, height, 28, color=SECONDARY, anchor="e")
                else:
                    side = page.button("›", lambda r=row: self.choose(r), 898, y, 126, height, 28, anchor="e")
                widgets = (heading, side)
                target = row
            for widget in widgets:
                if self.bookmarks:
                    widget.bind("<ButtonRelease-1>", lambda _e, m=target: self.choose(m))
                self.rows_frame.append(widget)
            self.rows_frame.append(page.line(48, y + height - 2, 976))
        self.app.status.set(self.status_text())

    def status_text(self):
        if self.bookmarks:
            return f"{len(self.entries)} 个书签" if self.entries else "暂无书签"
        return "当前阅读 · " + self.active["title"] if self.active else f"{len(self.app.rows)} 章"

    def update_nav(self):
        self.back_up.configure(state="disabled" if self.page <= 0 else "normal")
        self.back_down.configure(state="disabled" if self.page >= self.total_pages() - 1 else "normal")

    def refresh(self):
        self.draw_toolbar()
        self.draw_page()
        self.update_nav()

    def fold_chapters(self):
        near = self.visible_entries()[self.page * self.rows_per_page()][0] if self.visible_entries() else None
        self.collapsed = not self.collapsed
        entries = self.visible_entries()
        index = next((i for i, (row, _) in enumerate(entries) if row is near), 0)
        self.page = index // self.rows_per_page()
        self.refresh()

    def open_marks(self):
        self.show(bookmarks=True)

    def load_marks(self):
        self.retry.place_forget()
        if self.marks is not None:
            self.display_marks(self.marks)
            return
        app, client = self.app, self.app.client
        app.status.set("正在读取书签…")
        def failed(error):
            app.error(error)
            self.page_widget.put(self.retry, 48, 1151, 976, 88)
        app.submit(lambda: client.notes_page(self.book, "bookmarks"),
                   lambda result: self.display_marks(result[0]), failed)

    def display_marks(self, marks):
        self.marks = self.entries = marks
        self.page = 0
        self.draw_page()
        self.update_nav()

    def search(self):
        self.app.search_book(back=self.show)

    def turn(self, delta):
        self.page = max(0, min(self.total_pages() - 1, self.page + delta))
        self.refresh()

    def jump(self):
        self.page = self.total_pages() - 1 if self.page < self.total_pages() - 1 else 0
        self.refresh()

    def choose(self, target):
        if self.bookmarks:
            row = self.chapters.get(str(target.get("uid")))
            offset = str(target.get("range", "")).split("-")[0]
            if row and offset.isdigit():
                self.app.read(row, source_offset=int(offset))
            elif row and target.get("quote"):
                self.app.read(row, hit={"abstract": target["quote"]})
            else:
                self.app.status.set("无法定位此书签，请返回目录。")
        elif target is self.active:
            self.leave()
        else:
            self.app.read(target)
