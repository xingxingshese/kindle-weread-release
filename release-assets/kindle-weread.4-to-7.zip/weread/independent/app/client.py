"""Account-scoped data and the independent reader's WeRead client."""
import base64
import errno
import hashlib
import http.cookiejar
import json
import re
import secrets
import socket
import sqlite3
import time
import threading
from contextlib import contextmanager, closing
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, unquote, urlencode, urlsplit
from urllib.request import HTTPCookieProcessor, Request, build_opener, urlopen
import io
import tarfile

from resources.article_time import AGENT, ArticleSession, app_id, checksum, reader_id
from resources.mp import NoRedirect

WEB = "https://weread.qq.com"


class ReaderError(Exception):
    pass


class AuthorizationRequired(ReaderError):
    pass


class OfficialChapterRequired(ReaderError):
    def __init__(self, url):
        super().__init__("微信读书未向独立版返回本章正文，可在官方阅读页继续。")
        self.url = url


def connection_not_established(error):
    reason = error.reason if isinstance(error, URLError) else error
    return isinstance(reason, (socket.gaierror, ConnectionRefusedError)) or getattr(reason, "errno", None) in (
        errno.ENETDOWN, errno.ENETUNREACH, errno.EHOSTUNREACH)


class Library:
    def __init__(self, directory):
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / "library.sqlite"
        with self.connect() as db:
            db.execute("create table if not exists items (account text, kind text, id text, "
                       "value text not null, primary key(account, kind, id))")
            db.execute("create table if not exists reading_events (account text not null, id text not null, "
                       "ended integer not null, seconds integer not null, detail text not null, "
                       "status text not null, primary key(account,id))")

    def record_reading(self, account, ended, seconds, detail):
        event = secrets.token_hex(16)
        with self.connect() as db:
            db.execute("insert into reading_events values(?,?,?,?,?, 'pending')",
                       (account, event, ended, seconds, json.dumps(detail, ensure_ascii=False)))
        return event

    def reading_status(self, account, event, before, after):
        with self.connect() as db:
            return db.execute("update reading_events set status=? where account=? and id=? and status=?",
                              (after, account, event, before)).rowcount == 1

    def reading_totals(self, account, starts):
        totals = [0 for _ in starts]
        states = {}
        # Count just the portion after each local midnight for cross-day sessions.
        sums = ", ".join("sum(min(seconds,max(0,ended-?)))" for _ in starts)
        with self.connect() as db:
            for status, seconds, *parts in db.execute(
                    f"select status,sum(seconds),{sums} from reading_events where account=? group by status",
                    (*starts, account)):
                for index, part in enumerate(parts):
                    totals[index] += part
                states[status] = seconds
        return totals, states

    def recent_unsent(self, account):
        now = int(time.time())
        with self.connect() as db:
            rows = db.execute("select id,detail,ended,seconds from reading_events where account=? "
                              "and status='pending' and ended>? and ended<=? order by ended,rowid",
                              (account, now-120, now)).fetchall()
        result = []
        for event, raw, end, seconds in rows:
            detail = json.loads(raw)
            if "review" in detail or "offset" in detail:
                result.append((event, detail, end, seconds))
        return result

    def begin_book_report(self, account, event, detail):
        with self.connect() as db:
            return db.execute("update reading_events set status='unconfirmed',detail=? "
                              "where account=? and id=? and status='pending'",
                              (json.dumps(detail, ensure_ascii=False), account, event)).rowcount == 1

    def unconfirmed_reports(self, account):
        with self.connect() as db:
            rows = db.execute("select id,detail,seconds from reading_events where account=? "
                              "and status='unconfirmed'", (account,)).fetchall()
        return [(event, json.loads(detail), seconds) for event, detail, seconds in rows]

    @contextmanager
    def connect(self):
        with closing(sqlite3.connect(self.path)) as db, db:
            yield db

    def get(self, account, kind, key="", default=None):
        with self.connect() as db:
            row = db.execute("select value from items where account=? and kind=? and id=?",
                             (account, kind, key)).fetchone()
        return json.loads(row[0]) if row else default

    def put(self, account, kind, key, value):
        with self.connect() as db:
            db.execute("insert or replace into items values(?,?,?,?)",
                       (account, kind, key, json.dumps(value, ensure_ascii=False)))

    def save_shelf(self, account, books, archives):
        with self.connect() as db:
            db.executemany("insert or replace into items values(?,?,?,?)",
                           [(account, kind, "", json.dumps(value, ensure_ascii=False))
                            for kind, value in (("shelf", books), ("shelf-archives", archives))])

    def discard_chapter(self, account, key):
        with self.connect() as db:
            db.execute("delete from items where account=? and id=? "
                       "and kind in ('chapter','illustrations')", (account, key))

    def reading_cache(self, account, *, clear=False):
        if not account:
            raise ReaderError("请先登录要清理的账号。")
        where = "account=? and kind in ('catalog','chapter','illustrations','chapter-underlines','article-list','article-read')"
        with self.connect() as db:
            db.execute("begin immediate" if clear else "begin")
            rows, payload = db.execute("select count(*), coalesce(sum(length(cast(value as blob))),0) "
                                       "from items where " + where, (account,)).fetchone()
            files = self._article_cache_files(db, account)
            file_bytes = 0
            for path in files:
                try:
                    size = path.stat().st_size
                    if clear:
                        path.unlink()
                    file_bytes += size
                except FileNotFoundError:
                    continue
            reusable = 0
            if clear:
                before = db.execute("pragma freelist_count").fetchone()[0]
                db.execute("delete from items where " + where, (account,))
                after = db.execute("pragma freelist_count").fetchone()[0]
                reusable = max(0, after - before) * db.execute("pragma page_size").fetchone()[0]
        return {"rows": rows, "payload": payload, "file_bytes": file_bytes, "reusable": reusable}

    def _article_cache_files(self, db, account):
        # Older builds share a directory of URL-hashed sources and resized pictures.
        # Only delete files referenced by this account and by no other account.
        folder = self.path.parent / "article-images"
        if not folder.is_dir() or folder.resolve() != folder.parent.resolve() / folder.name:
            return []
        from resources.mp_image import image_url
        def hashes(rows):
            for (raw,) in rows:
                for item in json.loads(raw):
                    if len(item) < 2 or item[0] != "picture":
                        continue
                    try:
                        url = image_url(item[1])
                    except ValueError:
                        continue
                    yield hashlib.sha256(url.encode()).hexdigest()
        query = "select value from items where kind='article-read' and account"
        owned = set(hashes(db.execute(query + "=?", (account,))))
        if not owned:
            return []
        owned.difference_update(hashes(db.execute(query + "<>?", (account,))))
        return [path for path in folder.iterdir()
                if path.name[:64] in owned and re.fullmatch(r"[0-9a-f]{64}(?:-\d+\.png)?", path.name)
                and path.is_file() and not path.is_symlink()]

    def save_renewal(self, previous, renewed):
        with self.connect() as db:
            db.execute("begin immediate")
            row = db.execute("select value from items where account='' and kind='session' and id=''").fetchone()
            current = json.loads(row[0]) if row else {}
            if current == previous:
                db.execute("update items set value=? where account='' and kind='session' and id=''",
                           (json.dumps(renewed, ensure_ascii=False),))
                return renewed
            return current if current.get("wr_vid") == previous["wr_vid"] else None

    def save_native_session(self, session):
        with self.connect() as db:
            db.execute("begin immediate")
            db.executemany("insert or replace into items values('' ,?,'',?)",
                           [("session", json.dumps(session)), ("native-session-owner", json.dumps(session["wr_vid"]))])

    def forget_session(self, account):
        with self.connect() as db:
            db.execute("begin immediate")
            row = db.execute("select value from items where account='' and kind='session' and id=''").fetchone()
            if row and json.loads(row[0]).get("wr_vid") == account:
                db.execute("delete from items where account='' and kind='session' and id=''")
                db.execute("delete from items where account='' and kind='native-session-owner' and id=''")


class Client:
    def __init__(self, library, restore=True):
        self.store = library
        self.article_clock_session = None
        self.renew_lock = threading.Lock()
        self.signed_out = False
        policy = http.cookiejar.DefaultCookiePolicy(
            strict_ns_domain=http.cookiejar.DefaultCookiePolicy.DomainStrictNonDomain)
        self.cookies = http.cookiejar.CookieJar(policy)
        self.opener = build_opener(NoRedirect(), HTTPCookieProcessor(self.cookies))
        fp = library.get("", "fingerprint")
        if fp is None:
            fp = str(secrets.randbits(32))
            library.put("", "fingerprint", "", fp)
        self.cookie("wr_fp", fp)
        if restore:
            for name, value in library.get("", "session", default={}).items():
                self.cookie(name, value)
            self.restore_stats_cookie_scopes()

    def stats_cookie_available(self):
        request = Request("https://i.weread.qq.com/readdata/detail")
        self.cookies.add_cookie_header(request)
        fields = dict(entry.split("=", 1) for entry in request.get_header("Cookie", "").split("; ") if "=" in entry)
        return bool(fields.get("wr_skey")) and fields.get("wr_vid") == self.account

    def remember_stats_cookie_scopes(self):
        # Store the issuer's scope alongside existing login data, without a
        # second copy of the secrets. Old flat logins stay host-only.
        scopes = {}
        for c in self.cookies:
            if (c.name in ("wr_vid", "wr_skey") and c.secure and not c.discard and not c.is_expired()
                    and c.domain_specified and c.domain.lstrip(".") == "weread.qq.com" and c.path == "/"):
                scopes[c.name] = [hashlib.sha256(c.value.encode()).hexdigest(), c.expires]
        if self.account:
            self.store.put(self.account, "stats-cookie-scopes", "", scopes)

    def restore_stats_cookie_scopes(self):
        scopes = self.store.get(self.account, "stats-cookie-scopes", default={})
        for cookie in list(self.cookies):
            saved = scopes.get(cookie.name) if isinstance(scopes, dict) else None
            if (cookie.name not in ("wr_vid", "wr_skey") or not isinstance(saved, list) or len(saved) != 2
                    or saved[0] != hashlib.sha256(cookie.value.encode()).hexdigest()
                    or type(saved[1]) is not int or saved[1] <= time.time()):
                continue
            self.cookies.clear(cookie.domain, cookie.path, cookie.name)
            cookie.domain, cookie.domain_specified, cookie.domain_initial_dot = ".weread.qq.com", True, True
            cookie.expires, cookie.discard = saved[1], False
            self.cookies.set_cookie(cookie)

    def cookie(self, name, value):
        for existing in list(self.cookies):
            if existing.name == name:
                self.cookies.clear(existing.domain, existing.path, name)
        self.cookies.set_cookie(http.cookiejar.Cookie(
            0, name, value, None, False, "weread.qq.com", False, False, "/", True,
            True, None, True, None, None, {}, False))

    def session(self):
        names = {"wr_vid", "wr_skey", "wr_rt", "wr_ql"}
        return {c.name: c.value for c in self.cookies if c.name in names}

    @property
    def account(self):
        return self.session().get("wr_vid", "")

    def request(self, url, body=None, headers=None, timeout=18):
        if self.signed_out:
            raise ReaderError("已退出本机账号，请重新扫码登录。")
        defaults = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kindle-WeRead",
                    "Referer": WEB + "/"}
        if body is not None:
            defaults.update({"Content-Type": "application/json", "Origin": WEB})
        req = Request(url, json.dumps(body).encode() if body is not None else None,
                      {**defaults, **(headers or {})})
        try:
            with self.opener.open(req, timeout=timeout) as response:
                return response.read().decode("utf-8")
        except HTTPError as exc:
            if exc.code in (401, 403):
                raise AuthorizationRequired("微信读书未授权此次请求，可返回并重新扫码。") from None
            raise ReaderError(f"微信读书请求失败（HTTP {exc.code}）。") from None

    def begin(self):
        self.request(WEB + "/")
        uid = self.json(WEB + "/api/auth/getLoginUid").get("uid")
        if not isinstance(uid, str) or not uid:
            raise ReaderError("微信读书未返回二维码，请重新获取。")
        return uid

    def request_with_renewal(self, url, decode, *, read_only=False, **kwargs):
        previous = self.session()
        data = decode(self.request(url, **kwargs))
        if (isinstance(data, dict) and data.get("errCode") in (-2012, -2010)
                and (kwargs.get("body") is None or read_only) and previous.get("wr_rt") and previous.get("wr_vid")
                and url.startswith((WEB + "/web/", WEB + "/api/"))):
            if self.renew(previous, url):
                data = decode(self.request(url, **kwargs))
            if isinstance(data, dict) and data.get("errCode") in (-2012, -2010):
                raise AuthorizationRequired("登录已过期，请回到书架点「扫码登录」。")
        return data

    def json(self, url, *, read_only=False, **kwargs):
        data = self.request_with_renewal(url, json.loads, read_only=read_only, **kwargs)
        if not isinstance(data, dict):
            raise ReaderError("微信读书返回了无法识别的数据。")
        if data.get("errCode") not in (None, 0, "0"):
            raise ReaderError(str(data.get("errMsg") or "微信读书拒绝了此次请求。"))
        return data

    def renew(self, previous, url):
        with self.renew_lock:
            if self.session() != previous:
                return self.account == previous["wr_vid"]
            current = self.store.get("", "session", default={})
            if current == previous:
                # Let the normal web renewal exchange update its own cookie jar.
                temp = Client(self.store, restore=False)
                for name, value in previous.items():
                    temp.cookie(name, value)
                temp.restore_stats_cookie_scopes()
                args = {"rq": quote(urlsplit(url).path, safe=""), "ql": previous.get("wr_ql") == "1"}
                data = json.loads(temp.request(WEB + "/web/login/renewal", body=args,
                                               headers={"Referer": WEB + "/web/shelf"}))
                if not isinstance(data, dict) or data.get("succ") != 1:
                    return False
                renewed = temp.session()
                if renewed.get("wr_vid") != previous["wr_vid"] or not renewed.get("wr_skey"):
                    return False
                current = self.store.save_renewal(previous, renewed)
                if current == renewed:
                    temp.remember_stats_cookie_scopes()
            if not current or current.get("wr_vid") != previous["wr_vid"]:
                return False
            for name, value in current.items():
                self.cookie(name, value)
            self.restore_stats_cookie_scopes()
            return True

    def poll(self, uid, otp=""):
        params = {"uid": uid}
        if otp:
            params["otp"] = otp
        try:
            data = self.json(WEB + "/api/auth/getLoginInfo?" + urlencode(params), timeout=8)
        except (TimeoutError, socket.timeout):
            return "waiting"
        except URLError as exc:
            if isinstance(exc.reason, TimeoutError):
                return "waiting"
            raise
        if data.get("succeed") is not True:
            return data.get("logicCode") or "waiting"
        names = {"webLoginVid": "wr_vid", "accessToken": "wr_skey", "refreshToken": "wr_rt"}
        if not all(data.get(key) for key in names):
            raise ReaderError("登录确认缺少会话信息，请重新扫码。")
        for key, name in names.items():
            value = quote(str(data[key]), safe="")
            if not any(c.name == name and c.value == value and c.path == "/" and not c.is_expired()
                       and c.domain.lstrip(".") == "weread.qq.com" for c in self.cookies):
                self.cookie(name, value)
        self.cookie("wr_ql", "0")
        self.remember_stats_cookie_scopes()
        return "ok"

    def shelf(self):
        if not self.account:
            raise ReaderError("请先用微信扫码登录。")
        if self.has_native_login():
            data = self.native_get("/shelf/sync", {"synckey": 0, "lectureSynckey": 0})
        else:
            data = self.json(WEB + "/web/shelf/sync?synckey=0", headers={"Referer": WEB + "/web/shelf"})
        if not isinstance(data.get("books"), list):
            raise ReaderError("微信读书未返回完整书架，请重试。")
        books = [b for b in data["books"] if b.get("bookId") and b.get("title") and b["bookId"] != "mpbook"]
        books.sort(key=lambda b: (b.get("isTop") or 0, b.get("readUpdateTime") or 0),
                   reverse=True)
        archives = data.get("archive", [])
        if not isinstance(archives, list):
            raise ReaderError("微信读书未返回完整的书架分组，请重试。")
        self.store.save_shelf(self.account, books, archives)
        return books

    def has_native_login(self):
        return bool(self.account and self.store.get("", "native-session-owner") == self.account)

    def native_get(self, path, params):
        return self.native_request(path + "?" + urlencode(params))

    def native_request(self, path, *, body=None):
        if self.signed_out or not self.has_native_login():
            raise AuthorizationRequired("请重新扫码登录。")
        from native_login import API, request
        try:
            data = request(API + path, body=body, headers={
                "vid": self.account, "accessToken": unquote(self.session()["wr_skey"])})
        except HTTPError as exc:
            if exc.code == 401:
                raise AuthorizationRequired("登录已过期，请重新扫码。") from None
            raise
        code = str(data.get("errCode", data.get("errcode", 0)))
        if code in ("-2010", "-2012", "-2013"):
            raise AuthorizationRequired("登录已过期，请重新扫码。")
        if code != "0":
            raise ReaderError("微信读书未确认这次请求，请刷新或重新登录。")
        return data

    def state(self, book, chapter=None):
        import re
        url = WEB + "/web/reader/" + reader_id(book)
        if chapter is not None:
            url += "k" + reader_id(chapter)
        html = self.request(url)
        marker = re.search(r"window\.__INITIAL_STATE__\s*=\s*", html)
        if not marker:
            raise ReaderError("网页未返回阅读信息，请检查登录状态。")
        state = json.JSONDecoder().raw_decode(html[marker.end():])[0].get("reader", {})
        if str(state.get("bookId")) != book or state.get("isBookForbidden"):
            raise ReaderError("微信读书未开放这本书的阅读。")
        return url, state

    def catalog(self, book):
        url, state = self.state(book)
        rows = [c for c in state.get("chapterInfos", []) if c.get("chapterUid") is not None]
        if not rows:
            raise ReaderError("微信读书未返回目录。")
        self.store.put(self.account, "catalog", book, rows)
        progress = state.get("progress") or {}
        if self.has_native_login():
            try:
                snapshot = self.json(WEB + "/web/book/getProgress?" + urlencode({"bookId": book}),
                                     headers={"Referer": url})
                if str(snapshot.get("bookId")) == book and isinstance(snapshot.get("book"), dict):
                    progress = snapshot
            except (ReaderError, OSError, ValueError):
                pass  # The reader page already supplied its own progress snapshot.
        remote = progress.get("book") if str(progress.get("bookId")) == book else None
        if isinstance(remote, dict) and remote.get("chapterUid") is not None and remote.get("updateTime"):
            self.store.put(self.account, "cloud-position", book,
                           {"uid": str(remote["chapterUid"]), "summary": remote.get("summary") or "",
                            "changed": int(remote["updateTime"]), "offset": int(remote.get("chapterOffset") or 0)})
        else:
            self.store.put(self.account, "cloud-position", book, None)
        return rows

    def search_book(self, book, keyword, cursor=0):
        params = {"bookId": book, "keyword": keyword, "maxIdx": cursor}
        data = {}
        if self.has_native_login():
            try:
                data = self.native_get("/book/search", params)
            except HTTPError as error:
                if error.code not in (404, 405, 499):
                    raise
        if not isinstance(data.get("result"), list):
            data = self.json(WEB + "/web/book/search?" + urlencode(params))
        rows = data.get("result")
        if not isinstance(rows, list):
            raise ReaderError("微信读书未返回搜索结果。")
        following = rows[-1].get("searchIdx") if rows and data.get("hasMore") else None
        if following is not None and int(following) <= cursor:
            following = None
        return rows, following

    def dictionary(self, word):
        data = self.json(WEB + "/web/dict/query?" + urlencode({"word": word}))
        if data.get("status") == -1:
            return []
        if data.get("status") != 1:
            raise ReaderError("词典查询未获确认，请重试。")
        message = data.get("message") or {}
        lines = []
        for key, label in (("spell_en", "英"), ("spell_am", "美")):
            if message.get(key):
                lines.append(label + " [" + message[key] + "]")
        for row in message.get("result", []):
            if row.get("spell"):
                lines.append(row["spell"])
            if row.get("mean"):
                part = row.get("part") or ""
                parts = {"n": "n.", "j": "adj.", "d": "adv.", "i": "vi.", "t": "vt.", "v": "v."}
                lines.append(" ".join(filter(None, (parts.get(part, part), row["mean"]))))
            lines.extend(item["mean"] for item in row.get("means", []) if item.get("mean"))
            for key, label in (("origin", "出处"), ("usage", "用法"), ("example", "例句")):
                if isinstance(row.get(key), str) and row[key]:
                    lines.append(label + "　" + row[key])
        if data.get("baike"):
            lines.extend(("百科释义", data["baike"]))
        return lines

    def account_profile(self):
        if self.has_native_login():
            data = self.native_get("/user/profile", {"userVid": self.account, "gender": 1, "signature": 1,
                                   "vDesc": 1, "totalReadingTime": 1, "currentReadingTime": 1,
                                   "isBlackMe": 1, "isInBlackList": 1})
            identity = data.get("userVid", self.account)
        else:
            data = self.json(WEB + "/web/user?" + urlencode({"userVid": self.account}))
            identity = data.get("userVid")
        if str(identity) != self.account or not data.get("name"):
            raise ReaderError("微信读书未返回当前账号的资料。")
        profile = {k: data.get(k) or "" for k in ("name", "signature")}
        profile["medal"] = (data.get("medalInfo") or {}).get("title") or ""
        self.store.put(self.account, "profile", "", profile)
        return profile

    def send_reading_event(self, event, detail, ended, seconds):
        if self.signed_out:
            return
        if not 0 <= time.time() - ended < 120:
            return
        if "review" not in detail:
            self.report_book_time(event, detail, ended, seconds)
            return
        identity = (self.account, detail["book"], self.session().get("wr_skey"))
        if not self.article_clock_session or self.article_clock_session[0] != identity:
            cookies = "; ".join(f"{k}={v}" for k, v in self.session().items())
            self.article_clock_session = identity, ArticleSession(cookies, detail["book"])
        if time.time() - ended >= 120 or not self.store.reading_status(self.account, event, "pending", "unconfirmed"):
            return
        try:
            response = self.article_clock_session[1].report(detail["review"], seconds)
            if response.get("succ") != 1:
                raise ReaderError("本段阅读时长未获确认")
            self.store.reading_status(self.account, event, "unconfirmed", "confirmed")
        except Exception as exc:
            self.article_clock_session = None
            if connection_not_established(exc):
                self.store.reading_status(self.account, event, "unconfirmed", "pending")
            raise

    def report_book_time(self, event, detail, ended, seconds):
        # The online reading endpoint also writes the current device position.
        # Older offline time requires a historical-time endpoint.
        if not 0 <= time.time() - ended < 120 or "offset" not in detail:
            return
        book, uid = detail["book"], detail["uid"]
        url, state = self.state(book, uid)
        current = state.get("currentChapter") or {}
        if str(current.get("chapterUid")) != uid or current.get("chapterIdx") is None:
            return
        if (state.get("bookInfo") or {}).get("version") != detail["version"]:
            return
        progress = (state.get("progress") or {}).get("book") or {}
        if int(progress.get("updateTime") or 0) > min(ended, detail.get("cloudSeen", 0)):
            previous = self.store.get(self.account, "last-reported", book, {})
            if not (progress.get("appId") == app_id() and
                    (str(progress.get("chapterUid")), progress.get("chapterOffset")) ==
                    (previous.get("uid"), previous.get("offset")) and
                    int(progress["updateTime"]) <= previous.get("confirmed", 0)):
                return
        stamp = state.get("psvts")
        token = state.get("token") or self.json(WEB + "/web/getConfig").get("token")
        if not stamp or not token:
            return
        now = time.time_ns() // 1000000
        if not 0 <= now // 1000 - ended < 120:
            return
        rn = secrets.randbelow(1000)
        total = state["bookInfo"].get("totalWords") or detail["totalWords"]
        percent = min(100, 100 * detail["words"] // total)
        fields = dict(appId=app_id(), b=reader_id(book), c=reader_id(uid), ci=current["chapterIdx"],
                      co=detail["offset"], sm=detail["summary"][:20], pr=percent,
                      rt=seconds, ts=now, rn=rn, ct=now//1000, ps=stamp, pc=reader_id(now//1000),
                      sg=hashlib.sha256(f"{now}{rn}{token}".encode()).hexdigest())
        fields["s"] = checksum(fields)
        detail = dict(detail, submitted=now//1000, priorSeconds=progress.get("readingTime"))
        if not self.store.begin_book_report(self.account, event, detail):
            return
        try:
            data = self.json(WEB + "/web/book/read", body=fields, headers={"Referer": url, "User-Agent": AGENT})
        except OSError as exc:
            if connection_not_established(exc):
                self.store.reading_status(self.account, event, "unconfirmed", "pending")
            raise
        if data.get("succ") == 1:
            self.confirm_book_report(event, detail, int(time.time()))
        elif "succ" not in data and detail["priorSeconds"] is not None:
            self.check_book_reports([r for r in self.store.unconfirmed_reports(self.account) if r[1]["book"] == book])

    def confirm_book_report(self, event, detail, confirmed, status="confirmed"):
        if self.store.reading_status(self.account, event, "unconfirmed", status):
            self.store.put(self.account, "last-reported", detail["book"],
                           {"uid": detail["uid"], "offset": detail["offset"], "confirmed": confirmed})

    def check_book_reports(self, events):
        books = {}
        matches = {}
        for event, detail, seconds in events:
            if not isinstance(detail.get("priorSeconds"), int):
                continue
            book = detail["book"]
            if book not in books:
                _, state = self.state(book)
                cloud = state.get("progress") or {}
                books[book] = (cloud.get("book") or {}) if str(cloud.get("bookId")) == book else {}
            progress = books[book]
            updated = int(progress.get("updateTime") or 0)
            if (progress.get("appId") == app_id() and str(progress.get("chapterUid")) == detail["uid"]
                    and progress.get("chapterOffset") == detail["offset"]
                    and progress.get("summary") == detail["summary"][:20]
                    and detail["submitted"] <= updated < detail["submitted"] + 120
                    and progress.get("readingTime") == detail["priorSeconds"] + seconds):
                matches.setdefault(book, []).append((event, detail, updated))
        for candidates in matches.values():
            if len(candidates) == 1:
                self.confirm_book_report(*candidates[0], status="matched")

    def account_balance(self):
        if self.has_native_login():
            data = self.native_request("/pay/balance", body={"pf": "android"})
        else:
            data = self.json(WEB + "/web/pay/balance", read_only=True, body={"pf": "android"},
                             headers={"Referer": WEB + "/web/shelf"})
        balance = data.get("balance")
        if type(balance) not in (int, float):
            raise ReaderError("微信读书未返回书币余额。")
        result = {"balance": balance, "updated": int(time.time())}
        self.store.put(self.account, "account-balance", "", result)
        return result

    def membership(self):
        data = (self.native_get("/pay/memberCardSummary", {"pf":"android", "snapshot":1, "source":""})
                if self.has_native_login() else self.json(WEB + "/web/pay/memberCardSummary?pf=android&snapshot=1&source=",
                         headers={"Referer": WEB + "/web/shelf"}))
        if data.get("permanent") not in (0, 1) or data.get("expired") not in (0, 1):
            raise ReaderError("微信读书未返回会员状态。")
        now = int(time.time())
        ends = data.get("expiredTime")
        if not ends and isinstance(data.get("remainTime"), int):
            ends = (data.get("timestamp") or now) + data["remainTime"]
        if not (data["permanent"] or data["expired"]) and not isinstance(ends, int):
            raise ReaderError("微信读书未返回会员有效期。")
        result = {"permanent": bool(data["permanent"]), "expired": bool(data["expired"]),
                  "ends": ends or 0, "updated": now}
        self.store.put(self.account, "membership", "", result)
        return result

    def recent_books(self):
        data = (self.native_get("/storyfeed/getRecentBooks", {"count": 6}) if self.has_native_login()
                else self.json(WEB + "/api/storyfeed/getRecentBooks?count=6", headers={"Referer": WEB + "/"}))
        if not isinstance(data.get("items"), list):
            raise ReaderError("微信读书未返回最近阅读。")
        books = [item["book"] for item in data["items"] if not item.get("isRecommend")
                 and (item.get("book") or {}).get("bookId") and item["book"].get("title")]
        return books[:6]

    def recommended_books(self):
        data = self.json(WEB + "/api/promo/list?type=recommend_new&subtype=0&count=18",
                         headers={"Referer": WEB + "/"})
        if not isinstance(data.get("books"), list):
            raise ReaderError("微信读书未返回推荐书籍。")
        books = {}
        for book in data["books"]:
            if book.get("bookId") and book.get("title"):
                books.setdefault(str(book["bookId"]), book)
        return list(books.values())

    def search_library(self, keyword, cursor=0):
        params = {"keyword": keyword, "count": 20, "maxIdx": cursor, "fragmentSize": 120, "scope": 0}
        data = (self.native_get("/store/search", {"keyword": keyword, "count": 20, "maxIdx": cursor,
                                                  "type": 0, "scope": 0}) if self.has_native_login()
                else self.json(WEB + "/web/search/global?" + urlencode(params)))
        rows = data.get("books")
        if not isinstance(rows, list):
            raise ReaderError("微信读书未返回搜书结果。")
        books = [r["bookInfo"] for r in rows if (r.get("bookInfo") or {}).get("bookId")
                 and r["bookInfo"].get("title")]
        last = max((int(r.get("searchIdx") or 0) for r in rows), default=0)
        return books, last if data.get("hasMore") and last > cursor else None

    def add_to_shelf(self, book):
        result = self.json(WEB + "/web/shelf/add", body={"bookIds": [book]})
        if result.get("succ") != 1:
            raise ReaderError("微信读书未确认加入书架，请同步书架核对。")

    def chapter_underlines(self, book, uid, version):
        book, uid = str(book), str(uid)
        params = {"bookId": book, "chapterUid": uid, "synckey": 0}
        try:
            data = self.json(WEB + "/web/book/underlines?" + urlencode(params),
                             headers={"Referer": WEB + "/web/reader/" + reader_id(book) + "k" + reader_id(uid)})
        except AuthorizationRequired:
            raise
        except ReaderError:
            data = {}
        if str(data.get("bookId", book)) != book or str(data.get("chapterUid", uid)) != uid:
            raise ReaderError("微信读书未返回当前章节的划线。")
        rows = data.get("underlines")
        marks = [{"uid": uid, "range": row["range"], "quote": row.get("markText") or ""}
                 for row in (rows if isinstance(rows, list) else []) if isinstance(row, dict)
                 and re.fullmatch(r"[0-9]+-[0-9]+", str(row.get("range", "")))
                 and isinstance(row.get("markText") or "", str)
                 and str(row.get("chapterUid", uid)) == uid]
        if not marks:
            popular, _ = self.notes_page(book, "popular")
            marks = [mark for mark in popular if str(mark.get("uid")) == uid]
            if not isinstance(rows, list) and not marks:
                # A partial book-wide ranking cannot supersede a previously fetched chapter.
                raise ReaderError("微信读书未返回当前章节的划线。")
        self.store.put(self.account, "chapter-underlines", json.dumps([book, uid]),
                       {"version": version, "marks": marks})
        return marks

    def notes_page(self, book, section, offset=0, sync=0):
        if section in ("mine", "popular", "bookmarks"):
            if section != "popular":
                params = {"bookId": book, "syncKey": 0}
                data = self.json(WEB + "/web/book/bookmarklist?" + urlencode(params))
                if "updated" not in data and self.has_native_login():
                    data = self.native_get("/book/bookmarklist", params)
                marks = data.get("updated")
                identity = data.get("bookId", (data.get("book") or {}).get("bookId", book))
                if str(identity) != str(book) or not isinstance(marks, list):
                    raise ReaderError("微信读书未返回本书的个人标注。")
            else:
                params = {"bookId": book, "hasLogin": 1, "count": 500}
                data = self.json(WEB + "/web/book/bestbookmarks?" + urlencode(params))
                best = data.get("bestBookMarks")
                if (str(data.get("bookId", book)) != str(book) or not isinstance(best, dict)
                        or not isinstance(best.get("items"), list)):
                    raise ReaderError("微信读书未返回本书的热门划线。")
                marks = best["items"]
            items = [{"id": mark.get("bookmarkId") or (str(mark["chapterUid"]) + ":" + str(mark["range"])),
                      "mark_id": mark.get("bookmarkId"), "uid": mark.get("chapterUid"),
                      "quote": mark.get("markText", ""), "range": mark.get("range", ""),
                      "votes": mark.get("totalCount", 0)}
                     for mark in marks if isinstance(mark, dict) and mark.get("chapterUid") is not None
                     and mark.get("range") is not None and isinstance(mark.get("markText") or "", str)
                     and (section == "bookmarks") == (str(mark.get("type", 1)) == "0")
                     and (section == "bookmarks" or mark.get("markText"))]
            if section == "mine":
                self.store.put(self.account, "book-highlights", str(book), items)
            return items, None
        if section not in ("thoughts", "reviews"):
            raise ValueError("未知的笔记类别")
        params = {"bookId": book, "listType": 3, "listMode": 2, "count": 20,
                  "maxIdx": offset, "synckey": sync}
        if section == "thoughts":
            params.update(listType=11, mine=1, userVid=self.account)
        data = self.json(WEB + "/web/review/list?" + urlencode(params))
        rows = data["reviews"]
        items = []
        for row in rows:
            review = row["review"]
            items.append({"id": row["reviewId"], "quote": review.get("abstract", ""),
                          "content": review.get("content", ""), "author": (review.get("author") or {}).get("name", ""),
                          "uid": review.get("chapterUid"), "idx": review.get("chapterIdx"),
                          "chapter": review.get("chapterName", ""), "replies": row.get("commentsCount", 0)})
        end = offset + len(rows)
        more = rows and (data.get("hasMore") or end < (data.get("totalCount") or 0))
        return items, (end, data.get("synckey", 0)) if more else None

    def add_mark(self, book, row, version, span, quote, bookmark=False):
        if version is None or row.get("chapterIdx") is None:
            raise ReaderError("缺少章节版本信息，请联网重新打开本章。")
        body = {"bookId": book, "chapterIdx": int(row["chapterIdx"]), "chapterUid": int(row["chapterUid"]),
                "bookVersion": int(version), "type": 0 if bookmark else 1, "style": 0,
                "range": span, "markText": base64.b64encode(quote.encode("utf-8")).decode("ascii")}
        if not bookmark:
            body["colorStyle"] = 0
        data = self.json(WEB + "/web/book/addBookmark", body=body)
        if not data.get("bookmarkId"):
            raise ReaderError("未收到保存确认，请刷新列表查看。")
        return data["bookmarkId"]

    def remove_mark(self, mark_id):
        data = self.json(WEB + "/web/book/removeBookmark", body={"bookmarkId": mark_id})
        if data.get("succ") != 1:
            raise ReaderError("未收到删除确认，请刷新列表查看。")

    def review_detail(self, review_id):
        data = self.json(WEB + "/web/review/single?" + urlencode({"reviewId": review_id}))
        return data["review"]

    def review_replies(self, review_id, parent="", offset=0):
        params = {"reviewId": review_id, "commentId": parent, "maxIdx": offset,
                  "count": 100, "isExpandAll": int(bool(parent))}
        data = self.json(WEB + "/web/review/commentloadmore?" + urlencode(params))
        if str(data.get("reviewId")) != str(review_id):
            raise ReaderError("微信读书未返回这条书评的回复。")
        rows = data.get("comments", [])
        more = data.get("commentsHasMore")
        return rows, offset + len(rows) if rows and more else None

    def chapter(self, book, uid, offline_only=False):
        try:
            url, state = self.state(book, uid)
        except AuthorizationRequired:
            if offline_only:
                raise
            raise OfficialChapterRequired(WEB + "/web/reader/" + reader_id(book) + "k" + reader_id(uid)) from None
        current = state.get("currentChapter", {})
        if str(current.get("chapterUid")) != str(uid) or not state.get("psvts"):
            raise ReaderError("微信读书未打开所选章节。")
        info = state.get("bookInfo", {})
        owned = info.get("paid") == 1 or current.get("paid") == 1
        free = info.get("free") == 1
        permanent = owned or free
        card = state.get("memberCardSummary") or {}
        # WeRead labels 1/5 as complimentary for members, 2/4 for paid members.
        # 3 (paid chapters) and 6 (separate purchase) confer no card entitlement.
        status = info.get("payingStatus")
        member = bool(self.account and card.get("expired") == 0 and not info.get("soldout")
                      and (status in (1, 5) or (status in (2, 4) and card.get("isPaying") == 1)))
        idx = current.get("chapterIdx")
        public_range = isinstance(idx, int) and 0 < idx <= (info.get("maxFreeChapter") or 0)
        cache_key = json.dumps([book, str(uid)])
        if not (permanent or public_range):
            self.store.discard_chapter(self.account, cache_key)
            if offline_only:
                return None
        # A bulk download may store only the public excerpt, even for a member.
        mode = int(permanent or (member and not offline_only))
        def shard(name):
            now = int(time.time())
            fields = dict(b=reader_id(book), c=reader_id(uid), r=secrets.randbelow(10000)**2,
                          ct=now, ps=state["psvts"], pc=reader_id(now), sc=mode,
                          prevChapter=False, st=0)
            fields["s"] = checksum({**fields, "prevChapter": "false"})
            try:
                return self.request(WEB + "/web/book/chapter/" + name, fields, {"Referer": url}).strip()
            except AuthorizationRequired:
                if offline_only:
                    raise
                raise OfficialChapterRequired(url) from None

        fmt = "text" if info.get("format") == "txt" else "html"
        names = ("t_0", "t_1") if fmt == "text" else ("e_0", "e_1", "e_3")
        parts = [shard(name) for name in names]
        if member and not permanent and mode and public_range and all(p == "{}" for p in parts):
            # Preserve the public excerpt if the member edition needs the official reader.
            mode = 0
            parts = [shard(name) for name in names]
        if not offline_only and not permanent and (not any(parts) or any(p.startswith("{") for p in parts)):
            raise OfficialChapterRequired(url)
        content = decode_parts(parts)
        if not content.strip():
            raise ReaderError("此章没有可显示的内容。")
        result = {"content": content, "format": fmt, "preview": not mode, "version": info.get("version")}
        if member and mode and not permanent:
            result["onlineOnly"] = True
        if member and not mode:
            result["officialChapter"] = url
        # The web directory explicitly marks a public preview range. Keep exactly
        # the bytes returned in that range, including any shortened text.
        if permanent or (public_range and not mode):
            self.store.put(self.account, "chapter", cache_key, result)
        return result

    def pictures(self, book, uid, urls, online_only=False):
        ref = WEB + "/web/reader/" + reader_id(book) + "k" + reader_id(uid)
        cache_key = json.dumps([book, str(uid)])
        cache = self.store.get(self.account, "illustrations", cache_key, {})
        images = {url: base64.b64decode(cache[url]) for url in urls if url in cache}
        opener = build_opener(HTTPCookieProcessor(self.cookies))
        for url in dict.fromkeys(urls):
            parsed = urlsplit(url)
            if url in images or parsed.scheme != "https" or parsed.hostname != "res.weread.qq.com":
                continue
            try:
                with opener.open(Request(url, headers={"Referer": ref}), timeout=8) as response:
                    if response.headers.get_content_type().startswith("image/"):
                        images[url] = response.read()
            except (OSError, URLError):
                continue
        missing = set(urls) - images.keys()
        if missing and not online_only:
            try:
                images.update(self.archive_pictures(book, uid, missing, ref, opener))
            except (ReaderError, OSError, URLError, tarfile.TarError):
                pass
        if images and not online_only and self.store.get(self.account, "chapter", cache_key) is not None:
            self.store.put(self.account, "illustrations", cache_key,
                           {url: base64.b64encode(data).decode() for url, data in images.items()})
        return images

    def archive_pictures(self, book, uid, urls, ref, opener):
        catalog = self.json(WEB + "/web/book/chapterInfos", body={"bookIds": [book]},
                            headers={"Referer": ref})
        rows = catalog.get("data", [catalog])
        if isinstance(rows, dict):
            rows = [rows]
        entries = (ch for row in rows if str(row.get("bookId")) == book
                   for ch in row.get("updated", []) if str(ch.get("chapterUid")) == str(uid))
        url = next((c.get("tar", "") for c in entries), "")
        if urlsplit(url).scheme != "https" or urlsplit(url).hostname != "res.weread.qq.com":
            return {}
        with opener.open(Request(url, headers={"Referer": ref}), timeout=18) as response:
            blob = response.read()
        wanted = {Path(urlsplit(src).path).name: src for src in urls}
        images = {}
        with tarfile.open(fileobj=io.BytesIO(blob), mode="r:*") as archive:
            for item in archive:
                name = Path(item.name).name
                if item.isfile() and name in wanted:
                    images[wanted[name]] = archive.extractfile(item).read()
        return images


def cover_bytes(url):
    parsed = urlsplit(url)
    if parsed.scheme == "http":
        url = parsed._replace(scheme="https").geturl()
    elif parsed.scheme != "https":
        return None
    with urlopen(url, timeout=5) as response:
        return response.read(3_000_000)


def decode_parts(parts):
    pieces = []
    for part in parts:
        if part.startswith("{"):
            raise ReaderError("微信读书未提供这一章的正文，请检查阅读权限。")
        if not part:
            continue
        data = part[32:]
        if hashlib.md5(data.encode()).hexdigest() != part[:32].lower():
            raise ReaderError("章节未完整返回，请重试。")
        pieces.append(data)
    chars = list("".join(pieces)[1:])
    n = len(chars)
    moves = []
    if n >= 11:
        tail = min(4, (n + 9) // 10)
        digits = "".join(str(int(format(ord(c), "b"), 4)) for c in chars[-tail:][::-1])
        bound = n - tail - 2
        width = len(str(bound))
        for pos in range(0, min(len(digits) - width, 5 * width), width):
            moves.append(tuple(int(digits[i:i + width]) % bound for i in (pos, pos + 1)))
    elif n >= 4:
        moves.append((0, 2))
    for a, b in reversed(moves):
        for offset in (1, 0):
            left, right = a + offset, b + offset
            chars[left], chars[right] = chars[right], chars[left]
    encoded = "".join(chars).rstrip("=")
    return base64.b64decode(encoded + "=" * (-len(encoded) % 4),
                            altchars=b"-_", validate=True).decode("utf-8")
