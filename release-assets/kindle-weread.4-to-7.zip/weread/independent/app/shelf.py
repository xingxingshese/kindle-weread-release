"""Shelf browsing, selection and resumable offline chapter downloads."""
import io
import json
import tkinter as tk
from functools import lru_cache

from PIL import Image, ImageOps

from app import FONT, SCALE, blocks, photo
from client import cover_bytes


@lru_cache(maxsize=48)
def cover_thumbnail(url, width, height):
    data = cover_bytes(url)
    if data:
        with Image.open(io.BytesIO(data)) as source:
            return ImageOps.contain(source, (width, height)).convert("L")


class ShelfGrid:
    rows = 2
    choices = (3, 4, 5, 6)

    def __init__(self, app):
        self.app = app
        self.load_columns()
        self.account = None
        self.archive = None
        self.parent_view = ("", 0)

    def load_archives(self):
        app = self.app
        if self.account != app.client.account:
            self.account = app.client.account
            self.archive = None
            self.parent_view = ("", 0)
        groups = app.store.get(self.account, "shelf-archives", default=[])
        self.archives = {str(g["archiveId"]): g for g in groups if isinstance(g, dict)
                         and g.get("archiveId") and isinstance(g.get("bookIds"), list)}
        if self.archive is not None and self.archive not in self.archives:
            self.archive = None
            self.selected.clear()
            app.query, app.shelf_page = self.parent_view

    def open_archive(self, archive):
        app = self.app
        self.parent_view = (app.query, app.shelf_page)
        self.archive = archive
        app.query, app.shelf_page = "", 0
        app.show_shelf()

    def leave_archive(self):
        self.archive = None
        self.app.query, self.app.shelf_page = self.parent_view
        self.app.show_shelf()

    def controls(self):
        self.selecting = False
        self.selected = set()
        self.pending = self.app.store.get(self.account, "shelf-download", default=[])

    def more(self):
        from discovery import BookSearch
        page = self.page
        app = self.app
        menu = tk.Frame(page.frame, bg="white", highlightthickness=2, highlightbackground="#222222")
        self.entry.configure(text="收起")
        def close(action=None):
            menu.grab_release()
            menu.destroy()
            self.entry.configure(text="更多")
            self.entry.focus_set()
            if action:
                action()
            return "break"
        entries = [("全站搜书", lambda: BookSearch(app, app.show_shelf)), ("多选", self.toggle_mode),
                   ("书架布局", self.choose_layout), ("导入书籍", self.import_books),
                   ("扫码登录", lambda: app.login(back=app.show_shelf))]
        if self.pending:
            entries.append(("继续上次下载", lambda: self.start_download(resume=True)))
        page.put(menu,590,217,434,len(entries)*100)
        for i,(name,action) in enumerate(entries):
            row = tk.Frame(menu,bg="white")
            row.place(relx=.07, rely=i/len(entries), relwidth=.86, relheight=1/len(entries))
            button = app.button(row,name,lambda f=action: close(f))
            button.configure(font=page.font(32),anchor="w",padx=0)
            button.place(relwidth=1,relheight=1)
            arrow=tk.Label(row,text="›",font=page.font(28),bg="white")
            arrow.place(relx=1,rely=.5,anchor="e")
            arrow.bind("<ButtonRelease-1>",lambda _,f=action:close(f))
            if i:
                tk.Frame(row,bg="#bbbbbb",height=2).place(relwidth=1)
            button.bind("<Escape>",lambda _:close())
        menu.lift()
        menu.grab_set()
        menu.focus_set()
        menu.bind("<Escape>", lambda _: close())
        def outside(event):
            if not (0 <= event.x < menu.winfo_width() and 0 <= event.y < menu.winfo_height()):
                return close()
        menu.bind("<ButtonRelease-1>", outside)

    def load_columns(self):
        saved = self.app.store.get("", "shelf-columns", default=4)
        self.columns = saved if saved in self.choices else 4

    def choose_layout(self):
        app = self.app
        app.clear()
        from pw3_page import Page
        page = Page(app)
        page.title("书架布局")
        for i,count in enumerate(self.choices):
            y=300+215*i
            action=lambda n=count:self.resize(n)
            for j in range(count):
                pitch=262/count
                width=min(42,pitch-8)
                cover=page.put(tk.Frame(page.frame,bg="#eeeeee",relief="solid",bd=1),
                               54+j*pitch,y+20,width,width*1.42)
                cover.bind("<ButtonRelease-1>",lambda _,f=action:f())
            page.button(f"每行 {count} 本",action,352,y,450,108,36,anchor="w")
            page.button("已选" if count==self.columns else "选择",action,802,y,222,108,28,anchor="e")
            page.line(48,y+108,976,"#dddddd")
        page.footer([("‹ 返回",app.show_shelf)])

    def import_books(self):
        app = self.app
        app.clear()
        from pw3_page import Page
        page=Page(app)
        page.title("导入书籍")
        page.footer([("‹ 返回",app.show_shelf)])
        for i,(title,one,two) in enumerate([
                ("从手机导入","打开微信读书 App，进入「书架 → 导入」。","使用相同账号选择文件并上传。"),
                ("从电脑导入","在电脑浏览器打开 r.qq.com，","选择「传书到手机」，用相同账号上传。")]):
            y=294+i*360
            page.label(title,48,y,976,86,36,True)
            page.label(one,48,y+95,976,78)
            page.label(two,48,y+151,976,78)
        page.line(48,592,976,"#dddddd")
        if not app.kindle:
            import webbrowser
            page.button("打开微信读书传书页",lambda:webbrowser.open("https://weread.qq.com/web/upload"),
                        48,942,550,88,outline=True)
        def sync():
            self.archive = None
            app.query, app.shelf_page = "", 0
            app.show_shelf(sync=True)
        page.button("导入完成，刷新书架",sync,48,1144,976,88,primary=True)

    def resize(self, count):
        app = self.app
        app.shelf_page = app.shelf_page * self.columns // count
        self.columns = count
        app.store.put("", "shelf-columns", "", count)
        app.show_shelf()

    def toggle_mode(self):
        self.selecting = not self.selecting
        self.selected.clear()
        self.render()

    def toggle_all(self):
        if self.visible_ids <= self.selected:
            self.selected.difference_update(self.visible_ids)
        else:
            self.selected.update(self.visible_ids)
        self.render()

    @staticmethod
    def member_ids(entry):
        return entry["members"] if "members" in entry else {str(entry["bookId"])}

    def entries(self):
        app = self.app
        by_id = {str(b["bookId"]): b for b in app.books}
        term = app.query.casefold()
        if self.archive is not None:
            members = {str(k) for k in self.archives[self.archive]["bookIds"]}
            rows = [book for key, book in by_id.items() if key in members]
        else:
            rows, owners = [], {}
            for key, archive in self.archives.items():
                members = {str(k) for k in archive["bookIds"] if str(k) in by_id}
                group = {"archive": key, "title": archive.get("name") or "未命名分组",
                         "members": members, "author": f"{len(members)} 本书"}
                rows.append(group)
                for book in members:
                    owners[book] = key
            rows.extend(book for key, book in by_id.items() if term or key not in owners)
            if rows and self.archives:
                order = {key: i for i, key in enumerate(by_id)}
                rows.sort(key=lambda b: min((order[k] for k in self.member_ids(b)), default=len(order)))
        return [entry for entry in rows if term in
                (entry["title"] + (entry.get("author") or "")).casefold()]

    def render(self):
        from pw3_page import Page
        from discovery import Discover
        from book_details import ordinary
        app = self.app
        old = getattr(self,"page",None)
        if old and old.frame.winfo_exists():
            old.frame.destroy()
        page = self.page = Page(app)
        entries = self.entries()
        self.visible_ids = {key for entry in entries for key in self.member_ids(entry)}
        self.selected.intersection_update(str(b["bookId"]) for b in app.books)
        archive = self.archives.get(self.archive,{})
        if archive:
            self.selected.intersection_update(map(str,archive["bookIds"]))
        count = len(self.selected)
        page.title(f"多选 · 已选 {count} 项" if self.selecting else archive.get("name") or "书架")
        if not self.selecting:
            if not archive:
                page.button("同步",lambda:app.show_shelf(True),790,118,112,88)
            self.entry=page.button("多选" if archive else "更多",self.toggle_mode if archive else self.more,
                                   912,118,112,88)
        # Preserve the entry while typing. Only the grid is replaced on filter changes.
        page.search(app.search,"搜索本组" if archive else "搜索书架")
        if self.selecting:
            names = [("取消全选" if self.visible_ids and self.visible_ids<=self.selected else "全选",self.toggle_all),
                     ("详情",self.selected_details),("下载",self.start_download)]
            for i,(name,action) in enumerate(names):
                button=page.button(name,action,48+330*i,370,314,88,outline=True)
                if (i==1 and (count!=1 or not ordinary(next(iter(self.selected))))) or (i==2 and not count):
                    button.configure(state="disabled")
        if self.selecting or archive:
            page.footer([("‹ 返回",self.toggle_mode if self.selecting else self.leave_archive)])
        else:
            page.footer([("发现",lambda:Discover(app)),("书架",app.show_shelf),("我的",app.profile)],"书架")
        self.status_label=page.label("",48,1196,976,48,26,color="#555555")
        self.status_label.configure(textvariable=app.status)
        self.tiles=[]
        self.redraw_tiles()

    def redraw_tiles(self):
        page, app = self.page, self.app
        for tile in self.tiles:
            tile.destroy()
        self.tiles.clear()
        books=self.entries()
        self.visible_ids={key for entry in books for key in self.member_ids(entry)}
        per_page=self.rows*self.columns
        pages=max(1,(len(books)+per_page-1)//per_page)
        app.shelf_page=max(0,min(app.shelf_page,pages-1))
        def turn(delta):
            app.shelf_page=max(0,min(app.shelf_page+delta,pages-1))
            self.redraw_tiles()
        def track(widget):
            self.tiles.append(widget)
            return widget
        track(page.label(f"第 {app.shelf_page+1} / {pages} 页",380,1246,312,88,26,anchor="center"))
        if pages>1:
            for delta,title,x in [(-1,"‹ 上一页",220),(1,"下一页 ›",652)]:
                btn=track(page.button(title,lambda d=delta:turn(d),x,1246,200,88,26))
                if not 0<=app.shelf_page+delta<pages:
                    btn.configure(state="disabled")
        if not books:
            track(page.label("没有匹配的书" if app.query else "暂无书籍",48,424,976,80,32,anchor="center"))
        start=app.shelf_page*per_page
        for i,book in enumerate(books[start:start+per_page]):
            pitch=996/self.columns
            cx=48+pitch*(i%self.columns+.5)
            y=(490 if self.selecting else 415 if self.archive else 394)+(i//self.columns)*376
            w=min(176,round(pitch*.76))
            h=round(w*304/215)
            jacket=track(page.put(tk.Frame(page.frame,bg="#eeeeee",bd=1,relief="solid"),cx-w/2,y,w,h))
            cover=tk.Label(jacket,text=book["title"][:10],font=page.font(26,True),bg="#eeeeee",
                           fg="#222222",wraplength=round((w-22)*page.factor))
            cover.place(relwidth=1,relheight=1)
            artwork=[]
            if "archive" in book or str(book.get("bookId","")).startswith("MP_"):
                canvas=tk.Canvas(jacket,bg="#eeeeee",bd=0,highlightthickness=0)
                canvas.place(relwidth=1,relheight=1)
                scale=w*page.factor/215
                def rect(x,y,r,b,fill,stroke=""):
                    canvas.create_rectangle(x*scale,y*scale,r*scale,b*scale,fill=fill,outline=stroke)
                rect(0,0,7,304,"#777777")
                if "archive" in book:
                    for x,top in ((37,72),(83,88),(129,72)):
                        rect(x,top,x+34,222,"white","#555555")
                    canvas.create_text(107*scale,258*scale,text="分组",font=page.font(22))
                else:
                    rect(27,43,188,53,"#333333")
                    canvas.create_text(27*scale,91*scale,anchor="nw",text=book["title"][:9],
                                       width=161*scale,font=page.font(max(20,round(37*w/215)),True))
                    canvas.create_text(27*scale,250*scale,text="公众号",anchor="w",font=page.font(20))
                artwork.append(canvas)
            title=track(page.label(page.shorten(book["title"],pitch-14,32),cx-pitch/2,y+h+8,pitch,48,32,anchor="center"))
            author=track(page.label(page.shorten("分组" if "archive" in book else book.get("author") or "",pitch-12,26),
                                    cx-pitch/2,y+h+56,pitch,38,26,anchor="center",color="#555555"))
            widgets=[cover,title,author,*artwork]
            if self.selecting:
                members=self.member_ids(book)
                selected=members & self.selected
                mark=tk.Label(jacket,text="✓" if selected==members and members else "–" if selected else "",
                              font=page.font(30,True),bg="#222222" if selected else "white",
                              fg="white",bd=1,relief="solid")
                mark.place(relx=1,anchor="ne",width=46*page.factor,height=46*page.factor)
                widgets.append(mark)
            def release(event,item=book):
                dy=event.y_root-getattr(self,"start_y",event.y_root)
                if abs(dy)>=70*page.factor:
                    turn(-1 if dy>0 else 1)
                elif self.selecting:
                    members=self.member_ids(item)
                    if members<=self.selected:
                        self.selected.difference_update(members)
                    else:
                        self.selected.update(members)
                    self.render()
                elif "archive" in item:
                    self.open_archive(item["archive"])
                else:
                    app.open_book(item)
            for widget in widgets:
                widget.bind("<ButtonPress-1>",lambda e:setattr(self,"start_y",e.y_root))
                widget.bind("<ButtonRelease-1>",release)
                widget.bind("<Button-4>",lambda _:turn(-1))
                widget.bind("<Button-5>",lambda _:turn(1))
            if book.get("cover") and not artwork:
                def loaded(image,target=cover):
                    if image is not None and target.winfo_exists():
                        target.image=photo(image)
                        target.configure(image=target.image,text="")
                app.submit(lambda url=book["cover"],width=w,height=h:cover_thumbnail(url,width,height),
                           loaded,lambda _:None,media=True)

    def start_download(self, resume=False):
        app = self.app
        if app.store.get(app.client.account, "safe-mode", default=False):
            app.status.set("安全模式已开启，请在「我的 → 设置」关闭后下载书籍。")
            return
        books = self.pending if resume else [b for b in app.books if str(b["bookId"]) in self.selected]
        if books:
            ShelfDownload(app, books, resume=resume)

    def selected_details(self):
        from discovery import book_detail
        selected = self.selected.copy()
        book = next(b for b in self.app.books if str(b["bookId"]) in selected)
        def back():
            self.app.show_shelf()
            self.toggle_mode()
            self.selected.update(selected)
            self.render()
        book_detail(self.app, book, back, {str(b["bookId"]) for b in self.app.books})


class ShelfDownload:
    def __init__(self, app, books, resume=False):
        self.app, self.books = app, books
        self.client = app.client
        self.index = 0
        self.rows = None
        self.saved = self.previews = self.skipped = self.missing_images = 0
        app.clear()
        from pw3_page import Page
        self.page=page=Page(app)
        self.title_label=page.title("下载已暂停" if resume else "下载前")
        page.footer([("‹ 返回",app.show_shelf)])
        self.heading=page.label("下载已暂停" if resume else f"已选 {len(books)} 本书",48,292,976,80,36,True)
        app.status=tk.StringVar(value="已保存的章节可离线阅读。" if resume else "准备下载可离线阅读的章节和插图。")
        page.label("",48,384,976,86,32).configure(textvariable=app.status)
        self.track=page.line(48,483,976,"#dddddd",8)
        self.fill=page.line(48,483,1,"#222222",8)
        self.fill.place_forget()
        label="继续下载" if resume else ("替换上次任务并下载" if app.shelf_grid.pending else "开始下载")
        if resume:
            self.action=page.button(label,self.begin,550,1357,474,90,32,anchor="e")
        else:
            self.action=page.button(label,self.begin,48,1121,976,86,primary=True)
        self.stop=page.button("结束任务，保留已下载章节",self.stop_download,48,1120,976,88,outline=True)
        if not resume:
            self.stop.place_forget()
        self.results={}
        self.report_start=0
        self.report_widgets=[]
        self.draw_report()

    def draw_report(self):
        page=self.page
        for widget in self.report_widgets:
            widget.destroy()
        self.report_widgets=[]
        for i,book in enumerate(self.books[self.report_start:self.report_start+2]):
            n=self.report_start+i
            y=560+204*i
            cover=page.label(book["title"][:4],48,y,110,152,22,True,"center")
            cover.configure(wraplength=round(94*page.factor),bg="#eeeeee",bd=1,relief="solid")
            if book.get("cover"):
                def loaded(image,target=cover):
                    if image is not None and target.winfo_exists():
                        target.image=photo(image)
                        target.configure(image=target.image,text="")
                self.app.submit(lambda url=book["cover"]:cover_thumbnail(url,110,152),loaded,lambda _:None,media=True)
            self.report_widgets.extend((cover,page.label(page.shorten(book["title"],515,36),181,y+20,515,72,36),
                                        page.label(book.get("author") or "",181,y+92,515,58,26,color="#555555"),
                                        page.label(self.results.get(n,""),690,y+20,334,128,26,anchor="e"),
                                        page.line(48,y+184,976,"#dddddd")))
            self.report_widgets[-2].configure(wraplength=round(320*page.factor),justify="right")
        def turn(delta):
            self.report_start+=delta
            self.draw_report()
        if self.report_start:
            self.report_widgets.append(page.button("上一页",lambda:turn(-2),48,1008,200,88))
        if self.report_start+2<len(self.books):
            self.report_widgets.append(page.button("下一页",lambda:turn(2),824,1008,200,88))

    def begin(self):
        self.title_label.configure(text="下载到本机")
        self.page.put(self.action,550,1357,474,90)
        self.action.configure(text="暂停下载", command=self.pause,
                              bg="white", fg="#222222", highlightthickness=0, font=self.page.font(32))
        self.page.put(self.stop,48,1120,976,88)
        if self.rows is None:
            self.next_book()
        else:
            self.next_chapter()

    def pause(self):
        # Let an in-flight request finish caching. Dropping its page callback
        # prevents the next chapter from starting after navigation or pause.
        self.app.generation += 1
        self.title_label.configure(text="下载已暂停")
        self.heading.configure(text="下载已暂停")
        self.app.status.set("已保存的章节可离线阅读。")
        self.action.configure(text="继续下载", command=self.begin)

    def stop_download(self):
        self.client.store.put(self.client.account, "shelf-download", "", [])
        self.app.show_shelf()

    def next_book(self):
        while self.index < len(self.books) and str(self.books[self.index]["bookId"]).startswith("MP_"):
            self.results[self.index]="请到公众号文章列表阅读"
            self.index += 1
        self.remember()
        if self.index == len(self.books):
            self.action.place_forget()
            self.stop.place_forget()
            self.heading.configure(text="下载结束")
            self.draw_report()
            self.app.status.set("逐本结果见下方。")
            return
        self.book = self.books[self.index]
        self.heading.configure(text="正在下载 · "+self.book["title"])
        self.report_start=self.index//2*2
        self.fill.place_forget()
        self.draw_report()
        self.key = str(self.book["bookId"])
        self.saved = self.previews = self.skipped = self.missing_images = 0
        self.app.status.set(f"{self.index+1}/{len(self.books)} · {self.book['title']} · 正在读取目录…")
        self.app.submit(lambda: self.client.catalog(self.key), self.got_catalog, self.failed)

    def remember(self):
        remaining = [{"bookId": b["bookId"], "title": b["title"]} for b in self.books[self.index:]]
        self.client.store.put(self.client.account, "shelf-download", "", remaining)

    def got_catalog(self, rows):
        self.rows = rows
        self.chapter_index = 0
        self.next_chapter()

    def next_chapter(self):
        self.heading.configure(text="正在下载 · "+self.book["title"])
        if self.rows:
            width=round(976*self.chapter_index/len(self.rows))
            if width:
                self.page.put(self.fill,48,483,width,8)
            self.results[self.index]=f"{self.chapter_index} / {len(self.rows)} 章"
            if self.report_start<=self.index<self.report_start+2:
                self.report_widgets[3+5*(self.index-self.report_start)].configure(text=self.results[self.index])
        if self.chapter_index >= len(self.rows):
            summary = f"{self.saved} 章已保存"
            if self.previews:
                summary += f"（其中 {self.previews} 章为试读）"
            if self.skipped:
                summary += f"，{self.skipped} 章不可离线"
            if self.missing_images:
                summary += f"，{self.missing_images} 张插图未下载"
            self.finish_book(summary)
            return
        row = self.rows[self.chapter_index]
        self.app.status.set(f"{self.index+1}/{len(self.books)} · {self.book['title']}\n"
                            f"第 {self.chapter_index+1}/{len(self.rows)} 章 · {row.get('title', '')}")
        self.app.submit(lambda: self.cache_chapter(self.key, str(row["chapterUid"])),
                        self.chapter_done, self.failed)

    def cache_chapter(self, key, uid):
        client = self.client
        result = client.store.get(client.account, "chapter", json.dumps([key, uid]))
        if result is None:
            result = client.chapter(key, uid, offline_only=True)
        if result is None:
            return None, 0
        urls = {b[1] for b in blocks(result) if b[0] == "picture"}
        missing = len(urls - client.pictures(key, uid, urls).keys()) if urls else 0
        return result["preview"], missing

    def chapter_done(self, result):
        preview, missing = result
        if preview is None:
            self.skipped += 1
        else:
            self.saved += 1
            self.previews += int(preview)
            self.missing_images += missing
        self.chapter_index += 1
        self.next_chapter()

    def failed(self, exc):
        self.app.error(exc)
        self.results[self.index]=self.app.status.get()
        self.draw_report()
        self.pause()

    def finish_book(self, message):
        self.results[self.index]=message
        self.index += 1
        self.rows = None
        self.next_book()
