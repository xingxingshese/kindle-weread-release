"""Read statistics for the signed-in reader on desktop and Kindle."""
import json
import os
import re
import time
import tkinter as tk
from decimal import Decimal
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlencode
from urllib.request import Request, build_opener

from client import AuthorizationRequired, NoRedirect, ReaderError, WEB


STATS_HOST = "https://i.weread.qq.com"


PERIODS = (("weekly", "本周"), ("monthly", "本月"), ("annually", "本年"), ("overall", "累计"))


def native_stats(account, directory, active):
    if not active():
        raise ReaderError("账号或页面已变更。")
    if not directory:
        raise ReaderError("本机尚无原版登录记录。")
    try:
        with (directory / "session.json").open("rb") as source:
            raw = source.read(65537)
        session = json.loads(raw) if len(raw) <= 65536 else {}
    except (OSError, ValueError):
        raise ReaderError("无法读取本机原版登录记录。") from None
    if (not isinstance(session, dict) or not account or not account.isascii() or not account.isdigit()
            or str(session.get("vid")) != account or str(session.get("nativeVid")) != account):
        raise ReaderError("未找到与当前书架账号一致的原版登录。")
    token = session.get("nativeAccess")
    if not isinstance(token, str) or not re.fullmatch(r"[!-~]+", token):
        raise ReaderError("原版尚无有效的原生登录，请在原版重新登录。")
    return native_token_stats(account, token, active)


def native_token_stats(account, token, active):
    opener = build_opener(NoRedirect())
    def get(path, params):
        if not active():
            raise ReaderError("账号或页面已变更。")
        request = Request(STATS_HOST + path + "?" + urlencode(params),
                          headers={"vid": account, "accessToken": token, "Accept": "application/json"})
        try:
            with opener.open(request, timeout=12) as response:
                data = json.load(response)
        except HTTPError as error:
            if error.code in (401, 403):
                raise AuthorizationRequired("微信读书未授权原版统计请求，请在原版重新登录。") from None
            raise ReaderError(f"微信读书统计请求失败（HTTP {error.code}）。") from None
        code = str(data.get("errCode", data.get("errcode", 0))) if isinstance(data, dict) else ""
        if code in ("-2010", "-2012", "-2013"):
            raise AuthorizationRequired("原版登录已失效，请在原版重新登录。")
        if code != "0":
            raise ReaderError("微信读书未确认原版统计请求。")
        return data
    return detail_and_profile(get, account, active, native=True)


def detail_and_profile(get, account, active, *, native):
    try:
        _, times = period_totals(get, {}, account, active)
    except AuthorizationRequired:
        raise
    except (ReaderError, URLError, TimeoutError, ValueError) as error:
        times, detail_error = {}, error
    else:
        detail_error = None
    if "本周" in times and "累计" in times:
        return account, times
    if not active():
        raise ReaderError("账号或页面已变更。")
    params = {"currentReadingTime": 1, "totalReadingTime": 1}
    params.update({"userVid": account} if native else {"platform": "wp"})
    try:
        profile = get("/user/profile", params)
    except AuthorizationRequired:
        raise
    except (ReaderError, URLError, TimeoutError, ValueError):
        if times:
            return account, times
        if detail_error:
            raise detail_error
        raise
    summary, name = profile_times(profile, account, require_identity=not native, web_profile_hours=not native)
    summary.update(times)
    if not summary and detail_error:
        raise detail_error
    return name, summary


def profile_times(profile, account, *, require_identity=False, web_profile_hours=False):
    rows = [profile] + [profile[k] for k in ("user", "userInfo") if isinstance(profile.get(k), dict)]
    ids = [str(row[k]) for row in rows for k in ("userVid", "vid") if k in row]
    if any(value != account for value in ids) or (require_identity and not ids):
        raise AuthorizationRequired("微信读书返回的身份与当前书架不一致，请重新登录。")
    name = next((row[k] for row in rows for k in ("name", "nick")
                 if isinstance(row.get(k), str) and row[k]), account)
    times = {}
    for row in rows:
        for field, label in (("currentReadingTime", "本周"), ("totalReadingTime", "累计")):
            # Some profile responses carry formatted durations. Unlike
            # readdata/detail, bare profile numbers have no documented unit.
            value = row.get(field)
            if web_profile_hours and re.fullmatch(r"[0-9]{1,9}(?:\.[0-9]{1,9})?", str(value)):
                # /user/profile?platform=wp supplies these summaries in hours.
                # The per-period endpoint below takes precedence, in seconds.
                times[label] = round(Decimal(str(value)) * 3600)
                continue
            if isinstance(value, str):
                match = re.fullmatch(r"\s*(?:(\d+)\s*(?:小时|时))?\s*(?:(\d+)\s*(?:分钟|分))?\s*(?:(\d+)\s*秒)?\s*", value)
                if match and any(match.groups()):
                    hours, minutes, seconds = (int(x or 0) for x in match.groups())
                    times[label] = hours * 3600 + minutes * 60 + seconds
    return times, name


def period_totals(get, times, name, active):
    last_error = None
    for mode, label in PERIODS:
        if not active():
            raise ReaderError("账号或页面已变更。")
        try:
            data = get("/readdata/detail", {"mode": mode, "baseTime": 0})
        except AuthorizationRequired:
            raise
        except (ReaderError, URLError, TimeoutError, ValueError) as error:
            last_error = error
            continue
        total = data.get("totalReadTime")
        if total is None and mode in ("weekly", "monthly"):
            # A detail response can contain only some of the day's buckets.
            # Sum them only if every elapsed day in the period is accounted for.
            start, daily = data.get("baseTime"), data.get("readTimes")
            now = int(time.time())
            limit = 7 if mode == "weekly" else 31
            if type(start) is int and 0 <= now - start < limit * 86400 and isinstance(daily, dict):
                values = [daily.get(str(day)) for day in range(start, now + 1, 86400)]
                if all(type(v) is int and v >= 0 for v in values):
                    total = sum(values)
        if type(total) is int and total >= 0:
            times[label] = total
        if "今日" not in times:
            today_seconds(data, times, mode)
    if not active():
        raise ReaderError("账号或页面已变更。")
    if not times and last_error:
        raise last_error
    if not times:
        raise ReaderError("微信读书未返回可显示的时长。")
    return name, times


def today_seconds(data, times, mode="weekly"):
    daily = data.get("dailyReadTimes")
    if not isinstance(daily, dict) and mode in ("weekly", "monthly"):
        daily = data.get("readTimes")
    if not isinstance(daily, dict):
        return
    # Each timestamp is the start of the service's day. A Kindle can be set to
    # a different time zone. An absent bucket does not establish zero seconds.
    now = int(time.time())
    for key, value in daily.items():
        if isinstance(key, str) and re.fullmatch(r"[0-9]{1,11}", key) and 0 <= now - int(key) < 86400:
            if type(value) is int and value >= 0:
                times["今日"] = value
                return


def web_stats(client, account, active):
    def check():
        if not account or client.account != account or not active():
            raise ReaderError("账号或页面已变更，请重新登录。")
    check()
    # A scoped cookie pair already identifies the current reader at the API.
    # An unavailable web profile must not prevent requesting reading detail.
    def get(path, params):
        check()
        if not client.stats_cookie_available():
            raise AuthorizationRequired("当前登录未授权读取时长明细。")
        return client.json(STATS_HOST + path + "?" + urlencode(params), headers={"Referer": WEB + "/"}, timeout=12)

    if client.stats_cookie_available():
        return detail_and_profile(get, account, active, native=False)

    # A host-only web login can still supply summaries on its own origin.
    profile = client.json(WEB + "/api/userInfo", headers={"Referer": WEB + "/"})
    times, name = profile_times(profile, account, require_identity=True)
    check()
    params = {"userVid": account, "currentReadingTime": 1, "totalReadingTime": 1}
    try:
        profile = client.json(WEB + "/api/userInfo?" + urlencode(params), headers={"Referer": WEB + "/"})
    except AuthorizationRequired:
        raise
    except (ReaderError, URLError, TimeoutError, ValueError):
        if not times:
            raise
    else:
        found, name = profile_times(profile, account, require_identity=True)
        times.update(found)
    check()
    if client.stats_cookie_available():
        try:
            _, detail = detail_and_profile(get, account, active, native=False)
        except (ReaderError, URLError, TimeoutError, ValueError):
            if not times:
                raise
        else:
            times.update(detail)
    return name, times


def account_stats(client, store, kindle, account, active):
    from legacy_paths import legacy_directories

    def original():
        paths = legacy_directories(store, kindle)
        if paths and (paths[0] / "session.json").is_file():
            return native_stats(account, paths[0], active)
        return account, {}

    def signed_in():
        return web_stats(client, account, active)

    if (store.get("", "native-session-owner") == account
            and client.account == account and account):
        return native_token_stats(account, unquote(client.session()["wr_skey"]), active)
    sources = [original]
    if os.name == "nt" and not kindle:
        import omni_stats
        sources.append(lambda: omni_stats.read(store, account, active))
    sources.append(signed_in)
    name, totals, error = account, {}, None
    for read in sources:
        if not active():
            raise ReaderError("账号或页面已变更。")
        try:
            source_name, periods = read()
        except (ReaderError, URLError, TimeoutError, ValueError, OSError) as exc:
            if error is None:
                error = exc
            continue
        if source_name and name == account:
            name = source_name
        for label, seconds in periods.items():
            totals.setdefault(label, seconds)
        if all(label in totals for label in ("今日", "本周", "本月", "本年", "累计")):
            break
    if not active():
        raise ReaderError("账号或页面已变更。")
    if not totals and error:
        raise error
    return name, totals


def minute_duration(seconds):
    hours, minutes = divmod(seconds // 60, 60)
    return f"{hours} 小时 {minutes} 分钟" if hours else f"{minutes} 分钟"


def show_stats(app, back=None, period="本周"):
    from activity import duration
    from client import AuthorizationRequired
    from pw3_page import Page
    app.clear()
    client,account,generation=app.client,app.client.account,app.generation
    def active():
        return app.generation==generation and app.client is client and client.account==account
    def reopen():
        show_stats(app,back,period)
    def unauthorized():
        app.clear()
        page=Page(app)
        page.title("阅读时长·需要授权")
        page.footer([("‹ 返回",back or app.profile)])
        page.label("读取账号时长失败",48,330,976,70,36,True)
        page.label("请重新扫码，读取当前账号的阅读时长。",48,420,976,70,32)
        page.button("刷新",reopen,48,665,478,86,outline=True)
        page.button("扫码读取时长",lambda:app.login(for_stats=True,resume=reopen,back=reopen),
                   544,665,478,86,primary=True)
        page.row("本机阅读时长",lambda:app.activity.show(reopen),1030,132)
    page=Page(app)
    page.title("阅读时长")
    page.footer([("‹ 返回",back or app.profile)])
    app.status=tk.StringVar()
    page.label("",48,958,976,85,26,color="#555555").configure(textvariable=app.status)
    periods=("本周","本月","本年","累计")
    values={key:tk.StringVar(value="…") for key in ("今日",*periods)}
    page.label("今日",48,310,976,76,36,True)
    page.label("",48,387,976,95,56,True).configure(textvariable=values["今日"])
    page.line(48,516,976,"#dddddd")
    caption=page.label("",48,738,976,80,36)
    current=page.label("",48,814,976,100,56,True)
    def select(key):
        nonlocal period
        period=key
        caption.configure(text=("累计" if key=="累计" else key)+"阅读")
        current.configure(textvariable=values[key])
    page.tabs([(key, "总计" if key=="累计" else key) for key in periods], period, select, 575)
    select(period)
    def display(times):
        for key,value in values.items():
            formatter=minute_duration if app.kindle else duration
            value.set(formatter(times[key]) if key in times else "官方未返回")
    def load():
        refresh.configure(state="disabled")
        scan.place_forget()
        app.status.set("正在读取微信读书账号统计…")
        def work():
            return account_stats(client, app.store, app.kindle, account, active)
        def done(result):
            name, times = result
            display(times)
            app.status.set(name + " · 微信读书账号统计" if times else
                           "微信读书未向本次登录返回时长明细，可查看本机阅读时长。")
            refresh.configure(state="normal")
            if len(times) < len(values) and (app.kindle or os.name == "nt"):
                page.put(scan,48,1010,976,88)
        def failed(error):
            if isinstance(error, AuthorizationRequired) and active():
                unauthorized()
                return
            for label, variable in values.items():
                variable.set("读取失败")
            app.error(error)
            refresh.configure(state="normal")
            if app.kindle or os.name == "nt":
                page.put(scan,48,1010,976,88)
        app.submit(work, done, failed)
    refresh=page.button("刷新",load,884,118,140,88,anchor="e")
    scan=page.button("扫码读取时长",lambda:app.login(for_stats=True,resume=reopen,back=reopen),
                     48,1050,976,88,outline=True)
    page.row("本机阅读时长",lambda:app.activity.show(reopen),1118,132)
    load()
