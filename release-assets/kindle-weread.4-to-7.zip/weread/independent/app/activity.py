"""Reading intervals are committed only by a foreground reader action."""
from datetime import date, datetime, time as midnight, timedelta
import sqlite3
import time
import tkinter as tk

from locations import SourceOffsets


def duration(seconds):
    hours, rest = divmod(seconds, 3600)
    minutes, seconds = divmod(rest, 60)
    return (f"{hours} 小时 " if hours else "") + (f"{minutes} 分钟 " if hours or minutes else "") + f"{seconds} 秒"


def local_duration(seconds):
    if 0 < seconds < 60:
        return f"{seconds} 秒"
    from account_stats import minute_duration
    return minute_duration(seconds)


class ReadingActivity:
    def __init__(self, app):
        self.app = app
        self.ready = self.hidden = False
        self.since = self.offsets = None
        root = app.root
        def visibility(event):
            if event.widget is root:
                self.set_hidden(event.type == tk.EventType.Unmap or
                                getattr(event, "state", "") == "VisibilityFullyObscured")
        for event in ("<Visibility>", "<Map>", "<Unmap>"):
            root.bind(event, visibility, add=True)
        # Toplevel focus events are also delivered to descendants; an idle
        # check distinguishes changing controls from leaving the application.
        def focus(_):
            root.after_idle(self.focus_changed)
        root.bind("<FocusOut>", focus, add=True)
        root.bind("<FocusIn>", focus, add=True)
        self.focused = True
        self.sync_job = None
        self.retry_timer = root.after(30000, self.retry_pending)

    def retry_pending(self):
        self.retry_timer = self.app.root.after(30000, self.retry_pending)
        self.sync()

    def sync(self, check_unknown=False):
        app = self.app
        client = app.client
        if (not client.account or client.signed_out or app.saver.locked or app.saver.sleeping
                or self.sync_job and not self.sync_job.done()):
            return
        def flush():
            for record in app.store.recent_unsent(client.account):
                if client.signed_out:
                    return
                client.send_reading_event(*record)
            if check_unknown and not client.signed_out:
                from reading_history import known_reports
                client.check_book_reports(known_reports(client))
        self.sync_job = app.submit(flush, lambda _: None, lambda _: None, executor=app.reporting)

    def close(self):
        self.app.root.after_cancel(self.retry_timer)

    def set_hidden(self, hidden):
        if self.hidden != hidden:
            self.hidden = hidden
            self.reset()

    def focus_changed(self):
        focused = bool(self.app.root.tk.call("focus", "-displayof", "."))
        if focused != self.focused:
            self.focused = focused
            self.reset()
            if self.app.articles:
                self.app.articles.reset_clock()

    def reset(self):
        self.since = None
        app = self.app
        if (self.ready and self.focused and not self.hidden and app.text is not None
                and app.root.winfo_viewable() and not app.saver.sleeping and not app.saver.overlay):
            self.since = time.monotonic()

    def reading(self, ready):
        self.ready = ready
        self.reset()

    def elapsed(self):
        if self.since is None:
            return 0
        elapsed = time.monotonic() - self.since
        if elapsed < 1:
            return 0
        self.reset()
        return int(elapsed) if self.since is not None and elapsed <= 120 else 0

    def record(self, client, ended, seconds, detail):
        app = self.app
        book = app.book or {}
        if str(book.get("bookId")) == str(detail["book"]) and book.get("title"):
            detail["bookTitle"] = book["title"]
        if "review" in detail and app.articles and app.articles.visible(".mp.body"):
            tkapp = app.articles.tk
            row = tkapp.call("lindex", tkapp.getvar("mp::rows"), tkapp.getvar("mp::index"))
            if str(tkapp.call("lindex", row, 0)) == str(detail["review"]):
                detail["chapterTitle"] = tkapp.call("lindex", row, 1)
        elif "uid" in detail:
            title = next((r.get("title") for r in app.rows if str(r.get("chapterUid")) == str(detail["uid"])), None)
            if title:
                detail["chapterTitle"] = title
        try:
            return client.store.record_reading(client.account, ended, seconds, detail)
        except sqlite3.Error:
            message = "本段阅读时长未能保存，可继续阅读。"
            if "review" in detail:
                self.app.articles.tk.call("mp::readMessage", message)
            else:
                self.app.status.set(message)
            return None

    def turned(self, seconds, ended):
        app, client = self.app, self.app.client
        if not seconds or not client.account:
            return
        detail = {"book": str(app.book["bookId"]), "uid": app.uid}
        result = app.loaded
        if result.get("version") is not None:
            try:
                if self.offsets is None:
                    self.offsets = SourceOffsets(result, app.reading_blocks)
                where = app.text.index("@0,0")
                offset, summary = self.offsets.bookmark(where)
                counts = [max(0, int(r.get("wordCount") or 0)) for r in app.rows]
                row = next(i for i, r in enumerate(app.rows) if str(r["chapterUid"]) == app.uid)
                size = len(result["content"].encode("utf-16-le")) // 2
                if size and sum(counts):
                    within = counts[row] * int(offset) // size
                    if result.get("preview"):
                        # The end of a shortened preview is not the end of the chapter.
                        visible = self.offsets.display[:self.offsets.display_offset(where)]
                        within = min(counts[row], sum(not ch.isspace() for ch in visible))
                    observed = app.store.get(client.account, "cloud-position", detail["book"]) or {}
                    detail.update(offset=int(offset), summary=summary, words=sum(counts[:row]) + within,
                                  cloudSeen=observed.get("changed", 0),
                                  totalWords=sum(counts), version=result["version"])
            except ValueError:
                pass  # Text-only timing is still valid when a source position cannot be mapped.
        event = self.record(client, ended, seconds, detail)
        if event and "offset" in detail:
            app.submit(lambda: client.send_reading_event(event, detail, ended, seconds),
                       lambda _: None, lambda _: None, executor=app.reporting)

    def show(self, back=None):
        from pw3_page import Page
        app = self.app
        app.clear()
        from reading_history import ReadingHistory, known_reports
        page = Page(app)
        self.return_from_totals = back or getattr(self, "return_from_totals", app.profile)
        page.footer([("‹ 返回", self.return_from_totals)])
        today = date.today()
        dates = [today, today - timedelta(days=today.weekday()), today.replace(day=1), today.replace(month=1, day=1)]
        starts = [int(datetime.combine(d, midnight.min).timestamp()) for d in dates]
        totals, states = app.store.reading_totals(app.client.account, [*starts, 0])
        client = app.client
        recent = bool(states.get("pending") and app.store.recent_unsent(client.account))
        verify_available = bool(states.get("unconfirmed") and known_reports(client))
        page.title("本机时长·近期记录待上报" if recent else "本机阅读时长")
        if recent:
            page.label("本机阅读时长", 48, 306, 976, 96, 44, True)
            page.value_row("今日", local_duration(totals[0]), 472, 126)
            page.value_row("待同步", local_duration(states["pending"]), 604, 126)
        else:
            page.label("本机累计", 48, 276, 976, 92, 36, True)
            page.label(local_duration(totals[-1]), 48, 374, 976, 104, 56, True)
            for i, label in enumerate(("今日", "本周", "本月", "本年")):
                page.value_row(label, local_duration(totals[i]), 534 + 99*i, 96)
            labels = (("pending", "待同步"), ("unconfirmed", "上报结果待核对"),
                      ("confirmed", "已确认上报"), ("matched", "云端时长及位置已核对"))
            active = [(label, states[key]) for key, label in labels if states.get(key)]
            height = min(86, 204 // max(1, len(active)))
            for i, (label, seconds) in enumerate(active):
                page.value_row(label, local_duration(seconds), 940 + i*height, height)
        app.status = tk.StringVar()
        page.label("", 48, 1250, 976, 98, 26, color="#555555").configure(
            textvariable=app.status, wraplength=round(965*page.factor), justify="left")
        def retry():
            button.configure(state="disabled")
            app.status.set("正在核对最近的阅读记录…")
            def upload():
                for record in app.store.recent_unsent(client.account):
                    client.send_reading_event(*record)
            def failed(error):
                self.show()
                app.error(error)
            app.submit(upload, lambda _: self.show(), failed, executor=app.reporting)
        if recent:
            button = page.button("立即重试最近两分钟的记录", retry, 48, 946, 976, 88, primary=True)
        elif states.get("pending"):
            app.status.set("离线记录已按原时间保存。可在「本机阅读记录」查看未同步原因。")
        if verify_available:
            def check():
                verify.configure(state="disabled")
                app.status.set("正在读取云端进度…")
                def checked(_):
                    self.show()
                    app.status.set("核对完成。无法从云端进度确认的记录仍保留。")
                def failed(error):
                    self.show()
                    app.error(error)
                app.submit(lambda: client.check_book_reports(known_reports(client)),
                           checked, failed, executor=app.reporting)
            verify = page.button("核对全部图书上报结果", check, 544, 1154, 480, 88, outline=True)
        if recent and not verify_available:
            page.row("本机阅读记录", lambda: ReadingHistory(app), 1110, 132)
        else:
            page.button("本机阅读记录", lambda: ReadingHistory(app), 48, 1154,
                        480 if verify_available else 976, 88, outline=True)
