# Catalog geometry follows the 1072 x 1448 PW3 screen. The shelf supplies the status bar.
namespace eval mp {
    variable pageSize 5
    variable rowHeight 145
    variable firstRow 377
    variable matches {}
    variable query {}
    variable keyboardRow -1
    variable readerSize 38
    variable retryOffset 0
}
proc mp::sizeFonts {} {
    ui::fonts $mp::readerSize
}
mp::sizeFonts
proc mp::statusInset {{visible 1}} {
    # The desktop preview keeps the native status strip above the panel. On
    # Kindle the system bar owns that row, so begin directly beneath it. Pure
    # reading hides the bar and reclaims that row, matching rule 26.
    set inset [expr {$visible ? ($::kindle ? $::barCut : round(40 / $::scale)) : 0}]
    place configure .mp -y $inset -height [expr {-$inset}]
}

proc mp::listView {} {
    ::independent::systemBar 1
    rememberArticle
    variable version; incr version
    variable loading 0; variable failure {}; variable incoming {}
    variable pressed {}; variable keyboardRow -1
    variable target $mp::pos
    foreach w [winfo children .mp] {destroy $w}
    statusInset
    canvas .mp.catalog -background white -borderwidth 0 -highlightthickness 0 -takefocus 1
    pack .mp.catalog -fill both -expand 1
    bind .mp.catalog <Configure> {mp::drawCatalog}
    entry .mp.search -textvariable mp::query -font catalogSearch -relief flat -bd 0 \
        -highlightthickness 0 -background white -foreground black -insertbackground black
    bind .mp.search <Return> {focus .mp.catalog; break}
    bind .mp.search <Escape> {set mp::query {}; focus .mp.catalog; break}
    bind .mp.search <FocusOut> {if {[winfo exists .mp.catalog]} {mp::drawCatalog}}
    bind .mp.catalog <ButtonPress-1> {set mp::pressed [mp::catalogHit %x %y]}
    bind .mp.catalog <ButtonRelease-1> {
        set hit [mp::catalogHit %x %y]
        if {$hit ne {} && $hit eq $mp::pressed} {mp::catalogActivate $hit}
        set mp::pressed {}
        break
    }
    foreach {key dir} {Prior -1 Next 1 Left -1 Right 1 Button-4 -1 Button-5 1} {
        bind .mp.catalog <$key> [list mp::catalogPage $dir]
    }
    bind .mp.catalog <Up> {mp::selectRow -1}
    bind .mp.catalog <Down> {mp::selectRow 1}
    bind .mp.catalog <Return> {
        if {$mp::keyboardRow >= 0} {mp::article [lindex $mp::matches $mp::keyboardRow]}
        break
    }
    bind .mp.catalog <Escape> mp::leave
    bind .mp.catalog <Control-f> {mp::catalogActivate search; break}
    if {[tk windowingsystem] eq "win32"} {
        bind .mp.catalog <MouseWheel> {mp::catalogPage [expr {%D > 0 ? -1 : 1}]; break}
    }
    catalogMatches
    # Returning from the reader also follows 上一篇 / 下一篇 across page boundaries.
    set current [lsearch -exact $mp::matches $mp::index]
    if {$current >= 0} {set mp::pos [expr {$current / $mp::pageSize * $mp::pageSize}]}
    drawCatalog
    focus .mp.catalog
}

proc mp::catalogMatches {} {
    variable matches {}; variable rows; variable query
    set needle [string tolower [string trim $query]]
    set i 0
    foreach row $rows {
        if {$needle eq {} || [string first $needle [string tolower [lindex $row 1]]] >= 0} {lappend matches $i}
        incr i
    }
}
proc mp::filterChanged {args} {
    if {![winfo exists .mp.catalog]} return
    set mp::pos 0
    set mp::target 0
    set mp::keyboardRow -1
    catalogMatches
    drawCatalog
}
trace add variable mp::query write mp::filterChanged

proc mp::catalogPage {dir} {
    variable pos; variable pageSize; variable target; variable matches
    set desired [expr {max(0,$pos + $dir*$pageSize)}]
    set loaded [llength $matches]
    set mp::keyboardRow -1
    if {$desired < $loaded} {
        set pos $desired
        set target $pos
        drawCatalog
        if {$dir < 0 || $pos+$pageSize <= $loaded} return
    } elseif {$pos+$pageSize > $loaded} {
        # Complete the current partial page before jumping over its missing titles.
        set target $pos
    } elseif {!$mp::loading} {
        set target $desired
    }
    if {$dir > 0 && !$mp::loading && $mp::query eq {} && $mp::next ne {}} {
        fetch list $mp::account $mp::next
    }
}
proc mp::selectRow {dir} {
    if {![llength $mp::matches]} return
    set last [expr {min([llength $mp::matches], $mp::pos+$mp::pageSize)-1}]
    if {$mp::keyboardRow < $mp::pos} {
        set mp::keyboardRow $mp::pos
    } else {
        set mp::keyboardRow [expr {max($mp::pos,min($last,$mp::keyboardRow+$dir))}]
    }
    drawCatalog
}
proc mp::footerTop {} {
    set h [winfo height .mp.catalog]
    if {$h <= 1} {return 1354}
    return [expr {round($h*$::scale)-94}]
}
proc mp::catalogHit {x y} {
    set x [expr {$x*$::scale}]; set y [expr {$y*$::scale}]
    if {!$mp::loginRequired && !$mp::loading && $y >= 78 && $y < 166 && $x >= 912 && $x <= 1024} {return refresh}
    if {$y >= 218 && $y < 306 && $x >= 48 && $x <= 1024} {return search}
    if {$y >= [footerTop]} {
        if {$x < 350} {return back}
        if {$mp::failure ne {}} {
            if {$x > 716 && !$mp::loading} {return retry}
            return {}
        }
        return [expr {$x < 716 ? "previous" : "next"}]
    }
    if {$mp::loginRequired && $y >= 487 && $y < 573 && $x >= 48 && $x <= 356} {return login}
    set first [catalogStart]
    if {$y >= $first && $y < $first+$mp::rowHeight*$mp::pageSize} {
        set n [expr {$mp::pos+int(($y-$first)/$mp::rowHeight)}]
        if {$n < [llength $mp::matches]} {return [list article [lindex $mp::matches $n]]}
    }
    return {}
}
proc mp::catalogActivate {hit} {
    switch -- [lindex $hit 0] {
        login {::independent::catalogLogin}
        search {
            searchBox
            focus .mp.search
            if {[llength [info commands ::independent::inputCatalog]]} {::independent::inputCatalog}
        }
        back {leave}
        previous {catalogPage -1}
        next {catalogPage 1}
        article {article [lindex $hit 1]}
        retry {fetch list $mp::account $mp::retryOffset}
        refresh {
            set mp::target $mp::pos
            set mp::incoming {}
            fetch list $mp::account 0
        }
    }
}
proc mp::searchBox {} {
    place .mp.search -x [expr {124/$::scale}] -y [expr {238/$::scale}] \
        -width [expr {885/$::scale}] -height [expr {47/$::scale}]
}

# Return the number of characters that fit, using the actual CJK font metrics.
proc mp::fitChars {text font pixels} {
    set low 0; set high [string length $text]
    while {$low < $high} {
        set n [expr {($low+$high+1)/2}]
        if {[font measure $font [string range $text 0 $n-1]] <= $pixels} {
            set low $n
        } else {set high [expr {$n-1}]}
    }
    return $low
}
proc mp::rowText {c title y space} {
    set title [string trim [regsub -all {\s+} $title { }]]
    set pixels [expr {$space/$::scale}]
    if {[font measure catalogRow $title] <= $pixels} {
        $c create text $ui::margin $y -anchor w -font catalogRow -text $title -fill $ui::ink
        return
    }
    set n [fitChars $title catalogWrapped $pixels]
    set rest [string range $title $n end]
    if {[font measure catalogWrapped $rest] > $pixels} {
        set n2 [fitChars $rest catalogWrapped [expr {$pixels-[font measure catalogWrapped …]}]]
        set rest "[string range $rest 0 $n2-1]…"
    }
    $c create text $ui::margin [expr {$y-18}] -anchor w -font catalogWrapped -text [string range $title 0 $n-1] -fill $ui::ink
    if {$rest ne {}} {$c create text $ui::margin [expr {$y+19}] -anchor w -font catalogWrapped -text $rest -fill $ui::ink}
}

proc mp::shortText {value font width} {
    set limit [ui::px $width]
    if {[font measure $font $value] <= $limit} {return $value}
    set n [fitChars $value $font [expr {$limit - [font measure $font …]}]]
    return "[string range $value 0 $n-1]…"
}
proc mp::catalogStart {} {
    return [expr {$mp::loginRequired ? 621 : $mp::firstRow}]
}
proc mp::drawCatalog {} {
    variable pos; variable matches; variable rows; variable pageSize; variable loading
    set c .mp.catalog
    $c delete all
    $c create text $ui::margin 115 -anchor w -font catalogTitle -fill $ui::ink -text 文章列表
    $c create text $ui::margin 162 -anchor w -font catalogMeta -fill $ui::secondary -text [shortText $mp::name catalogMeta 750]
    $c create line $ui::margin 186 1024 186 -fill $ui::rule
    if {!$mp::loginRequired} {
        $c create text 968 137 -font mpSmall -text 刷新 -fill [expr {$loading ? $ui::tertiary : $ui::ink}]
    }
    set prompt {}
    if {[focus] eq ".mp.search"} {searchBox} else {
        place forget .mp.search
        set prompt [expr {$mp::query eq {} ? "搜索已加载标题" : $mp::query}]
    }
    ui::searchField $c 262 [shortText $prompt catalogSearch 872]
    set end [expr {min($pos+$pageSize,[llength $matches])}]
    set first [catalogStart]
    if {$mp::loginRequired} {
        $c create text 48 442 -anchor w -font catalogSearch -text 授权已失效，请重新登录以加载文章。
        $c create rectangle 48 487 356 573 -outline $ui::ink -width [ui::px 2]
        $c create text 202 530 -font mpSmall -text 重新扫码登录
    } elseif {$mp::catalogNotice ne {} && $mp::failure eq {}} {
        $c create text 48 352 -anchor w -font catalogMeta -fill $ui::secondary -text [shortText $mp::catalogNotice catalogMeta 976]
    }
    for {set n $pos} {$n < $end} {incr n} {
        set i [lindex $matches $n]
        set row [lindex $rows $i]
        set y [expr {$first+$mp::rowHeight*($n-$pos)}]
        if {$n == $mp::keyboardRow} {
            $c create rectangle 30 $y 1042 [expr {$y+$mp::rowHeight}] -fill $ui::selected -outline {}
        }
        set detail [lindex $row 3]
        if {$i == $mp::index} {
            $c create rectangle 24 [expr {$y+15}] 30 [expr {$y+95}] -fill $ui::ink -outline {}
            set detail [expr {$detail eq {} ? "在读" : "在读  ·  $detail"}]
        }
        rowText $c [lindex $row 1] [expr {$y+46}] 976
        $c create text $ui::margin [expr {$y+90}] -anchor w -font catalogMeta -fill $ui::secondary -text $detail
        $c create text 1024 [expr {$y+80}] -anchor e -font mpSmall -fill $ui::secondary -text ›
        $c create line $ui::margin [expr {$y+$mp::rowHeight}] 1024 [expr {$y+$mp::rowHeight}] -fill $ui::hairline
    }
    if {!$end && !$loading && !$mp::loginRequired && $mp::failure eq {}} {
        $c create text 536 525 -font catalogMeta -fill $ui::secondary -text [expr {$mp::query eq {} ? "暂无文章" : "未找到匹配的文章"}]
    }
    set footer [footerTop]
    set center [expr {$footer+61}]
    $c create rectangle 0 $footer 1072 [expr {$footer+94}] -fill white -outline {}
    $c create line 0 $footer 1072 $footer -fill $ui::rule -width [ui::px 2]
    if {$mp::failure ne {}} {
        $c create text 48 $center -anchor w -font catalogSearch -text 返回 -fill $ui::ink
        if {!$mp::loginRequired} {
            $c create text 48 352 -anchor w -font catalogSearch -text [shortText $mp::failure catalogSearch 976]
        }
        $c create text 1024 $center -anchor e -font catalogSearch -text 重试
    } else {
        $c create text 179 $center -font catalogSearch -text 返回 -fill $ui::ink
        set caption [expr {$loading ? "加载中…" : "第 [expr {$pos/$pageSize+1}] 页"}]
        $c create text 536 [expr {$footer-68}] -font catalogMeta -fill $ui::secondary -text $caption
        set canNext [expr {$end < [llength $matches] || (!$loading && $mp::query eq {} && $mp::next ne {})}]
        $c create text 536 $center -font catalogSearch -text 上一页 -fill [expr {$pos ? $ui::ink : $ui::tertiary}]
        $c create text 893 $center -font catalogSearch -text 下一页 -fill [expr {$canNext ? $ui::ink : $ui::tertiary}]
    }
    set factor [expr {1.0/$::scale}]
    $c scale all 0 0 $factor $factor
}
