namespace eval mp {
    variable options 0
    variable ready 0
    variable touch {}
    variable positions
    array set positions {}
    variable bodyMargin 64
}
proc mp::rememberArticle {} {
    if {[winfo exists .mp.body] && $mp::ready} {
        set key [lindex $mp::rows $mp::index 0]
        set ::mp::positions($key) [.mp.body index @0,0]
        ::independent::remember $key $mp::positions($key)
    }
}
proc mp::readerButton {path label action {kind plain} {font mpSmall}} {
    ui::button $path $label $action $kind $font
}
# The catalog meta keeps the ISO date (sortable, matches the list row); the
# byline restates it as "M 月 D 日" to match the article header mockups.
proc mp::chineseDate {iso} {
    if {![regexp {^\d{4}-0*(\d{1,2})-0*(\d{1,2})$} $iso -> m d]} {return $iso}
    return "$m 月 $d 日"
}
proc mp::article {n} {
    if {$n < 0 || $n >= [llength $mp::rows]} return
    rememberArticle
    set mp::index $n
    set row [lindex $mp::rows $n]
    foreach w [winfo children .mp] {destroy $w}
    statusInset 0
    ::independent::systemBar 0
    set mp::options 0
    set mp::ready 0
    set mp::touch {}
    frame .mp.foot -bg white
    frame .mp.rule -bg $ui::rule -height 1
    readerButton .mp.foot.toc 文章列表 mp::listView plain catalogSearch
    label .mp.progress -font catalogSearch -fg $ui::secondary -bg white
    readerButton .mp.foot.options "阅读选项" mp::readerOptions plain catalogSearch
    pack .mp.foot.toc -side left
    pack .mp.foot.options -side right
    pack .mp.progress -in .mp.foot -expand 1
    frame .mp.nav -bg white
    foreach {w label action} [list prev 上一篇 [list mp::article [expr {$n-1}]] \
            smaller − {mp::fontStep -1} larger ＋ {mp::fontStep 1} next 下一篇 mp::nextArticle] {
        readerButton .mp.nav.$w $label $action outlined
        if {$w eq "smaller"} {
            label .mp.nav.label -text 字号 -font catalogSearch -bg white
            pack .mp.nav.label -side left -padx [ui::px 12]
        }
        if {$w eq "larger"} {
            label .mp.nav.value -textvariable mp::readerSize -font catalogRow -bg white
            pack .mp.nav.value -side left -padx [ui::px 14]
        }
        pack .mp.nav.$w -side left -expand 1 -fill both
    }
    if {!$n} {.mp.nav.prev configure -state disabled}
    if {$n+1 >= [llength $mp::rows] && $mp::next eq {}} {.mp.nav.next configure -state disabled}
    label .mp.status -bg white -fg $ui::secondary -font mpSmall -anchor w -justify left
    readerButton .mp.retry 重试 [list mp::article $n]
    text .mp.body -wrap char -bg white -fg $ui::ink -relief flat -bd 0 -highlightthickness 0 \
        -cursor arrow -font mpBody -yscrollcommand mp::readerProgress
    pack .mp.body -fill both -expand 1
    readerLayout
    .mp.body insert end "[lindex $row 1]\n" heading
    set date [lindex $row 3]
    set byline $mp::name
    if {$date ne {}} {append byline "　　[chineseDate $date]"}
    .mp.body insert end "$byline\n" byline
    .mp.body configure -state disabled
    bind .mp.body <ButtonPress-1> {set mp::touch [list %x %y]; focus .mp.body; break}
    bind .mp.body <B1-Motion> {break}
    bind .mp.body <ButtonRelease-1> {mp::readerTap %x %y; break}
    foreach {key dir} {Left -1 Right 1 Prior -1 Next 1 space 1 Button-4 -1 Button-5 1} {
        bind .mp.body <$key> "mp::turn $dir; break"
    }
    bind .mp.body <Return> {mp::readerOptions; break}
    if {[tk windowingsystem] eq "win32"} {
        bind .mp.body <MouseWheel> {mp::turn [expr {%D > 0 ? -1 : 1}]; break}
    }
    bind .mp.body <Escape> {if {$mp::options} {mp::readerOptions} else {mp::listView}; break}
    focus .mp.body
    fetch read [lindex $row 0] 0
}
proc mp::readerLayout {} {
    set margin [ui::px $mp::bodyMargin]
    .mp.body configure -padx $margin -pady [expr {round(148/$::scale)}] -spacing2 [expr {round(9/$::scale)}]
    .mp.body tag configure heading -font mpTitle -spacing3 [expr {round(12/$::scale)}]
    .mp.body tag configure byline -font catalogMeta -foreground $ui::secondary -spacing3 [ui::px 46]
    .mp.status configure -wraplength [expr {round(944/$::scale)}]
    foreach frame [array names mp::pictures] {sizePicture $frame}
}
proc mp::fontStep {step} {
    set mark [.mp.body index @0,0]
    set mp::readerSize [expr {max(28,min(54,$mp::readerSize+4*$step))}]
    sizeFonts
    updateFontButtons
    update idletasks
    .mp.body yview $mark
}
proc mp::updateFontButtons {} {
    .mp.nav.smaller configure -state [expr {$mp::readerSize <= 28 ? "disabled" : "normal"}]
    .mp.nav.larger configure -state [expr {$mp::readerSize >= 54 ? "disabled" : "normal"}]
}
proc mp::readerOptions {} {
    set mark [.mp.body index @0,0]
    set mp::options [expr {!$mp::options}]
    ::independent::systemBar $mp::options
    statusInset $mp::options
    if {$mp::options} {
        updateFontButtons
        pack .mp.foot .mp.rule -side bottom -fill x -before .mp.body
        pack .mp.nav -side bottom -fill x -before .mp.body
        .mp.foot.options configure -text 收起选项
    } else {
        pack forget .mp.nav .mp.foot .mp.rule
        .mp.foot.options configure -text 阅读选项
    }
    update idletasks
    .mp.body yview $mark
    focus .mp.body
    ::independent::clock
}
proc mp::readerProgress {first last} {
    if {!$mp::ready || ![winfo exists .mp.progress]} return
    set percent [expr {$last >= 0.99999 ? 100 : round(100*$first/(1-$last+$first))}]
    .mp.progress configure -text "$percent%"
}
proc mp::turn {dir} {
    if {!$mp::ready} return
    set position [.mp.body index @0,0]
    .mp.body yview scroll $dir pages
    if {$position ne [.mp.body index @0,0]} {reading::turned}
}
proc mp::readerTap {x y} {
    if {$mp::touch eq {}} return
    lassign $mp::touch startX startY
    set mp::touch {}
    set delta [expr {$x-$startX}]
    if {abs($delta) > 0.12*[winfo width .mp.body] && abs($delta) > abs($y-$startY)} {
        turn [expr {$delta < 0 ? 1 : -1}]
    } elseif {abs($x-$startX)+abs($y-$startY) < 12} {
        set part [expr {double($x)/[winfo width .mp.body]}]
        if {$part < 0.30} {
            turn [expr {[info exists ::mp::leftNext] && $::mp::leftNext ? 1 : -1}]
        } elseif {$part > 0.65} {turn 1} else {readerOptions}
    }
}
proc mp::nextArticle {} {
    if {$mp::index+1 < [llength $mp::rows]} {article [expr {$mp::index+1}]; return}
    if {$mp::next ne {}} {
        set mp::incoming {}
        .mp.nav.next configure -state disabled
        fetch following $mp::account $mp::next
    }
}
proc mp::readMessage {message {retry {}}} {
    if {$message eq {}} {
        pack forget .mp.status .mp.retry
        return
    }
    .mp.status configure -text $message
    pack .mp.status -before .mp.body -side bottom -fill x -padx 14 -pady 4
    if {$retry ne {}} {
        .mp.retry configure -command $retry
        pack .mp.retry -before .mp.body -side bottom -anchor w -padx 10
    } else {pack forget .mp.retry}
}
