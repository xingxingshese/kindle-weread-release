# Text windows reserve each picture's space and load when scrolled into view.
namespace eval mp {
    variable serial 0
    variable pictures
    array set pictures {}
}
proc mp::pictureWidth {} {
    return [expr {max(32,round(944.0/$::scale)-4)}]
}
proc mp::insertPicture {url ratio alt} {
    variable pictures
    set frame .mp.body.pic[incr mp::serial]
    if {![string is double -strict $ratio] || !($ratio > 0 && $ratio <= 10)} {set ratio 0.6}
    frame $frame -bg white -bd 0 -highlightthickness [ui::px 2] -highlightbackground $ui::rule
    label $frame.label -text 加载图片… -font mpSmall -fg $ui::tertiary -bg white -bd 0 -highlightthickness 0
    place $frame.label -relwidth 1 -relheight 1
    set pictures($frame) [dict create url $url ratio $ratio alt $alt width 0 wanted 0 photo {}]
    bind $frame <Destroy> [list mp::discardPicture $frame]
    bind $frame <Map> [list after idle [list mp::loadPicture $frame]]
    foreach event {ButtonPress-1 ButtonRelease-1 B1-Motion Button-4 Button-5} {
        bind $frame.label <$event> [list mp::pictureGesture $event %X %Y $frame]
    }
    if {[tk windowingsystem] eq "win32"} {
        bind $frame.label <MouseWheel> {mp::turn [expr {%D > 0 ? -1 : 1}]; break}
    }
    sizePicture $frame
    .mp.body configure -state normal
    .mp.body window create end -window $frame
    .mp.body insert end "\n\n"
    .mp.body configure -state disabled
}
proc mp::pictureGesture {event x y frame} {
    variable pictures
    if {$event eq "ButtonRelease-1" && [dict get $pictures($frame) wanted] == -1} {
        set mp::touch {}
        dict set pictures($frame) wanted 0
        loadPicture $frame
        return
    }
    event generate .mp.body <$event> -x [expr {$x-[winfo rootx .mp.body]}] -y [expr {$y-[winfo rooty .mp.body]}]
}
proc mp::sizePicture {frame} {
    variable pictures
    set width [pictureWidth]
    if {$width == [dict get $pictures($frame) width]} return
    dict set pictures($frame) width $width
    $frame configure -width $width -height [expr {max(1,round($width*min(1.32,[dict get $pictures($frame) ratio])))}]
    if {[winfo ismapped $frame]} {after idle [list mp::loadPicture $frame]}
}
proc mp::loadPicture {frame} {
    variable pictures
    if {![info exists pictures($frame)] || ![winfo ismapped $frame]} return
    set width [dict get $pictures($frame) width]
    set wanted [dict get $pictures($frame) wanted]
    if {$wanted == $width || $wanted == -1} return
    dict set pictures($frame) wanted $width
    $frame.label configure -text 加载图片… -font mpSmall -fg $ui::tertiary
    ::independent::picture $frame $width [dict get $pictures($frame) url]
}
proc mp::showPicture {frame width path} {
    variable pictures
    if {![info exists pictures($frame)] || [dict get $pictures($frame) wanted] != $width} return
    if {$path eq {} || [catch {image create photo -file $path} photo]} {
        dict set pictures($frame) wanted -1
        set alt [dict get $pictures($frame) alt]
        $frame.label configure -image {} -font catalogSearch -fg $ui::ink \
            -text [string trim "$alt\n图片加载失败，点图重试"] -wraplength $width
        return
    }
    set old [dict get $pictures($frame) photo]
    dict set pictures($frame) photo $photo
    dict set pictures($frame) ratio [expr {double([image height $photo])/$width}]
    $frame configure -height [image height $photo] -highlightthickness 0
    $frame.label configure -image $photo -text {}
    if {$old ne {}} {image delete $old}
}
proc mp::discardPicture {frame} {
    variable pictures
    if {![info exists pictures($frame)]} return
    set photo [dict get $pictures($frame) photo]
    if {$photo ne {}} {image delete $photo}
    unset pictures($frame)
}
