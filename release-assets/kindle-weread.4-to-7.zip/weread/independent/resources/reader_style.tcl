# Shared typography and spacing for article pages and the calendar.
# Dimensions are expressed in the PW3's 1072-pixel portrait coordinate space.
# The panel shows 16 grey levels, so every colour is one of them (#000, #111,
# ..., #fff): no dithering speckle, and the same grey everywhere.
namespace eval ui {
    variable ink #222222        ;# text, titles, icons, selection, primary button
    variable secondary #555555  ;# subtitles, notes, labels
    variable tertiary #888888   ;# disabled, chevrons, placeholders
    variable rule #aaaaaa       ;# strong dividers (header rule, footer rule)
    variable hairline #cccccc   ;# list row separators, slider trough
    variable selected #eeeeee   ;# pressed or selected background
    variable margin 48
    variable backFile [file join [file dirname [info script]] back_arrow.png]
    # Type scale in native pixels: role -> size weight.
    variable type {title {44 bold} heading {36 normal} body {32 normal} label {28 normal} caption {26 normal}}
}
proc ui::px {value} {expr {max(1,round(double($value)/$::scale))}}
proc ui::searchField {c cy text {end 1024}} {
    set top [expr {$cy-40}]; set bottom [expr {$cy+40}]; set radius 16
    set stroke [px 2]
    foreach {x y angle} [list 48 $top 90 [expr {$end-32}] $top 0 48 [expr {$bottom-32}] 180 [expr {$end-32}] [expr {$bottom-32}] 270] {
        $c create arc $x $y [expr {$x+32}] [expr {$y+32}] -start $angle -extent 90 -style arc -outline $ui::secondary -width $stroke
    }
    foreach y [list $top $bottom] {$c create line 64 $y [expr {$end-$radius}] $y -fill $ui::secondary -width $stroke}
    foreach x [list 48 $end] {$c create line $x [expr {$top+$radius}] $x [expr {$bottom-$radius}] -fill $ui::secondary -width $stroke}
    $c create oval 73 [expr {$cy-14}] 94 [expr {$cy+7}] -outline $ui::ink -width $stroke
    $c create line 91 [expr {$cy+4}] 103 [expr {$cy+16}] -fill $ui::ink -width $stroke
    if {$text ne {}} {$c create text 124 $cy -anchor w -font catalogSearch -fill $ui::secondary -text $text}
}
proc ui::fonts {bodySize} {
    # Each named font takes its size from a role in ui::type; only the article
    # body follows the reader's own size setting.
    foreach {name role weight} {catalogTitle title {} mpTitle title {} catalogRow heading {}
            catalogWrapped body {} catalogSearch body {} mpSmall label {} navLabel label {}
            navSelected label bold catalogMeta caption {} homeClock caption {}} {
        lassign [dict get $ui::type $role] size base
        defineFont $name $size [expr {$weight eq {} ? $base : $weight}]
    }
    defineFont mpBody $bodySize normal
}
# Break text into lines no wider than width (screen pixels). Tk labels only
# break at spaces, so Chinese prose otherwise wraps at the nearest Latin word.
# Closing punctuation stays at the end of the line it follows.
proc ui::wrap {text font width} {
    set out {}
    foreach para [split $text \n] {
        set line {}
        foreach ch [split $para {}] {
            if {$line ne {} && [::font measure $font $line$ch] > $width
                    && [string first $ch "，。、；：！？）」』》,.;:!?)"] < 0} {
                lappend out [string trimright $line]
                set line [expr {$ch eq " " ? {} : $ch}]
            } else {
                append line $ch
            }
        }
        lappend out $line
    }
    join $out \n
}
proc ui::defineFont {name size weight} {
    if {$name ni [font names]} {::font create $name}
    ::font configure $name -family {Noto Sans CJK SC} -weight $weight -size [expr {-[px $size]}]
}
proc ui::backImage {} {
    set icon backArrow[px 112]
    if {$icon ni [image names]} {
        image create photo $icon -file $ui::backFile
        if {$::scale != 1} {
            set large [image create photo]
            $large copy $icon -zoom 4
            $icon copy $large -subsample [expr {round(4*$::scale)}] -shrink
            image delete $large
        }
    }
    return $icon
}
proc ui::backButton {w action} {
    button $w {} $action
    $w configure -image [backImage] -padx 0 -pady 0 -highlightbackground white -takefocus 1
    bind $w <Return> [list $w invoke]
}
proc ui::button {w title action {kind plain} {font mpSmall}} {
    set bg white
    set fg $ui::ink
    set border white
    if {$kind eq "outlined"} {set border $ui::ink}
    if {$kind eq "primary"} {set bg $ui::ink; set fg white; set border $ui::ink}
    ::button $w -text $title -command $action -font $font -relief flat -overrelief flat \
        -bd 0 -bg $bg -fg $fg -activebackground $ui::selected -activeforeground $ui::ink \
        -highlightthickness [px 2] -highlightbackground $border -highlightcolor $ui::ink \
        -disabledforeground $ui::tertiary -padx [px 20] -pady [px 14]
}
