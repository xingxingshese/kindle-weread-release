namespace eval mp {
    variable dir [file dirname [info script]]
    variable version 0
    variable rows {}
    variable catalogNotice {}
    variable loginRequired 0
    variable next {}
    variable name 公众号
    variable index -1
    variable pressed -1
    variable pos 0
}
proc mp::leave {} {
    rememberArticle
    variable version; incr version
    destroy .mp
    ::independent::shelf
}
proc mp::openAccount {id {title 公众号}} {
    variable loginRequired 0
    variable account $id; variable name $title
    variable duplicatePages 0
    variable catalogNotice {}
    variable rows {}; variable next {}; variable pos 0
    variable query {}; variable index -1
    variable version; incr version
    if {[winfo exists .mp]} {destroy .mp}
    frame .mp -bg white
    place .mp -in .page -relwidth 1 -relheight 1
    raise .mp
    listView
    fetch list $id 0
}
source -encoding utf-8 [file join $mp::dir mp_catalog.tcl]
source -encoding utf-8 [file join $mp::dir mp_reader.tcl]
source -encoding utf-8 [file join $mp::dir mp_pictures.tcl]
proc mp::fetch {mode key offset} {
    variable version
    incr version
    if {$mode eq "list"} {
        set mp::loading 1
        set mp::failure {}
        drawCatalog
    } else {readMessage 加载中…}
    set operation [expr {$mode eq "following" ? "list" : $mode}]
    ::independent::fetch $version $mode $operation $key $offset
}
proc mp::showCachedCatalog {items} {
    set mp::rows $items
    if {[lindex $items 0 2] ne {}} {set mp::name [lindex $items 0 2]}
    set mp::catalogNotice 本机文章列表
    catalogMatches
    drawCatalog
}
proc mp::record {mode offset type data} {
    variable rows; variable next; variable name
    switch -- $type {
            item {
                lappend mp::incoming $data
            }
            next {
                set next [lindex $data 0]
                set currentId [lindex $rows $mp::index 0]
                if {$offset == 0} {set rows {}}
                array set known {}
                foreach row $rows {set known([lindex $row 0]) 1}
                set original [llength $rows]
                foreach row $mp::incoming {
                    set id [lindex $row 0]
                    if {![info exists known($id)]} {lappend rows $row; set known($id) 1}
                }
                if {$offset > 0 && [llength $rows] == $original && $next ne {}} {
                    incr mp::duplicatePages
                } else {set mp::duplicatePages 0}
                if {[lindex $rows 0 2] ne {}} {set name [lindex $rows 0 2]}
                if {$offset == 0 && $currentId ne {}} {set mp::index [lsearch -exact -index 0 $rows $currentId]}
                set mp::incoming {}
                set mp::loading 0
                catalogMatches
                if {$mp::pos >= [llength $mp::matches]} {set mp::pos 0; set mp::target 0}
                if {$mode eq "following"} {
                    readMessage {}
                    if {$mp::index+1 < [llength $rows]} {
                        article [expr {$mp::index+1}]
                    } elseif {$next ne {}} {
                        .mp.nav.next configure -state normal
                        readMessage 本批没有新文章，点下一篇继续。
                    } else {readMessage 已到最后一篇}
                    return
                }
                if {$mp::target < [llength $mp::matches]} {set mp::pos $mp::target}
                drawCatalog
                if {$next ne {} && [llength $rows] < $mp::pageSize && $mp::duplicatePages < 2} {
                    after idle [list mp::fillFirstPage $mp::version]
                }
            }
            paragraphs {
                .mp.body configure -state normal
                .mp.body insert end "[lindex $data 0]\n\n"
                .mp.body configure -state disabled
            }
            picture {insertPicture {*}$data}
            ready {
                set mp::ready 1
                ::independent::clock
                readMessage {}
                set key [lindex $rows $mp::index 0]
                if {[info exists mp::positions($key)]} {.mp.body yview $mp::positions($key)} else {.mp.body yview moveto 0}
                readerProgress {*}[.mp.body yview]
            }
            error {
                if {$mode eq "list"} {
                    set mp::loading 0
                    set mp::incoming {}
                    set mp::failure [lindex $data 0]
                    set mp::retryOffset $offset
                    drawCatalog
                } elseif {$mode eq "following"} {
                    .mp.nav.next configure -state normal
                    readMessage [lindex $data 0] mp::nextArticle
                } else {readMessage [lindex $data 0] [list mp::article $mp::index]}
            }
        }
}

proc mp::fillFirstPage {version} {
    if {$version == $mp::version && [winfo exists .mp.catalog] && !$mp::loading && $mp::query eq {} && $mp::next ne {}} {
        fetch list $mp::account $mp::next
    }
}
