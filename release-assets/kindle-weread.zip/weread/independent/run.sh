#!/bin/sh
set -eu
umask 077
if [ "${1:-}" = --hold-sleep-screen ]; then
    # The reader owns the pipe. EOF also restores the renderers if Python crashes.
    service=com.lab126.blanket
    saved=
    restore() {
        for module in $saved; do
            lipc-set-prop "$service" load "$module" || echo "Could not restore $module" >&2
        done
    }
    trap restore EXIT
    trap 'exit 0' HUP INT TERM
    modules=$(lipc-get-prop "$service" load) || exit 1
    for module in $modules; do
        case "$module" in
            screensaver|ad_screensaver|custom_screensaver)
                if lipc-set-prop "$service" unload "$module"; then
                    saved="$saved $module"
                else
                    echo "Could not release $module for the reader sleep screen" >&2
                fi ;;
        esac
    done
    read -r unused || :
    exit 0
fi
app=/mnt/us/weread/independent
best=$(cat "$app/revision")
for dir in /mnt/us/weread/independent-updates/[0-9]*; do
    rev=${dir##*/}
    case "$rev" in *[!0-9]*) continue ;; esac
    if [ -f "$dir/run.sh" ] && [ -f "$dir/app/app.py" ] && [ -x "$dir/bin/python3" ] &&
       [ -f "$dir/revision" ] && [ "$(cat "$dir/revision")" = "$rev" ] && [ "$rev" -gt "$best" ]; then
        app=$dir
        best=$rev
    fi
done
if [ "$app" != /mnt/us/weread/independent ] && [ "$0" != "$app/run.sh" ]; then
    exec sh "$app/run.sh" "$@"
fi
export WR_APP_ROOT="$app" WR_PW3_VIEWER=1 DISPLAY="${DISPLAY:-:0}"
export PYTHONHOME="$app/runtime/usr" PYTHONUTF8=1 PYTHONDONTWRITEBYTECODE=1
export PYTHONPATH="$app${PYTHONPATH:+:$PYTHONPATH}"
export TCL_LIBRARY="$app/runtime/usr/lib/tcl8.6" TK_LIBRARY="$app/runtime/usr/lib/tk8.6"
export FONTCONFIG_FILE="$app/fonts.conf" SSL_CERT_FILE=/mnt/us/weread/certs/ca-bundle.pem
exec "$app/bin/python3" "$app/app/app.py" --data-dir /mnt/us/weread/independent-data \
    >> /mnt/us/weread/independent-launch.log 2>&1
