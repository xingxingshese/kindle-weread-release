"""Read the original reader's account-scoped last-chapter records."""
import hashlib
import json
from pathlib import PureWindowsPath


def last_chapter(books, account, book):
    if not account or not book or PureWindowsPath(book).name != book or ":" in book or book in {".", ".."}:
        return None
    scope = hashlib.sha256(str(account).encode()).hexdigest()
    cache = books / "ui-cache" / "accounts" / scope
    newest = None
    for path in (cache / "last" / (book + ".json"), cache / "last.json"):
        try:
            row = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if (not isinstance(row, dict) or str(row.get("bookId")) != book
                or type(row.get("chapterUid")) != int or row["chapterUid"] < 0
                or type(row.get("savedAt")) != int or row["savedAt"] <= 0):
            continue
        if not newest or newest["changed"] < row["savedAt"]:
            newest = {"uid": str(row["chapterUid"]), "changed": row["savedAt"], "offset": 0}
    return newest


def first_position(legacy, cloud, rows):
    # Chapter indices can change between editions. The UID is shared with the web catalog.
    if not legacy or not any(str(row["chapterUid"]) == legacy["uid"] for row in rows):
        return cloud
    if cloud and (cloud["changed"] >= legacy["changed"] or cloud["uid"] == legacy["uid"]):
        return cloud
    return legacy
