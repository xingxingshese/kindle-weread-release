"""Import explicitly saved preferences from the original and enhanced Kindle reader."""
import json
from pathlib import Path


def _digit(path, low, high):
    # The native reader requires exactly two bytes, including the final LF.
    try:
        if not path.is_file():
            return None
        with path.open("rb") as source:
            raw = source.read(3)
    except OSError:
        return None
    if len(raw) == 2 and raw[1] == 10 and 48 + low <= raw[0] <= 48 + high:
        return raw[0] - 48
    return None


def _same_account(directory, account):
    if not account or not str(account).isascii() or not str(account).isdigit():
        return False
    try:
        with (directory / "session.json").open("rb") as source:
            data = source.read(65537)
        if len(data) > 65536:
            return False
        session = json.loads(data)
    except (OSError, ValueError, RecursionError):
        return False
    vid = session.get("vid") if isinstance(session, dict) else None
    return type(vid) in (int, str) and str(vid) == str(account)


def migrate_settings(store, account, account_dir, books_dir):
    """Return the settings newly imported from the original device configuration directory."""
    if account_dir is None:
        return {}
    directory = Path(account_dir)
    candidates = []
    columns = _digit(directory / "shelf-columns.conf", 3, 6)
    if columns is not None:
        candidates.append(("", "shelf-columns", columns))

    # These files are device-wide in the native reader but scoped to the signed-in
    # account here. Only seed the account that was active in the original reader.
    if _same_account(directory, account):
        for name, kind in (("reader-left-next.conf", "left-tap-next"),
                           ("reader-chapter-pages.conf", "chapter-pages"),
                           ("book-downloads-allowed.conf", "safe-mode")):
            digit = _digit(directory / name, 0, 1)
            if digit is not None:
                enabled = digit == 0 if kind == "safe-mode" else digit == 1
                candidates.append((str(account), kind, enabled))

    imported = {}
    if candidates:
        with store.connect() as db:
            for scope, kind, value in candidates:
                row = db.execute("insert or ignore into items(account,kind,id,value) values(?,?,'',?)",
                                 (scope, kind, json.dumps(value)))
                if row.rowcount:
                    imported[kind] = value
    return imported
