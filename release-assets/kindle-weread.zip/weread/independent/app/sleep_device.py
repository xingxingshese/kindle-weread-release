"""Frontlight and airplane-mode handling for the Kindle reader."""
import subprocess
import threading
from pathlib import Path

from quick_device import POWER, SleepWifi, command, write_int


class Frontlight:
    def __init__(self):
        self.saved = None
        self.dimmed = None

    def read(self):
        try:
            result = subprocess.check_output(["lipc-get-prop", "com.lab126.powerd", "flIntensity"],
                                             stderr=subprocess.DEVNULL, timeout=2)
            value = int(result)
            return value if 0 <= value <= 24 else None
        except (OSError, ValueError, subprocess.SubprocessError):
            return None

    def write(self, level):
        try:
            subprocess.run(["lipc-set-prop", "-i", "com.lab126.powerd", "flIntensity", str(level)],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=2, check=True)
            return True
        except (OSError, subprocess.SubprocessError):
            return False

    def dim(self, minimum=False):
        if self.saved is not None:
            return
        level = self.read()
        if level is None or level == 0:
            return
        self.saved, self.dimmed = level, 0 if minimum else min(1, level - 1)
        self.write(self.dimmed)

    def restore(self):
        if self.saved is None:
            return
        # Preserve a level that the user changed while the cover was visible.
        if self.read() in (None, self.dimmed) and not self.write(self.saved):
            return
        self.saved = self.dimmed = None


class SystemSleepWifi:
    """Airplane-mode lock shared by the app saver and Kindle's own sleep.

    The inner SleepWifi captures state on the first reason and restores it
    after the last one ends. One lock serializes the relay and listener threads.
    """
    EVENTS = {"goingToScreenSaver": ("saver", True), "outOfScreenSaver": ("saver", False),
              "readyToSuspend": ("suspend", True), "suspending": ("suspend", True),
              "wakeupFromSuspend": ("suspend", False), "resuming": ("suspend", False)}

    def __init__(self, inner=None, retries=6, delay=3, on_event=None):
        self.inner = inner or SleepWifi()
        self.on_event = on_event
        self.guard = threading.RLock()
        self.reasons = set()
        self.retries, self.delay = retries, delay
        self.generation = 0
        self.lock_failed = False
        self.spawn = threading.Lock()
        self.stopped = threading.Event()
        self.proc = None
        self.thread = None

    def _change(self, reason, active):
        with self.guard:
            if self.stopped.is_set() and active:
                return
            before = bool(self.reasons)
            (self.reasons.add if active else self.reasons.discard)(reason)
            after = bool(self.reasons)
            if after == before:
                # Duplicate or nested reason: keep any pending reconnect, but
                # try again if entering airplane mode failed earlier.
                if after and active and self.lock_failed:
                    self._lock()
                return
            # Only a real lock/unlock transition ends the previous retry worker.
            self.generation += 1
            if after:
                self._lock()
                done = not self.lock_failed
            else:
                self.lock_failed = False
                done = self.inner.restore()
            if not done:
                threading.Thread(target=self._retry, args=(self.generation,), daemon=True).start()

    def _lock(self):
        # A pre-existing manual airplane mode counts as success, not a failure.
        self.lock_failed = self.inner.lock() is False

    def _retry(self, generation):
        for _ in range(self.retries):
            if self.stopped.wait(self.delay):
                return
            with self.guard:
                if generation != self.generation:
                    return
                if self.reasons:  # still locked: only a failed airplane-mode entry is pending
                    if self.lock_failed:
                        self._lock()
                    if not self.lock_failed:
                        return
                elif self.inner.restore():
                    return

    # Relay interface: the app inactivity saver.
    def lock(self):
        self._change("app", True)

    def restore(self):
        self._change("app", False)

    def event(self, name):
        action = self.EVENTS.get(name)
        if not action:
            return
        with self.guard:
            if name == "outOfScreenSaver":
                self._change("suspend", False)
            elif not action[1] and "saver" in self.reasons and command("lipc-get-prop", POWER, "state") == "active":
                # A missed outOfScreenSaver must not keep Wi-Fi off after waking.
                self._change("saver", False)
            self._change(*action)

    def listen(self):
        events = ",".join(self.EVENTS)
        while not self.stopped.is_set():
            with self.spawn:  # close() cannot slip between the stop check and the launch
                if self.stopped.is_set():
                    return
                try:
                    self.proc = subprocess.Popen(["lipc-wait-event", "-m", POWER, events],
                                                 stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, text=True)
                except OSError:
                    return  # No Kindle event service, for example on the desktop.
            for line in self.proc.stdout:
                parts = line.split()
                if parts:
                    self.event(parts[0])
                    if self.on_event:
                        self.on_event(parts[0])
            self.proc.wait()
            self.stopped.wait(2)

    def start(self):
        self.thread = threading.Thread(target=self.listen, daemon=True)
        self.thread.start()

    def close(self):
        self.stopped.set()
        with self.spawn:
            if self.proc and self.proc.poll() is None:
                self.proc.terminate()
        if self.thread:
            self.thread.join(5)
        with self.guard:
            self.reasons.clear()
            self.generation += 1
            self.inner.finish()


class PowerPolicy:
    """Keep the reader awake until its own idle timer requests system sleep."""
    LOCK_SLEEP = 300

    def __init__(self, wifi, lock_sleep=LOCK_SLEEP, keep_interval=30):
        self.wifi = wifi
        self.lock_sleep, self.keep_interval = lock_sleep, keep_interval
        self.guard = threading.Lock()
        self.locked = False
        self.system_sleeping = False
        self.timer = None
        self.stopped = threading.Event()
        self.thread = None

    def _awake(self):
        return command("lipc-get-prop", POWER, "state") == "active"

    def _keep(self):
        while not self.stopped.wait(self.keep_interval):
            if self._awake():
                write_int(POWER, "touchScreenSaverTimeout", 1)

    def start(self):
        launcher = Path(__file__).resolve().parents[1] / "run.sh"
        self.display_guard = subprocess.Popen(["sh", str(launcher), "--hold-sleep-screen"],
                                              stdin=subprocess.PIPE, start_new_session=True)
        self.thread = threading.Thread(target=self._keep, daemon=True)
        self.thread.start()

    def _sleep(self):
        with self.guard:
            if (self.timer is not threading.current_thread() or not self.locked or
                    self.stopped.is_set() or not self._awake()):
                return
            self.timer = None
            write_int(POWER, "powerButton", 1)

    def system_state(self, asleep):
        # A physical button press wins over a queued inactivity timeout, even
        # when the process resumes after the timer's original deadline.
        with self.guard:
            self.system_sleeping = asleep
            if asleep and self.timer:
                self.timer.cancel()
                self.timer = None

    # Relay interface: the app's actual lock screen.
    def lock(self):
        with self.guard:
            self.locked = True
            if self.timer:
                self.timer.cancel()
            if not self.system_sleeping:
                self.timer = threading.Timer(self.lock_sleep, self._sleep)
                self.timer.daemon = True
                self.timer.start()
        self.wifi.lock()

    def restore(self):
        with self.guard:
            self.locked = False
            if self.timer:
                self.timer.cancel()
                self.timer = None
        self.wifi.restore()

    def close(self):
        self.stopped.set()
        with self.guard:
            self.locked = False
            if self.timer:
                self.timer.cancel()
        if self.thread:
            self.thread.join(5)
            self.display_guard.stdin.close()
            self.display_guard.wait()
