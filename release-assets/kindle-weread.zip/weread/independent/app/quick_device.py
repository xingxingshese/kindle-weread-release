"""Kindle wireless state and reconnection after sleep."""
import subprocess
import sys
import time

POWER = "com.lab126.powerd"
RADIO = "com.lab126.wifid"
CONNECTION = "com.lab126.cmd"


def command(*args):
    try:
        result = subprocess.run(args, text=True, encoding="utf-8", errors="replace",
                                capture_output=True, timeout=2)
        return result.stdout.rstrip("\n") if result.returncode == 0 else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def read_int(service, name):
    value = command("lipc-get-prop", service, name)
    return int(value) if value and value.isascii() and value.isdecimal() else None


def write_int(service, name, value):
    return command("lipc-set-prop", "-i", service, name, str(value)) is not None


def current_ssid():
    status = command("wpa_cli", "-i", "wlan0", "status") or ""
    entries = dict(line.split("=", 1) for line in status.splitlines() if "=" in line)
    if entries.get("wpa_state") == "COMPLETED":
        # wpa_supplicant escapes non-ASCII bytes in the displayed SSID.
        import re
        raw = re.sub(rb'\\(x[0-9a-fA-F]{2}|[\\"])',
                     lambda m: bytes.fromhex(m[1][1:].decode()) if m[1].startswith(b"x") else m[1],
                     entries.get("ssid", "").encode())
        try:
            name = raw.decode("utf-8")
            return name if name.isprintable() else ""
        except UnicodeError:
            pass
    return ""


class SleepWifi:
    """Airplane mode while the reader is locked, so the radio is fully off."""

    def __init__(self):
        self.owned = False
        self.enabled_again = False
        self.requested = False
        self.radio_on = True
        self.quiet = 0
        self.ssid = ""

    def lock(self):
        """Returns False when a read or write failed and the lock should be tried again."""
        if self.owned and not self.enabled_again:
            return True
        if self.owned:
            # Locked again while leaving airplane mode: keep the state captured
            # on the first lock and switch the radios off once more.
            if write_int(CONNECTION, "wirelessEnable", 0):
                self.enabled_again = False
                self.requested = False
                self.quiet = 0
            else:
                print("Could not re-enter airplane mode on reader lock", file=sys.stderr)
                return False
            return True
        self.requested = False
        self.quiet = 0
        # Airplane mode already on: keep it. A radio that is momentarily down
        # (powerd switches it off at sleep) does not stop airplane mode.
        wireless = read_int(CONNECTION, "wirelessEnable")
        if wireless != 1:
            return wireless is not None
        self.radio_on = read_int(RADIO, "enable") == 1
        self.ssid = (current_ssid() if self.radio_on else "") or self.ssid
        self.enabled_again = False
        self.owned = write_int(CONNECTION, "wirelessEnable", 0)
        if not self.owned:
            print("Could not enter airplane mode on reader lock", file=sys.stderr)
        return self.owned

    def restore(self):
        """Leave airplane mode and reconnect. Returns True once nothing is left to do."""
        if not self.owned:
            return True
        wireless = read_int(CONNECTION, "wirelessEnable")
        if wireless is None:
            return False
        if not self.enabled_again:
            self.enabled_again = write_int(CONNECTION, "wirelessEnable", 1)
            if not self.enabled_again:
                return False
        elif wireless == 0:  # Airplane mode was selected again outside the reader.
            self.owned = False
            return True
        radio = read_int(RADIO, "enable")
        if not self.radio_on:
            # Wi-Fi was off before the lock: leave it off. The radio can come up
            # a moment after airplane mode ends, so see it stay down twice.
            if radio != 0:
                self.quiet = 0
                if radio == 1:
                    write_int(RADIO, "enable", 0)
                return False
            self.quiet += 1
            if self.quiet < 2:
                return False
            self.owned = False
            return True
        if radio == 0 and not write_int(RADIO, "enable", 1):
            return False
        connected = current_ssid()
        if not self.ssid or connected == self.ssid or (connected and self.requested):
            self.owned = False
            return True
        # A successful request can precede association. Check again on the
        # next wake callback while the driver starts and scans for the AP.
        self.requested = command("lipc-set-prop", CONNECTION, "ensureConnection",
                                 "wifi:" + self.ssid) is not None
        return False

    def finish(self, attempts=4, pause=2.0):
        """Retry on normal exit, when no further wake callback will arrive."""
        for attempt in range(attempts):
            if self.restore():
                return
            if attempt + 1 < attempts:
                time.sleep(pause)
