"""Locate the two data directories used by the old Kindle reader or Windows preview."""
import os
import subprocess
from functools import lru_cache
from pathlib import Path
from threading import Lock


_lookup = Lock()


@lru_cache(maxsize=1)
def _desktop_books():
    if os.name != "nt":
        return Path.home() / ".local/share/pw3-weread/books"
    # run-original.ps1 used Ubuntu's default user. Ask WSL for its home path without opening a window.
    try:
        result = subprocess.run(["wsl.exe", "-d", "Ubuntu", "--cd", "~", "--exec", "/usr/bin/wslpath",
                                 "-w", ".local/share/pw3-weread/books"], timeout=10, check=True,
                                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=subprocess.CREATE_NO_WINDOW)
        books = Path(result.stdout.decode("utf-8").strip())
        return books if books.is_absolute() else None
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def desktop_legacy_books():
    with _lookup:
        return _desktop_books()


def legacy_directories(store, kindle):
    directory = store.path.parent
    if kindle:
        if directory != Path("/mnt/us/weread/independent-data"):
            return None
        return Path("/var/local/weread-test"), directory.parent
    if directory != Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Kindle-WeRead/independent":
        return None
    books = desktop_legacy_books()
    if books is not None:
        return books.parent / "account", books
    return None
