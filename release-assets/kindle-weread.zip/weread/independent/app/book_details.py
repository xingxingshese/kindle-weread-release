"""Metadata from the ordinary WeRead book detail page and the signed-in shelf."""
import json
import re

from client import WEB, ReaderError, reader_id


def ordinary(book_id):
    return book_id != "mpbook" and not book_id.startswith("MP_")


def published_details(client, book_id):
    page = client.request(WEB + "/web/bookDetail/" + reader_id(book_id))
    marker = re.search(r"window\.__INITIAL_STATE__\s*=\s*", page)
    if marker:
        state = json.JSONDecoder().raw_decode(page[marker.end():])[0]
        info = (state.get("bookReview") or {}).get("bookInfo") or {}
        if str(info.get("bookId")) == book_id:
            return info
    raise ReaderError("未收到这本书的完整资料。")


def description(book):
    lines = [book["title"]]
    for field, name in (("author", "作者"), ("translator", "译者"), ("category", "分类"),
                        ("publisher", "出版社"), ("publishTime", "出版日期"), ("isbn", "ISBN")):
        value = book.get(field)
        if isinstance(value, str) and value.strip():
            lines.append(name + "　" + (value[:10] if field == "publishTime" else value.strip()))
    words = book.get("totalWords")
    if isinstance(words, int) and words > 0:
        lines.append(f"字数　{words:,}")
    score, count = book.get("newRating"), book.get("newRatingCount")
    if isinstance(score, int) and 0 < score <= 1000 and isinstance(count, int) and count > 0:
        lines.append(f"微信读书推荐值　{score/10:.1f}%（{count:,} 人点评）")
    elif count == 0:
        lines.append("微信读书推荐值　评分不足")
    if book.get("intro"):
        lines.append(book["intro"])
    return "\n\n".join(lines)
