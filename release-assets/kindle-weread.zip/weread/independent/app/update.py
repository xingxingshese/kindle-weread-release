"""Install verified application files on the USB volume for the next launch."""
import errno
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
from concurrent.futures import ThreadPoolExecutor, wait
from http.client import HTTPException
import json
import os
import re
import shutil
import time
from pathlib import Path, PurePosixPath
from urllib.request import Request, urlopen
from urllib.parse import urlsplit
from zipfile import BadZipFile, ZipFile

REPO = "xingxingshese/kindle-weread-release"


@dataclass(frozen=True)
class InstallLayout:
    app: Path
    store: Path
    prefix: str
    required: tuple
    lock: Path


def console(*fields):
    print(*fields, flush=True)


@contextmanager
def install_lock(path):
    with path.open("a+b") as lock:
        if os.name == "nt":
            import msvcrt
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield


def routes(url):
    return [url, "https://api.gitproxy.dev/" + url.removeprefix("https://"),
            *["https://" + host + "/" + url for host in
              ("gh-proxy.com", "ghproxy.net", "ghproxy.homeboyc.cn", "github.akams.cn")]]


def open_asset(url, byte_range=None):
    headers = {"User-Agent": "Kindle-WeRead", "Accept-Encoding": "identity"}
    if byte_range:
        headers["Range"] = "bytes=" + byte_range
    return urlopen(Request(url, headers=headers), timeout=8)


def probe(url):
    started = time.monotonic()
    with open_asset(url, "0-32767") as response:
        prefix = response.read(32768)
        if not prefix.startswith(b"PK\x03\x04"):
            raise ValueError("无效的安装包")
    return len(prefix) / max(.001, time.monotonic() - started)


def ranked_routes(url):
    choices = routes(url)
    pool = ThreadPoolExecutor(max_workers=len(choices))
    jobs = {pool.submit(probe, u): u for u in choices}
    try:
        done, _ = wait(jobs, timeout=5)
        speeds = []
        for job in done:
            try:
                speeds.append((job.result(), jobs[job]))
            except (OSError, HTTPException, ValueError):
                pass
        ranked = [u for _, u in sorted(speeds, reverse=True)]
        return ranked + [u for u in choices if u not in ranked]
    finally:
        pool.shutdown(wait=False, cancel_futures=True)


def download(asset, path, digest, emit=console):
    url, size = asset["browser_download_url"], asset["size"]
    emit("stage", "probe")
    choices = ranked_routes(url)
    last_error = ""
    with path.open("w+b") as output:
        for index, source in enumerate(choices + [url]):
            # The final direct attempt starts fresh if mirrors supplied bad data.
            offset = output.tell() if index < len(choices) else 0
            if offset == size:
                offset = 0
            try:
                with open_asset(source, f"{offset}-" if offset else None) as response:
                    if response.status == 206:
                        if response.headers.get("Content-Range") != f"bytes {offset}-{size-1}/{size}":
                            raise ValueError("下载范围不匹配")
                    elif response.status == 200:
                        offset = 0
                    else:
                        raise ValueError("下载地址不可用")
                    length = response.headers.get("Content-Length")
                    if length is not None and int(length) != size-offset:
                        raise ValueError("安装包大小不匹配")
                    output.seek(offset)
                    output.truncate()
                    host = urlsplit(source).hostname
                    window = last = time.monotonic()
                    baseline = offset
                    emit("progress", offset, size, host)
                    while output.tell() < size:
                        chunk = response.read1(min(65536, size-output.tell()))
                        if not chunk:
                            raise ValueError("下载中断")
                        if output.tell() == 0 and len(chunk) >= 4 and not chunk.startswith(b"PK\x03\x04"):
                            raise ValueError("下载地址未返回安装包")
                        output.write(chunk)
                        now = time.monotonic()
                        if now-last >= 1 or output.tell() == size:
                            emit("progress", output.tell(), size, host)
                            last = now
                        if now-window >= 8:
                            if index+1 < len(choices) and output.tell()-baseline < (now-window)*32768:
                                raise ValueError("下载较慢，切换线路")
                            window, baseline = now, output.tell()
            except (HTTPException, OSError, ValueError) as exc:
                if isinstance(exc, OSError) and exc.errno in (28, 30, 5):
                    raise
                last_error = str(exc)
                continue
            emit("stage", "verify")
            output.seek(0)
            if "sha256:" + hashlib.file_digest(output, "sha256").hexdigest() == digest:
                return
            output.seek(0)
            output.truncate()
            last_error = "安装包校验失败"
    raise ValueError("下载失败：" + last_error)


def member_path(name):
    parts = name.split("/")
    if any(p in ("", ".", "..") or p.endswith((" ", ".")) or ":" in p or "\\" in p for p in parts):
        raise ValueError("更新包路径无效")
    return PurePosixPath(*parts)


def installed(path, revision, required):
    marker = path / "revision"
    return (marker.is_file() and marker.read_text().strip() == str(revision)
            and all((path / name).is_file() for name in required))


def unpack(archive, dest, revision, layout, base=None):
    with ZipFile(archive) as z:
        members = [i for i in z.infolist() if i.filename.startswith(layout.prefix) and not i.is_dir()]
        reused = {}
        if base is not None:
            manifest = json.loads(z.read("delta.json"))
            if manifest["base"] != base or manifest["revision"] != revision:
                raise ValueError("增量包版本不匹配")
            reused = manifest["reuse"]
        required = sum(row[0] for row in reused.values()) + sum(i.file_size for i in members)
        if required > shutil.disk_usage(dest).free:
            raise OSError(errno.ENOSPC, "Kindle 剩余空间不足")
        for name, (size, expected_hash, executable) in reused.items():
            relative = member_path(name)
            source = layout.app / relative
            out = dest / relative
            if source.stat().st_size != size:
                raise ValueError("本地文件与增量包不匹配")
            out.parent.mkdir(parents=True, exist_ok=True)
            digest = hashlib.sha256()
            with source.open("rb") as src, out.open("xb") as dst:
                while chunk := src.read(256 * 1024):
                    dst.write(chunk)
                    digest.update(chunk)
            if digest.hexdigest() != expected_hash:
                raise ValueError("本地文件与增量包不匹配")
            if executable:
                out.chmod(0o755)
        for info in members:
            name = info.filename[len(layout.prefix):]
            out = dest / member_path(name)
            out.parent.mkdir(parents=True, exist_ok=True)
            with z.open(info) as source, out.open("xb") as target:
                shutil.copyfileobj(source, target)
            if info.external_attr >> 16 & 0o111:
                out.chmod(0o755)
        if not installed(dest, revision, layout.required):
            raise ValueError("更新包版本或文件不完整")


def prepare_update(staging, rev, asset, layout, base=None, emit=console):
    digest = asset.get("digest") or ""
    if not re.fullmatch("sha256:[0-9a-f]{64}", digest):
        raise ValueError("GitHub 未提供有效的校验值")
    if shutil.disk_usage(staging).free < asset["size"]:
        raise OSError(errno.ENOSPC, "Kindle 剩余空间不足")
    archive = staging / "install.zip"
    download(asset, archive, digest, emit)
    emit("stage", "install")
    payload = staging / "app"
    payload.mkdir()
    unpack(archive, payload, rev, layout, base)
    return payload


def install(rev, full, delta=None, *, layout, emit=console):
    store = layout.store
    store.mkdir(exist_ok=True)
    with install_lock(layout.lock):
        dest = store / str(rev)
        if installed(dest, rev, layout.required):
            return
        staging = store / ".pending"
        if staging.exists():
            shutil.rmtree(staging)
        staging.mkdir()
        try:
            current = int((layout.app / "revision").read_text())
            payload = None
            if delta:
                try:
                    payload = prepare_update(staging, rev, delta, layout, current, emit)
                except (ValueError, BadZipFile, KeyError, FileNotFoundError):
                    shutil.rmtree(staging)
                    staging.mkdir()
                    emit("stage", "fallback")
            if payload is None:
                payload = prepare_update(staging, rev, full, layout=layout, emit=emit)
            if hasattr(os, "sync"):
                os.sync()
            if dest.is_dir():
                shutil.rmtree(dest)
            payload.rename(dest)
            if hasattr(os, "sync"):
                os.sync()
            for old in store.iterdir():
                if old.name.isascii() and old.name.isdecimal() and int(old.name) < current and old.is_dir():
                    shutil.rmtree(old, ignore_errors=True)
        finally:
            shutil.rmtree(staging, ignore_errors=True)
