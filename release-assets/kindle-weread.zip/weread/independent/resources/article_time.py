"""Report elapsed time confirmed by a foreground article page turn."""
import hashlib
import json
import re
import secrets
import time
from urllib.parse import quote
from urllib.request import Request, build_opener

from .mp import NoRedirect, checked_json

BASE = "https://weread.qq.com"
AGENT = "Kindle-WeRead (Kindle Paperwhite)"


def reader_id(value):
    text = str(value)
    digest = hashlib.md5(text.encode()).hexdigest()
    numeric = text.isdecimal()
    chunks = ([format(int(text[i:i+9]), "x") for i in range(0, len(text), 9)] if numeric
              else ["".join(format(ord(c), "x") for c in text)])
    result = digest[:3] + ("32" if numeric else "42") + digest[-2:]
    result += "g".join(f"{len(chunk):02x}{chunk}" for chunk in chunks)
    result += digest[:max(0, 20-len(result))]
    return result + hashlib.md5(result.encode()).hexdigest()[:3]


def app_id():
    number = 0
    for char in AGENT:
        number = (131*number + ord(char)) & 0x7fffffff
    return "wb" + "".join(str(len(p) % 10) for p in AGENT.split()[:12]) + "h" + str(number)


def checksum(fields):
    query = "&".join(key + "=" + quote(str(fields[key]), safe="~()*!.'-") for key in sorted(fields))
    a = b = 0x15051505
    for i in range(len(query)-1, 0, -2):
        a = (a ^ (ord(query[i]) << ((len(query)-i) % 30))) & 0x7fffffff
        b = (b ^ (ord(query[i-1]) << (i % 30))) & 0x7fffffff
    return format(a+b, "x")


class ArticleSession:
    def __init__(self, login, book):
        self.book = reader_id(book)
        self.url = BASE + "/web/mp/reader/" + self.book
        self.headers = {"Cookie": login, "User-Agent": AGENT, "Referer": self.url}
        self.opener = build_opener(NoRedirect())
        page = self.fetch(self.url)
        match = re.search(r"window\.__INITIAL_STATE__\s*=\s*", page)
        state = json.JSONDecoder().raw_decode(page[match.end():])[0] if match else {}
        reader = next((v for v in state.values() if isinstance(v, dict)
                       and v.get("bookId") == book and v.get("psvts")), {})
        if not reader:
            raise ValueError("请重新登录后同步阅读时长")
        self.server_stamp = reader["psvts"]
        self.client_stamp = reader_id(int(time.time()))
        self.token = reader.get("token") or checked_json(self.fetch(BASE+"/web/getConfig")).get("token")
        if not self.token:
            raise ValueError("微信读书未返回阅读会话")

    def fetch(self, url, body=None):
        headers = dict(self.headers)
        if body is not None:
            headers.update({"Content-Type": "application/json", "Origin": BASE})
        with self.opener.open(Request(url, data=body, headers=headers), timeout=10) as res:
            return res.read().decode("utf-8")

    def report(self, review, seconds):
        now = time.time_ns() // 1000000
        rn = secrets.randbelow(1000)
        fields = dict(appId=app_id(), b=self.book, c=reader_id(0), ci=0, co=0, sm="", pr=0,
                      rt=seconds, ts=now, rn=rn, ri=review, ct=now//1000,
                      ps=self.server_stamp, pc=self.client_stamp,
                      sg=hashlib.sha256(f"{now}{rn}{self.token}".encode()).hexdigest())
        fields["s"] = checksum(fields)
        result = checked_json(self.fetch(BASE+"/web/book/read", json.dumps(fields).encode()))
        if not result or result.get("succ") == 0:
            raise ValueError("微信读书未确认阅读时长")
        return result
