"""Fetch an article illustration from the WeChat CDN and fit it to the reader."""
import hashlib
import os
from pathlib import Path
from tempfile import NamedTemporaryFile
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from PIL import Image, ImageOps


def image_url(url):
    if url.startswith("//"):
        url = "https:" + url
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https") or parts.hostname not in (
        "mmbiz.qpic.cn", "mmbiz.qlogo.cn", "mmbiz.qpic.com", "res.wx.qq.com"
    ) or parts.username or parts.password or parts.port not in (None, 443):
        raise ValueError("Unsupported image address")
    return parts._replace(scheme="https").geturl()


class ImageRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return super().redirect_request(req, fp, code, msg, headers, image_url(newurl))


def fitted_image(cache, url, width):
    url = image_url(url)
    key = hashlib.sha256(url.encode()).hexdigest()
    cache.mkdir(mode=0o700, exist_ok=True)
    source = cache / key
    target = cache / f"{key}-{width}.png"
    if target.exists():
        return target
    scratch = None
    try:
        if not source.exists():
            req = Request(url, headers={"Referer": "https://mp.weixin.qq.com/"})
            with build_opener(ImageRedirect()).open(req, timeout=15) as response, NamedTemporaryFile(dir=cache, delete=False) as tmp:
                scratch = Path(tmp.name)
                while chunk := response.read(65536):
                    tmp.write(chunk)
                    if tmp.tell() > 32 * 1024 * 1024:
                        raise ValueError("Image too large")
        with Image.open(scratch or source) as raw:
            image = ImageOps.exif_transpose(raw)
            image.thumbnail((width, round(width * 1.32)), Image.Resampling.LANCZOS)
            gray = Image.new("L", image.size, 255)
            rgba = image.convert("RGBA")
            gray.paste(rgba.convert("L"), mask=rgba.getchannel("A"))
        if scratch:
            os.replace(scratch, source)
        with NamedTemporaryFile(dir=cache, delete=False) as tmp:
            scratch = Path(tmp.name)
            gray.save(tmp, format="PNG")
        os.replace(scratch, target)
        return target
    finally:
        if scratch:
            scratch.unlink(missing_ok=True)
