"""Article reader and screensaver resources shared by Windows and Kindle."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent
