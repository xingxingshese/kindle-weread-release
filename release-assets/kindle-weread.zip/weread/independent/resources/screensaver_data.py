"""Supply the reader cover with an almanac and IP-localized weather."""
import json
from bisect import bisect_right
from datetime import datetime, timedelta, timezone
from http.client import HTTPException
from urllib.parse import urlencode
from urllib.request import Request, urlopen


def local_calendar(now, emit):
    try:
        from lunar_python import Solar
    except ImportError:
        return
    lunar = Solar.fromYmd(now.year, now.month, now.day).getLunar()
    emit(lunar=f"农历{lunar.getMonthInChinese()}月{lunar.getDayInChinese()}",
         good=" ".join(lunar.getDayYi()[:4]), avoid=" ".join(lunar.getDayJi()[:4]))


def fetch(url):
    with urlopen(Request(url, headers={"User-Agent": "WeRead-PW3"}), timeout=7) as response:
        return json.load(response)


def network_location():
    for url in ("https://ipwho.is/?lang=zh-CN&fields=success,city,latitude,longitude", "https://ipapi.co/json/"):
        try:
            place = fetch(url)
            city = " ".join(place["city"].split())
            lat, lon = float(place["latitude"]), float(place["longitude"])
            if place.get("success") is not False and not place.get("error") and city and -90 <= lat <= 90 and -180 <= lon <= 180:
                return city, lat, lon
        except (OSError, HTTPException, ValueError, KeyError, TypeError, AttributeError):
            continue
    raise ValueError("网络定位暂不可用")


def request(location, host, endpoint, **params):
    _, lat, lon = location
    query = urlencode(dict(latitude=lat, longitude=lon, timezone="auto", **params))
    return fetch(f"https://{host}/v1/{endpoint}?{query}")


def local_day(data):
    return datetime.now(timezone(timedelta(seconds=data["utc_offset_seconds"]))).date().isoformat()


def condition(code):
    if code <= 3:
        return ("晴", "大部晴朗", "局部多云", "阴")[code]
    if code <= 48:
        return "雾"
    if code <= 67:
        return "雨"
    if code <= 77:
        return "雪"
    if code <= 82:
        return "阵雨"
    return "阵雪" if code <= 86 else "雷阵雨"


def weather(location, emit):
    forecast = request(location, "api.open-meteo.com", "forecast",
                       current="temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m",
                       hourly="temperature_2m,weather_code",
                       daily="weather_code,temperature_2m_min,temperature_2m_max,precipitation_probability_max,uv_index_max,sunrise,sunset",
                       forecast_days=2)
    cur, daily, hourly = (forecast[k] for k in ("current", "daily", "hourly"))
    today = local_day(forecast)
    if cur["time"][:10] != today or daily["time"][0] != today:
        raise ValueError("forecast date does not match the dashboard")
    low, high = (round(daily[k][1]) for k in ("temperature_2m_min", "temperature_2m_max"))
    clothes = "轻薄短袖" if high >= 28 else "长袖或薄外套" if high >= 15 else "保暖外套"
    advice = f"明日 {low}–{high}°C，建议穿{clothes}"
    if daily["precipitation_probability_max"][1] >= 40:
        advice += "，出门带伞"
    direction = ("北", "东北", "东", "东南", "南", "西南", "西", "西北")[int((cur["wind_direction_10m"]+22.5)//45) % 8]
    level = bisect_right((1, 6, 12, 20, 29, 39, 50, 62, 75, 89, 103, 118), cur["wind_speed_10m"])
    start = next(i for i, moment in enumerate(hourly["time"]) if moment[:13] == cur["time"][:13])
    hours = {}
    for slot, step in enumerate((0, 3, 6, 9)):
        i = start + step
        hours[f"hour{slot}"] = hourly["time"][i][11:16]
        hours[f"sky{slot}"] = condition(hourly["weather_code"][i])
        hours[f"temp{slot}"] = f"{round(hourly['temperature_2m'][i])}°"
    emit(temp=round(cur["temperature_2m"]), current=condition(cur["weather_code"]),
         humidity=f"{cur['relative_humidity_2m']}%", feels=f"{round(cur['apparent_temperature'])}°C",
         wind=f"{direction}{level}级", uv=round(daily["uv_index_max"][0]),
         rain=f"{daily['precipitation_probability_max'][0]}%", sunrise=(daily["sunrise"][0] or "")[11:16] or "—",
         sunset=(daily["sunset"][0] or "")[11:16] or "—", tomorrow=condition(daily["weather_code"][1]),
         clothes=advice+"。", **{"range": f"{high}°C / {low}°C"}, **hours,
         stamp=f"{location[0]} · Open-Meteo  {cur['time'][11:16]}")


def collect(online, emit):
    local_calendar(datetime.now(), emit)
    if not online:
        return
    try:
        location = network_location()
    except ValueError:
        emit(city="", stamp="网络定位暂不可用", current="暂无本地预报")
        return
    emit(city=location[0])
    try:
        weather(location, emit)
    except (OSError, HTTPException, ValueError, KeyError, IndexError, TypeError, StopIteration):
        emit(stamp=f"{location[0]} · 天气暂未更新")
        emit(current="暂无新预报")
    try:
        data = request(location, "air-quality-api.open-meteo.com", "air-quality", current="us_aqi")
        air = data["current"]
        if air["time"][:10] == local_day(data):
            emit(aqi=round(air["us_aqi"]))
    except (OSError, HTTPException, ValueError, KeyError, TypeError):
        pass
