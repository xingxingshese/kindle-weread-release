#!/bin/sh
# Name: 微信读书 独立修订版 v0.07
# Icon: /mnt/us/weread/independent/resources/default-cover.png
# DontUseFBInk
exec sh /mnt/us/weread/independent/run.sh
